// ════════════════════════════════════════════════════════════
// 灶咖茶弄 Zaoka — 菜單資料
//
// 要新增 / 修改品項、價錢或選項，只需要改這個檔案。
//
// 品項欄位說明：
//   id          編號（新增品項時給一個沒用過的數字）
//   name        品名
//   price       價格（單一杯型，不分大小杯）
//   cat         分類（要和 MENU_CATEGORIES 裡的名稱一致）
//   fixedSweet  寫 true＝此品項「甜度固定、不可調」，點餐時甜度鎖成「固定甜度」
//   fixedIce    寫 true＝此品項「冰塊固定、不可調」，點餐時冰塊鎖成「固定冰塊」
//               （沒寫＝甜度／冰塊可自由選）
//
// 注意：
//   ・每一項用 { } 包起來，項目之間用逗號分隔
//   ・文字用雙引號 " " 包起來，數字不用
//   ・菜單／選項要和線上點餐頁（zaoka.com.tw/order）保持一致
// ════════════════════════════════════════════════════════════

// ── 分類顯示順序 ─────────────────────────────────────────────
//   點餐畫面每個分類一直欄，由左到右照這個順序排；
//   沒列在這裡的分類會自動接在最後面（品項不會消失）
window.MENU_CATEGORIES = [
  "原味茶",
  "手炒黑糖",
  "鮮奶茶",
  "甘蔗",
  "棒打梅子",
  "檸檬",
  "特調",
];

// ── 點餐畫面的菜單版面（全部品項一頁排完、不用捲動）────────────
//   "columns"：價目看板式，每個分類一直欄並排
//   "blocks" ：分類分上下兩排區塊，區塊內品項排兩欄
//   （想暫時比較另一種，可在網址後面加 ?layout=blocks 或 ?layout=columns）
window.MENU_VIEW = "columns";
//   "blocks" 版面上排放幾個分類（照上面 MENU_CATEGORIES 的順序取前幾個，其餘放下排）。
//   上排區塊比較寬，品名字數多的分類（例：黑糖珍珠布丁鮮奶）要排在前面、放上排
window.MENU_BLOCKS_TOP = 3;

// ── 品項按鈕上顯示價格 ───────────────────────────────────────
//   true ：每顆按鈕右下角顯示價格
//   false：不顯示，品名置中、可以排得更大（點進品項視窗、購物車一樣看得到價格）
//   （想暫時比較，可在網址後面加 ?price=1 或 ?price=0）
window.MENU_SHOW_PRICE = false;

// ── 分類標題底色 ─────────────────────────────────────────────
//   可用顏色：橘色、綠色、淡綠色、藍色、咖啡色、藍綠色、紫色、紅色、金色
window.MENU_CATEGORY_COLORS = {
  "原味茶":   "綠色",
  "手炒黑糖": "咖啡色",
  "鮮奶茶":   "金色",
  "甘蔗":     "藍綠色",
  "棒打梅子": "紅色",
  "檸檬":     "淡綠色",
  "特調":     "紫色",
};

// ── 甜度選項 ─────────────────────────────────────────────────
//   一般品項可自由選；fixedSweet 的品項會鎖成 SWEETNESS_FIXED_LABEL
//   2026-10-24：加多糖、一分糖，以及「黑糖」（跟其他甜度一樣只能選一個，每杯加價見 SWEETNESS_PRICE）；
//   2026-10-28 Rory：二分糖加回來，放在一分糖左邊
//   點餐畫面是一條「程度條」，由左到右照這個順序排（多糖在最左邊；黑糖接在最右邊、中間有一條分隔）。
//   跟下面的溫度條上下對齊：第 1 格正常糖對正常冰、第 3 格半糖對半冰、第 7 格無糖對去冰，改順序時兩邊要一起看
//   2026-11-08 Rory：黑糖右邊加「客製」（SWEETNESS_CUSTOM_LABEL）：選了跳出小視窗選 0.1～2.0 分糖（每次 0.1），記成「0.3分糖」
window.SWEETNESS_OPTIONS = ["多糖", "正常糖", "少糖", "半糖", "微糖", "二分糖", "一分糖", "無糖", "黑糖", "客製"];
window.SWEETNESS_DEFAULT = "正常糖";
window.SWEETNESS_FIXED_LABEL = "固定甜度";
window.SWEETNESS_CUSTOM_LABEL = "客製";
// 要加價的甜度：{ "甜度": 每杯加幾元 }（按鈕上用小字提醒，單價自動加上）
window.SWEETNESS_PRICE = { "黑糖": 5 };

// ── 溫度（冰塊＋熱飲）─────────────────────────────────────────
//   一般品項可自由選；fixedIce 的品項會鎖成 ICE_FIXED_LABEL
//   2026-10-24：加多冰、微微冰。點餐畫面的「溫度」程度條由左到右：
//   ICE_OPTIONS（多冰在最左邊）→ 分隔 → HOT_OPTIONS（常溫、溫、熱，越右越熱）。兩組只能選一個
//   2026-10-28 Rory：微微冰後面加「特定」（ICE_CUSTOM_LABEL）：選了會再跳出小視窗選幾顆冰塊，記成「冰塊3顆」
//   （原本備註裡的「冰塊」那一類拿掉了）
window.ICE_OPTIONS = ["多冰", "正常冰", "少冰", "半冰", "微冰", "微微冰", "特定", "去冰"];
window.ICE_DEFAULT = "正常冰";
window.ICE_FIXED_LABEL = "固定冰塊";
window.ICE_CUSTOM_LABEL = "特定";
window.HOT_OPTIONS = ["常溫", "溫", "熱"];
// 固定甜度、固定冰塊：2026-11-08 Rory 起所有品項都可以解開（品項視窗寫「固定X，點擊可修改」，點了出現一般的程度條；
// 不再提醒冰塊不滿杯），原本只限手炒黑糖的 FIXED_ICE_UNLOCK_CATEGORIES 拿掉了

// ── 原料專區（2026-11-08 Rory）──────────────────────────────────
//   菜單原味茶那一欄、經典冬瓜茶下面的「原料專區」：客人買原料（不是飲料：不算杯數、不印杯子貼紙、不打折、不集點）
//   key   記錄用的代號（不能重複）　name  品名　price  一份多少錢
//   tea   寫 true＝桶裝茶：按 + 之後再選哪一種茶（RAW_TEA_CATEGORY 那一類的品項），收據、購物車寫在品名下面
window.RAW_ITEMS = [
  { key: "milk",   name: "牛奶",      price: 70 },
  { key: "lemon",  name: "檸檬",      price: 100 },
  { key: "cane",   name: "甘蔗",      price: 90 },
  { key: "plum",   name: "梅子",      price: 100 },
  { key: "soy",    name: "豆漿",      price: 80 },
  { key: "ice",    name: "冰塊",      price: 10 },
  { key: "tea8",   name: "8L桶裝茶",  price: 400, tea: true },
  { key: "tea12",  name: "12L桶裝茶", price: 500, tea: true },
];
window.RAW_TEA_CATEGORY = "原味茶";

// ── 加料（可複選）────────────────────────────────────────────
//   點餐時可多選，每杯價錢自動加上所選料的加價。
//   name   記錄用的名字（不能重複）
//   show   按鈕、貼紙、收據上的字（沒寫就用 name）：同一種料有兩種價錢時，name 分開、show 一樣
//   group  同一組只能選一個（例如 +10 和 +5 的黑糖珍珠不能同時加）
//   uses   完售共用的材料名（長按其中一個設完售，同一種料一起完售）
//   newRow 寫 true＝從新的一排開始
//   2026-10-24：上排原本 +10 的料；中間一排同樣的料「少」一點 +5（按鈕、貼紙寫「黑糖珍珠少」…）；
//   下排養樂多、鮮奶、梅子 +10，布丁 +15 接在梅子右邊（Rory）；2026-10-28 Rory：加豆奶 +10，接在梅子右邊、布丁放到豆奶旁邊
//   （下排 5 樣，加料視窗一排 5 格）
window.TOPPINGS = [
  { "name": "黑糖珍珠", "price": 10, "group": "黑糖珍珠" },
  { "name": "羅勒籽",   "price": 10, "group": "羅勒籽" },
  { "name": "椰果",     "price": 10, "group": "椰果" },
  { "name": "黑糖珍珠+5", "show": "黑糖珍珠少", "price": 5, "group": "黑糖珍珠", "uses": "黑糖珍珠", "newRow": true },
  { "name": "羅勒籽+5",   "show": "羅勒籽少",   "price": 5, "group": "羅勒籽",   "uses": "羅勒籽" },
  { "name": "椰果+5",     "show": "椰果少",     "price": 5, "group": "椰果",     "uses": "椰果" },
  { "name": "養樂多",   "price": 10, "newRow": true },
  { "name": "鮮奶",     "price": 10 },
  { "name": "梅子",     "price": 10 },
  { "name": "豆奶",     "price": 10 },
  { "name": "布丁",     "price": 15 },
];
// 一杯最多加幾樣料（0＝不限）
window.TOPPING_MAX = 0;

// ── 品項資料 ─────────────────────────────────────────────────
window.MENU_DATA = [
  // 原味茶
  { "id": 1,  "name": "灶咖家鄉紅茶", "price": 30, "cat": "原味茶" },
  { "id": 2,  "name": "杉林溪青茶",   "price": 30, "cat": "原味茶" },
  { "id": 3,  "name": "四季春青茶",   "price": 30, "cat": "原味茶" },
  { "id": 4,  "name": "茉莉綠茶",     "price": 30, "cat": "原味茶" },
  { "id": 5,  "name": "鐵觀音茶",     "price": 30, "cat": "原味茶" },
  { "id": 6,  "name": "經典冬瓜茶",   "price": 30, "cat": "原味茶", "fixedSweet": true },

  // 手炒黑糖
  { "id": 7,  "name": "黑糖珍珠鮮奶",     "price": 65, "cat": "手炒黑糖", "fixedSweet": true, "fixedIce": true },
  { "id": 8,  "name": "黑糖布丁鮮奶",     "price": 65, "cat": "手炒黑糖", "fixedSweet": true, "fixedIce": true },
  { "id": 9,  "name": "黑糖珍珠布丁鮮奶", "price": 65, "cat": "手炒黑糖", "fixedSweet": true, "fixedIce": true },
  { "id": 10, "name": "黑糖鮮奶",         "price": 65, "cat": "手炒黑糖", "fixedSweet": true, "fixedIce": true },
  { "id": 11, "name": "黑糖紅茶鮮奶",     "price": 55, "cat": "手炒黑糖", "fixedSweet": true },

  // 鮮奶茶
  { "id": 12, "name": "紅茶鮮奶",   "price": 50, "cat": "鮮奶茶" },
  { "id": 13, "name": "綠茶鮮奶",   "price": 50, "cat": "鮮奶茶" },
  { "id": 14, "name": "青茶鮮奶",   "price": 50, "cat": "鮮奶茶" },
  { "id": 15, "name": "鐵觀音鮮奶", "price": 50, "cat": "鮮奶茶" },
  { "id": 16, "name": "冬瓜鮮奶",   "price": 50, "cat": "鮮奶茶", "fixedSweet": true },
  { "id": 17, "name": "可可鮮奶",   "price": 60, "cat": "鮮奶茶" },

  // 甘蔗
  { "id": 18, "name": "甘蔗青茶",   "price": 55, "cat": "甘蔗", "fixedSweet": true },
  { "id": 19, "name": "甘蔗鐵觀音", "price": 55, "cat": "甘蔗", "fixedSweet": true },
  { "id": 20, "name": "甘蔗鮮奶",   "price": 75, "cat": "甘蔗", "fixedSweet": true, "fixedIce": true },
  { "id": 21, "name": "甘蔗檸檬",   "price": 80, "cat": "甘蔗", "fixedSweet": true, "fixedIce": true },
  { "id": 22, "name": "甘蔗青檸檬", "price": 55, "cat": "甘蔗", "fixedSweet": true },

  // 棒打梅子
  { "id": 23, "name": "梅子綠茶",   "price": 45, "cat": "棒打梅子" },
  { "id": 24, "name": "梅子檸檬",   "price": 50, "cat": "棒打梅子", "fixedSweet": true },
  { "id": 25, "name": "梅子溜",     "price": 55, "cat": "棒打梅子", "fixedSweet": true },
  { "id": 26, "name": "梅子養樂多", "price": 55, "cat": "棒打梅子", "fixedSweet": true },
  { "id": 27, "name": "梅子可樂",   "price": 60, "cat": "棒打梅子", "fixedSweet": true },

  // 檸檬
  { "id": 28, "name": "初戀檸檬溜", "price": 50, "cat": "檸檬", "fixedSweet": true },
  { "id": 29, "name": "翠綠檸檬溜", "price": 50, "cat": "檸檬", "fixedSweet": true },
  { "id": 30, "name": "青青檸檬溜", "price": 50, "cat": "檸檬", "fixedSweet": true },
  { "id": 31, "name": "冬瓜檸檬",   "price": 45, "cat": "檸檬", "fixedSweet": true },
  { "id": 32, "name": "檸檬紅茶",   "price": 45, "cat": "檸檬", "fixedSweet": true },
  // 原本的「檸檬綠青茶」拆成兩項（2026-10-21）：檸檬綠茶沿用 id 33，檸檬青茶用新 id 44
  // 2026-10-31 Rory：檸檬綠茶、檸檬青茶甜度改成可調（檸檬紅茶維持甜度固定；冰塊三項都可調）
  { "id": 33, "name": "檸檬綠茶",   "price": 45, "cat": "檸檬" },
  { "id": 44, "name": "檸檬青茶",   "price": 45, "cat": "檸檬" },
  { "id": 34, "name": "檸檬養樂多", "price": 50, "cat": "檸檬" },
  { "id": 35, "name": "檸檬汁",     "price": 45, "cat": "檸檬" },

  // 特調
  { "id": 36, "name": "古紅多多",   "price": 60, "cat": "特調", "fixedSweet": true },
  { "id": 37, "name": "養樂多綠茶", "price": 50, "cat": "特調" },
  { "id": 38, "name": "紅茶豆奶",   "price": 45, "cat": "特調", "fixedSweet": true },
  { "id": 39, "name": "冬瓜豆奶",   "price": 45, "cat": "特調", "fixedSweet": true },
  { "id": 40, "name": "冬瓜紅茶",   "price": 30, "cat": "特調", "fixedSweet": true },
  { "id": 41, "name": "冬瓜青茶",   "price": 30, "cat": "特調", "fixedSweet": true },
  { "id": 42, "name": "冬瓜鐵觀音", "price": 30, "cat": "特調", "fixedSweet": true },
  { "id": 43, "name": "經典可可",   "price": 50, "cat": "特調" },
];
