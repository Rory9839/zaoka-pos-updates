// 灶咖點餐：平板當主機時的「店內主機」執行環境（2026-11-01）。
//
// Pi 上的 server.js、vouchers.js、remarks.js、settings.js、customers.js 原封不動搬進點餐頁執行。
// 它們原本跑在 Node 上，這裡補上它們用到的 Node 功能：
//   fs            → App 的 window.PosFs（同步讀寫 App 資料夾裡的檔案，路徑一律 /data/…）
//   path          → 只用到 join
//   crypto        → randomInt、randomBytes、scryptSync（設定密碼）、timingSafeEqual
//   ws、http、express、net、child_process → 假的：WebSocket 改成同一頁裡的 LocalSocket（見 boot.js），
//                   express 的路由給 boot.js 的 fetch 轉接，印表機偵測在第 2 階段換成 USB
//   printer.js（貼紙機）→ 原封不動：/dev/juicebar-label 換成 USB（window.PosUsb），python3 label-render.py 換成 host/label-render.js
//   receipt.js（出單機）→ 原封不動：/dev/juicebar-receipt 換成 USB，python3 receipt-render.py 換成 host/receipt-render.js
//
// 模組由 android/sync-web.ps1 包成 host/modules.js：ZaokaHost.define('vouchers', function (require, module, …) { 原檔內容 })。
// 只有在 App 裡（有 window.PosFs）才會啟動；在 Pi 或電腦瀏覽器打開點餐頁時這裡什麼都不做。
(function () {
  'use strict';
  if (!window.PosFs) {
    window.ZaokaHost = { active: false, define: function () {} };
    return;
  }

  const defs = {}, cache = {};
  const H = window.ZaokaHost = { active: true, defs, logs: [], routes: { GET: {}, POST: {} }, wss: null, startError: null };

  // ── 紀錄：店內主機的 console 另外留最後 500 行（之後維護介面可以看）──
  function note(level, args) {
    const line = new Date().toISOString() + ' ' + level + ' ' + Array.prototype.map.call(args, a =>
      a instanceof Error ? (a.stack || a.message) : (typeof a === 'string' ? a : safeJson(a))).join(' ');
    H.logs.push(line);
    if (H.logs.length > 500) H.logs.splice(0, H.logs.length - 500);
  }
  function safeJson(v) { try { return JSON.stringify(v); } catch (e) { return String(v); } }
  const hostConsole = {
    log: function () { note('I', arguments); console.log.apply(console, ['[主機]'].concat([].slice.call(arguments))); },
    warn: function () { note('W', arguments); console.warn.apply(console, ['[主機]'].concat([].slice.call(arguments))); },
    error: function () { note('E', arguments); console.error.apply(console, ['[主機]'].concat([].slice.call(arguments))); }
  };

  // ── 小工具：事件 ──
  class Emitter {
    constructor() { this._ev = {}; }
    on(name, fn) { (this._ev[name] = this._ev[name] || []).push(fn); return this; }
    once(name, fn) { const w = (...a) => { this.off(name, w); fn(...a); }; return this.on(name, w); }
    off(name, fn) { this._ev[name] = (this._ev[name] || []).filter(f => f !== fn); return this; }
    emit(name, ...args) { (this._ev[name] || []).slice().forEach(f => f(...args)); return true; }
  }

  // ── fs ──
  function fsCall(op, a, b) {
    const r = JSON.parse(window.PosFs.call(op, a == null ? null : String(a), b == null ? null : String(b)));
    if (!r.ok) {
      const e = new Error(r.code + ': ' + r.msg);
      e.code = r.code;
      e.path = a;
      throw e;
    }
    return r.v;
  }
  // 印表機：Pi 上是 /dev/juicebar-label（貼紙機）、/dev/juicebar-receipt（出單機），平板上是 USB（window.PosUsb）
  const USB_DEVICES = { '/dev/juicebar-label': 'label', '/dev/juicebar-receipt': 'receipt' };
  const BUNDLED = { '/data/slogan.txt': 'host/slogan.txt' };
  const LABEL_FRESH_LIFT = 12;   // 貼紙機剛開機的第一張往上挪幾點（8 點＝1 mm；2026-11-07 Rory 量的是偏下 1.5 mm）
  const usbPresent = kind => { try { return !!(window.PosUsb && window.PosUsb.present(kind)); } catch (e) { return false; } };
  function usbWrite(kind, bytes) {
    if (!window.PosUsb) throw Object.assign(new Error('這個 App 沒有 USB 列印'), { code: 'ENODEV' });
    let bin = '';
    for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
    const r = JSON.parse(window.PosUsb.write(kind, btoa(bin)));
    if (!r.ok) {
      const why = { 'not-connected': '沒有接上', permission: '還沒允許「灶咖點餐」使用（請在平板上按允許）' }[r.reason] || r.reason;
      throw Object.assign(new Error((kind === 'label' ? '貼紙機' : '出單機') + why), { code: 'EIO' });
    }
  }
  const fs = {
    promises: {
      writeFile: (p, data) => new Promise((resolve, reject) => {
        try {
          if (USB_DEVICES[p]) usbWrite(USB_DEVICES[p], data instanceof Uint8Array ? data : new TextEncoder().encode(String(data)));
          else fsCall('write', p, String(data));
          resolve();
        } catch (e) { reject(e); }
      })
    },
    // 只讀文字檔（呼叫的地方都帶 'utf8'）。Pi 上跟程式放在一起的檔案（收據頁尾的祝福語 slogan.txt）
    // 在平板上是點餐頁的一部分（host/），資料夾裡沒有就從那裡拿
    readFileSync: (p) => {
      try { return fsCall('read', p); }
      catch (e) {
        const bundled = BUNDLED[p];
        if (e.code !== 'ENOENT' || !bundled) throw e;
        const x = new XMLHttpRequest();
        x.open('GET', bundled, false);
        x.send();
        if (x.status !== 200) throw e;
        return x.responseText;
      }
    },
    writeFileSync: (p, data) => { fsCall('write', p, String(data)); },
    appendFileSync: (p, data) => { fsCall('append', p, String(data)); },
    appendFile: (p, data, cb) => { try { fsCall('append', p, String(data)); if (cb) cb(null); } catch (e) { if (cb) cb(e); } },
    renameSync: (a, b) => { fsCall('rename', a, b); },
    copyFileSync: (a, b) => { fsCall('copy', a, b); },
    unlinkSync: (p) => { fsCall('unlink', p); },
    existsSync: (p) => { if (USB_DEVICES[p]) return usbPresent(USB_DEVICES[p]); try { return !!fsCall('exists', p); } catch (e) { return false; } },
    mkdirSync: (p) => { fsCall('mkdir', p); },
    readdirSync: (p) => fsCall('readdir', p),
    statSync: (p) => {
      const s = fsCall('stat', p);
      return { size: s.size, mtimeMs: s.mtimeMs, isFile: () => !s.dir, isDirectory: () => !!s.dir };
    }
  };

  // ── path（只用到 join）──
  const path = {
    sep: '/',
    join: function () {
      const parts = [].slice.call(arguments).join('/').split('/');
      const out = [];
      parts.forEach((s, i) => {
        if (s === '' && i > 0) return;
        if (s === '.') return;
        if (s === '..') { out.pop(); return; }
        out.push(s);
      });
      return out.join('/') || '/';
    },
    basename: p => String(p).split('/').pop(),
    dirname: p => String(p).split('/').slice(0, -1).join('/') || '/'
  };

  // ── Buffer、crypto（只做這幾個模組用到的）──
  class Buf extends Uint8Array {
    toString(enc) {
      if (enc === 'hex') return Array.prototype.map.call(this, b => b.toString(16).padStart(2, '0')).join('');
      return new TextDecoder().decode(this);
    }
  }
  const Buffer = {
    from(v, enc) {
      if (enc === 'hex') {
        const s = String(v), out = new Buf(s.length >> 1);
        for (let i = 0; i < out.length; i++) out[i] = parseInt(s.substr(i * 2, 2), 16);
        return out;
      }
      if (typeof v === 'string' && (enc === 'ascii' || enc === 'latin1' || enc === 'binary')) {
        const out = new Buf(v.length);
        for (let i = 0; i < v.length; i++) out[i] = v.charCodeAt(i) & 0xff;
        return out;
      }
      if (typeof v === 'string') return Buf.from(new TextEncoder().encode(v));
      return Buf.from(v);
    },
    concat(list) {
      const out = new Buf(list.reduce((n, b) => n + b.length, 0));
      let o = 0;
      list.forEach(b => { out.set(b, o); o += b.length; });
      return out;
    },
    isBuffer: v => v instanceof Uint8Array
  };
  function randomBytes(n) { const b = new Buf(n); window.crypto.getRandomValues(b); return b; }
  const crypto = {
    randomBytes,
    // 0 ≤ 結果 < max，沒有偏差（超出能整除的範圍就重抽）
    randomInt(max) {
      const limit = Math.floor(0x100000000 / max) * max, u = new Uint32Array(1);
      do { window.crypto.getRandomValues(u); } while (u[0] >= limit);
      return u[0] % max;
    },
    // 與 Node 的預設參數相同（N=16384, r=8, p=1）：Pi 上存的密碼雜湊搬過來也對得上
    scryptSync(password, salt, keylen) {
      const enc = s => typeof s === 'string' ? new TextEncoder().encode(s) : s;
      return Buf.from(window.scrypt.syncScrypt(enc(password), enc(salt), 16384, 8, 1, keylen));
    },
    timingSafeEqual(a, b) {
      if (a.length !== b.length) throw new RangeError('Input buffers must have the same byte length');
      let d = 0;
      for (let i = 0; i < a.length; i++) d |= a[i] ^ b[i];
      return d === 0;
    }
  };

  // ── ws：WebSocket 伺服器（連線來自同一頁的 LocalSocket，見 boot.js）──
  class FakeWsServer extends Emitter {
    constructor() { super(); this.clients = new Set(); H.wss = this; }
  }
  const ws = { Server: FakeWsServer, CONNECTING: 0, OPEN: 1, CLOSING: 2, CLOSED: 3 };

  // ── express／http：只記下路由，boot.js 的 fetch 轉接過來 ──
  function express() {
    const app = function () {};
    app.use = () => app;
    app.get = (p, fn) => { H.routes.GET[p] = fn; return app; };
    app.post = (p, fn) => { H.routes.POST[p] = fn; return app; };
    return app;
  }
  express.static = () => null;
  express.json = () => null;
  const http = { createServer: () => ({ listen(port, host, cb) { setTimeout(typeof host === 'function' ? host : cb, 0); } }) };

  // ── net：出單機走 Wi-Fi 的偵測用不到（印表機都接在平板的 USB 上），一律連不上 ──
  // 2026-11-05：receipt.js 在 USB 剛好斷線的那一刻會改走 Wi-Fi（new net.Socket()）。以前這裡沒有 Socket，
  // 會直接丟「net.Socket is not a constructor」、不再重試；現在一樣「連不上」，receipt.js 就會照常等一下再重試，
  // 重試時出單機 USB 接回來了就照印
  const deadSocket = () => {
    const s = new Emitter();
    s.setTimeout = () => s;
    s.destroy = () => {};
    s.end = () => {};
    s.write = (b, cb) => { if (typeof cb === 'function') setTimeout(cb, 0); return false; };
    s.connect = () => { setTimeout(() => s.emit('error', new Error('平板上沒有 Wi-Fi 出單機（出單機 USB 沒接上）')), 0); return s; };
    return s;
  };
  function Socket() { return deadSocket(); }
  const net = {
    Socket,
    connect() { return deadSocket().connect(); }
  };

  // ── child_process ──
  //   timedatectl（對時檢查）：平板的時間由 Android 校正，一律當作已對時
  //   python3 label-render.py（畫貼紙）：改用 host/label-render.js（canvas），stdin 一樣是 JSON、輸出一樣是 TSPL 位元組
  //   python3 build-report.py（完整報表）：改用 host/report-build.js，一樣寫出 report.html（在 /data，App 從那裡提供）
  const child_process = {
    execFile(cmd, args, opts, cb) {
      if (typeof opts === 'function') cb = opts;
      const child = new Emitter();
      let input = '';
      const script = String((args && args[0]) || '');
      child.stdin = new Emitter();
      child.stdin.write = s => { input += s; return true; };
      child.stdin.end = s => {
        if (s != null) input += s;
        setTimeout(() => {
          if (cmd === 'python3' && /label-render\.py$/.test(script) && window.ZaokaLabel) {
            // 貼紙機剛開機（App 1.8.0 起的 PosUsb.fresh）：這一批的第一張往上挪 1.5 mm（12 點，203 dpi），見 label-render.js 的 tspl
            try {
              const data = JSON.parse(input || '{}');
              try { if (window.PosUsb && typeof window.PosUsb.fresh === 'function' && window.PosUsb.fresh('label')) data.liftFirst = LABEL_FRESH_LIFT; } catch (e) {}
              cb(null, Buf.from(window.ZaokaLabel.render(data)), '');
            }
            catch (e) { cb(e, null, String(e.message || e)); }
          } else if (cmd === 'python3' && /receipt-render\.py$/.test(script) && window.ZaokaReceipt) {
            try { cb(null, Buf.from(window.ZaokaReceipt.render(JSON.parse(input || '{}'))), ''); }
            catch (e) { cb(e, null, String(e.message || e)); }
          } else if (cmd === 'python3' && /build-report\.py$/.test(script) && window.ZaokaReport) {
            window.ZaokaReport.run(fs).then(msg => cb(null, msg, ''), e => cb(e, '', String(e.message || e)));
          } else {
            cb(new Error(cmd + ' ' + script + ' 在平板上不能執行'), null, '');
          }
        }, 0);
      };
      child.kill = () => {};
      if (cmd === 'timedatectl') setTimeout(() => cb(null, 'yes\n', ''), 0);
      else if (!(cmd === 'python3' && /(label|receipt)-render\.py$/.test(script))) setTimeout(() => child.stdin.end(), 0);
      return child;
    }
  };

  // ── 計時器：server.js 對 setInterval 的結果呼叫 .unref()（Node 才有），包一層 ──
  function hostSetInterval(fn, ms) {
    const id = window.setInterval(fn, ms);
    return { unref() { return this; }, ref() { return this; }, [Symbol.toPrimitive]() { return id; } };
  }

  const process = { env: {} };
  const builtins = { fs, path, crypto, ws, express, http, net, child_process };

  function require(name) {
    const key = String(name).replace(/^\.\//, '').replace(/\.js$/, '');
    if (builtins[key]) return builtins[key];
    if (cache[key]) return cache[key].exports;
    const def = defs[key];
    if (!def) throw new Error('店內主機找不到模組 ' + name);
    const module = cache[key] = { exports: {} };
    def(require, module, module.exports, '/data', '/data/' + key + '.js', process, hostSetInterval, Buffer, hostConsole);
    return module.exports;
  }

  H.define = (name, fn) => { defs[name] = fn; };
  H.require = require;
  // 啟動店內主機（boot.js 呼叫）：跑 server.js，它會建立 WebSocket 伺服器、讀今天的訂單
  H.start = () => require('server');
})();
