// 灶咖點餐（平板當主機）：啟動店內主機，並把點餐頁對外的兩條路接到它身上。
//   1. WebSocket：點餐頁原本 new WebSocket('ws://Pi:3000')，這裡換成 LocalSocket，
//      訊息直接交給同一頁裡的 server.js（runtime.js 的假 ws 伺服器），格式完全一樣
//   2. fetch('/api/…')：交給 server.js 用 express 寫的路由（列印結帳單、重算報表）
// 點餐頁本身幾乎不用改：它以為自己還連著一台伺服器。
// 只在 App 裡（runtime.js 判斷有 window.PosFs）才動作；在別的地方打開點餐頁時什麼都不做。
(function () {
  'use strict';
  const H = window.ZaokaHost;
  if (!H || !H.active) return;

  try {
    H.start();
  } catch (e) {
    H.startError = e;
    console.error('[主機] 啟動失敗', e);
  }

  // 告訴 App「點餐頁起來了」：熱更新剛換的新版要在時限內回報，否則 App 退回上一版（HotUpdate.kt）。
  // 條件：店內主機沒出錯、頁面載入完、點餐頁也連上了店內主機
  window.addEventListener('load', () => {
    if (H.startError || !window.PosApp || typeof window.PosApp.ready !== 'function') return;
    const t0 = Date.now();
    (function wait() {
      if (typeof isOnline === 'function' && isOnline()) { try { window.PosApp.ready(); } catch (e) {} return; }
      if (Date.now() - t0 < 15000) setTimeout(wait, 200);
    })();
  });

  const NativeWebSocket = window.WebSocket;
  const later = fn => setTimeout(fn, 0);   // 跟真的網路一樣「晚一點才到」，順序不變

  // ── 主機那一端的連線（server.js 看到的 ws）──
  class ServerSide {
    constructor(page) { this.page = page; this.readyState = 1; this._ev = {}; }
    on(name, fn) { (this._ev[name] = this._ev[name] || []).push(fn); return this; }
    emit(name, ...a) { (this._ev[name] || []).slice().forEach(f => { try { f(...a); } catch (e) { console.error('[主機]', e); } }); }
    send(text) {
      if (this.readyState !== 1) return;
      const page = this.page;
      later(() => page._receive(String(text)));
    }
    close() { this.page.close(); }
  }

  // ── 點餐頁那一端（取代 window.WebSocket）──
  class LocalSocket {
    constructor(url) {
      this.url = String(url);
      this.readyState = LocalSocket.CONNECTING;
      this.onopen = this.onmessage = this.onclose = this.onerror = null;
      this._ls = {};
      later(() => this._open());
    }
    _open() {
      if (this.readyState !== LocalSocket.CONNECTING) return;
      if (!H.wss || H.startError) {            // 主機沒起來：當作連不上，點餐頁會顯示紅燈並自己重試
        this.readyState = LocalSocket.CLOSED;
        this._fire('error', {});
        this._fire('close', { code: 1006, reason: 'host not running', wasClean: false });
        return;
      }
      this.server = new ServerSide(this);
      this.readyState = LocalSocket.OPEN;
      this._fire('open', {});
      H.wss.clients.add(this.server);
      H.wss.emit('connection', this.server, { socket: { remoteAddress: 'tablet' } });
    }
    send(text) {
      if (this.readyState !== LocalSocket.OPEN) throw new Error('LocalSocket is not open');
      const server = this.server;
      later(() => server.emit('message', String(text)));
    }
    close() {
      if (this.readyState === LocalSocket.CLOSED) return;
      const wasOpen = this.readyState === LocalSocket.OPEN;
      this.readyState = LocalSocket.CLOSED;
      if (this.server) {
        this.server.readyState = 3;
        H.wss.clients.delete(this.server);
        if (wasOpen) this.server.emit('close');
      }
      later(() => this._fire('close', { code: 1000, reason: '', wasClean: true }));
    }
    _receive(text) { if (this.readyState === LocalSocket.OPEN) this._fire('message', { data: text }); }
    addEventListener(name, fn) { (this._ls[name] = this._ls[name] || []).push(fn); }
    removeEventListener(name, fn) { this._ls[name] = (this._ls[name] || []).filter(f => f !== fn); }
    _fire(name, ev) {
      const h = this['on' + name];
      try { if (h) h.call(this, ev); } catch (e) { console.error(e); }
      (this._ls[name] || []).slice().forEach(f => { try { f.call(this, ev); } catch (e) { console.error(e); } });
    }
  }
  LocalSocket.CONNECTING = 0; LocalSocket.OPEN = 1; LocalSocket.CLOSING = 2; LocalSocket.CLOSED = 3;

  // 只接管連往自己（點餐頁的主機）的連線；其他網址照用真的 WebSocket
  window.WebSocket = function (url, protocols) {
    let host = '';
    try { host = new URL(url, location.href).hostname; } catch (e) {}
    if (host === location.hostname) return new LocalSocket(url);
    return new NativeWebSocket(url, protocols);
  };
  Object.assign(window.WebSocket, { CONNECTING: 0, OPEN: 1, CLOSING: 2, CLOSED: 3 });

  // ── fetch('/api/…') → server.js 的 express 路由 ──
  const nativeFetch = window.fetch.bind(window);
  window.fetch = function (input, init) {
    let url;
    try { url = new URL(typeof input === 'string' ? input : input.url, location.href); } catch (e) { return nativeFetch(input, init); }
    const method = String((init && init.method) || (input && input.method) || 'GET').toUpperCase();
    const route = url.origin === location.origin && H.routes[method] && H.routes[method][url.pathname];
    if (!route) return nativeFetch(input, init);
    return new Promise(resolve => {
      let status = 200;
      let body = null;
      try { body = init && typeof init.body === 'string' ? JSON.parse(init.body) : null; } catch (e) { body = null; }
      const res = {
        status(code) { status = code; return res; },
        json(obj) { resolve(new Response(JSON.stringify(obj), { status, headers: { 'Content-Type': 'application/json' } })); },
        send(text) { resolve(new Response(String(text), { status })); },
        sendFile() { resolve(new Response('', { status: 404 })); }
      };
      try {
        const r = route({ body, hostname: location.hostname, query: Object.fromEntries(url.searchParams) }, res);
        if (r && typeof r.catch === 'function') r.catch(e => { console.error('[主機]', e); res.status(500).json({ ok: false, error: String(e.message || e) }); });
      } catch (e) {
        console.error('[主機]', e);
        res.status(500).json({ ok: false, error: String(e.message || e) });
      }
    });
  };
})();
