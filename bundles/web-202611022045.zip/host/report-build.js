// 營業分析報表（完整報表）——平板版（2026-11-01）。
//
// Pi 上的 deploy/build-report.py 逐行移植：把 /data/orders/*.json 彙整成精簡的統計資料，
// 嵌進 report-template.html（原樣沿用，打包在 host/ 裡），存成 /data/report.html。
// 點餐頁的「完整報表」照舊：POST /api/rebuild-report（server.js 呼叫 python3 build-report.py →
// runtime.js 轉到這裡）→ 報表框打開 report.html（App 的 WebBundle 從資料夾拿這個檔案）。
// 只讀訂單，不修改任何原始資料。
(function () {
  'use strict';

  const CUTOFF_HOUR = 4;        // 營業日凌晨 4 點換日（與 build-report.py、報表樣板一致）

  const VOCAB = {
    size: ['大杯', '中杯'],
    sugar: ['正糖', '標糖', '全糖', '正常糖', '半糖', '微糖', '無糖'],
    ice: ['正冰', '標冰', '全冰', '正常冰', '少冰', '微冰', '去冰'],
    temp: ['熱', '溫', '常溫']
  };
  const LEGACY = { '正常糖': '正糖', '全糖': '正糖', '標糖': '正糖', '正常冰': '正冰', '全冰': '正冰', '標冰': '正冰' };

  function opt(item, key) {
    const o = item.options;
    if (o && typeof o === 'object' && !Array.isArray(o) && o[key]) return LEGACY[o[key]] || o[key];
    for (let part of String(item.attrs || '').split('・')) {
      part = part.trim();
      if (VOCAB[key].includes(part)) return LEGACY[part] || part;
    }
    return '';
  }

  function cupsOf(order) {
    const n = order.cups;
    if (Number.isInteger(n) && n > 0) return n;
    return (order.items || []).filter(i => !i.bag).reduce((s, i) => s + (i.qty || 0), 0);
  }

  const isDigits = s => /^\d+$/.test(s);
  function bizMinute(localTime) {
    const s = String(localTime || '');
    if (!(isDigits(s.slice(11, 13)) && isDigits(s.slice(14, 16)))) return null;
    return (((parseInt(s.slice(11, 13), 10) - CUTOFF_HOUR) % 24 + 24) % 24) * 60 + parseInt(s.slice(14, 16), 10);
  }

  const pad = n => String(n).padStart(2, '0');
  const ymd = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  function shift(date, days) {
    const [y, m, d] = date.split('-').map(Number);
    return new Date(Date.UTC(y, m - 1, d + days)).toISOString().slice(0, 10);
  }
  const counter = () => Object.create(null);
  const plain = c => Object.assign({}, c);

  // fs：runtime.js 的 fs（讀 /data/orders）
  function build(fs, ordersDir) {
    const names = [], idx = new Map(), days = [];
    const now = new Date();
    const today = ymd(now.getHours() < CUTOFF_HOUR ? new Date(now.getTime() - 86400000) : now);
    const cut = (((now.getHours() - CUTOFF_HOUR) % 24 + 24) % 24) * 60 + now.getMinutes();
    const cmpDates = new Set([shift(today, -1), shift(today, -7)]);
    const cutDays = {};

    let files = [];
    try { files = fs.readdirSync(ordersDir).filter(f => /\.json$/.test(f)).sort(); } catch (e) { files = []; }
    files.forEach(f => {
      let raw;
      try { raw = JSON.parse(fs.readFileSync(ordersDir + '/' + f, 'utf8')); }
      catch (e) { console.warn('[報表] 略過 ' + f + '：' + e.message); return; }
      const date = raw.businessDate || f.slice(0, -5);
      if (!raw.orders || !raw.orders.length) return;
      const orders = raw.orders.filter(o => !o.canceled);
      if (cmpDates.has(date)) {
        const early = orders.filter(o => bizMinute(o.localTime) != null && bizMinute(o.localTime) <= cut);
        cutDays[date] = [early.length, early.reduce((s, o) => s + cupsOf(o), 0), early.reduce((s, o) => s + (o.total || 0), 0)];
      }
      const items = new Map();                                   // 品名 → [杯數, 金額]
      const attrs = { sz: counter(), sg: counter(), ic: counter(), tp: counter() };
      const hours = new Map();                                   // 小時 → [訂單, 杯數, 金額]
      const eco = counter();
      orders.forEach(o => {
        const hh = String(o.localTime || '').slice(11, 13);
        if (isDigits(hh)) {
          const h = hours.get(hh) || [0, 0, 0];
          h[0] += 1; h[1] += cupsOf(o); h[2] += o.total || 0;
          hours.set(hh, h);
        }
        (o.items || []).forEach(it => {
          if (it.bag) return;
          const qty = it.qty || 0, name = it.name || '?';
          const row = items.get(name) || [0, 0];
          row[0] += qty; row[1] += qty * (it.price || 0);
          items.set(name, row);
          [['size', 'sz'], ['sugar', 'sg'], ['ice', 'ic'], ['temp', 'tp']].forEach(([key, short]) => {
            const v = opt(it, key);
            if (v) attrs[short][v] = (attrs[short][v] || 0) + qty;
          });
          if (it.eco && !it.deposit) {
            const k = it.ecoMode === 'nowash' ? '直接裝' : '要洗';
            eco[k] = (eco[k] || 0) + qty;
          }
        });
      });
      const itList = [...items.entries()].sort((a, b) => b[1][0] - a[1][0]).map(([name, [cups, amt]]) => {
        if (!idx.has(name)) { idx.set(name, names.length); names.push(name); }
        return [idx.get(name), cups, amt];
      });
      const hr = {};
      [...hours.keys()].sort().forEach(k => { hr[k] = hours.get(k); });
      days.push({
        d: date, o: orders.length,
        c: orders.reduce((s, o) => s + cupsOf(o), 0),
        r: orders.reduce((s, o) => s + (o.total || 0), 0),
        it: itList,
        sz: plain(attrs.sz), sg: plain(attrs.sg), ic: plain(attrs.ic), tp: plain(attrs.tp), ec: plain(eco),
        hr
      });
    });
    return {
      generated: ymd(now) + ' ' + pad(now.getHours()) + ':' + pad(now.getMinutes()),
      today, items: names, days, cut: { m: cut, days: cutDays }
    };
  }

  let template = null;
  // 產生 /data/report.html。回傳 Promise<訊息>；沒有訂單時 reject（跟 build-report.py 回傳 1 一樣）
  async function run(fs) {
    if (!template) {
      const r = await fetch('host/report-template.html', { cache: 'no-store' });
      if (!r.ok) throw new Error('找不到報表樣板');
      template = await r.text();
    }
    const data = build(fs, '/data/orders');
    if (!data.days.length) throw new Error('找不到訂單資料');
    if (!template.includes('/*__DATA__*/')) throw new Error('模板缺少 /*__DATA__*/ 佔位符');
    const blob = JSON.stringify(data).replace(/<\//g, '<\\/');
    const html = template.replace('/*__DATA__*/', () => blob);
    fs.writeFileSync('/data/report.html.tmp', html);
    fs.renameSync('/data/report.html.tmp', '/data/report.html');
    return data.days.length + ' 個營業日、' + data.items.length + ' 種品項';
  }

  window.ZaokaReport = { build, run };
})();
