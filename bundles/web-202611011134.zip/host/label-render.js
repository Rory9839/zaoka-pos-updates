// 貼紙繪圖（35 × 25 mm / 203dpi = 280 × 200 dot）——平板版（2026-11-01）。
//
// 這是 Pi 上 label-render.py 的逐行移植：同一套版面數字、同一套縮字／換行／上下定位規則，
// 只是改用網頁的 canvas 畫（字型是 Android 內建的思源黑體，跟 Pi 上的 Noto Sans CJK 同一套字），
// 畫完轉成黑白點陣，用 TSPL 的 BITMAP 送出。
//   ZaokaLabel.render({ labels: [...] }) → Uint8Array（整串 TSPL），labels 的格式跟 label-render.py 的 stdin 一樣
// 寄杯券的 QR code 請貼紙機自己畫（TSPL 的 QRCODE 指令）：label-render.py 在沒有 python3-qrcode 時本來就走這條路，位置一樣。
// 「小心燙口」直條 2026-10-29 已取消（printer.js 一律送 hot:false），這裡沒有移植。
//
// 版面數字不要隨意更動（2026-09-20、10-29 與 Rory 逐張比對實體貼紙後定案，見 label-render.py）。
(function () {
  'use strict';

  const W = 280, H = 200;
  const LEFT = 10;
  const RIGHT0 = 252;
  const FIT_MARGIN = 32;
  const PLACE_TOP = 30, BOTTOM_KEEP = 12;
  const SHIFT_X = 0;
  const PX_SEQ = 38, PX_CUP = 30, PX_BAG = 26, PX_NAME = 46, PX_ATTR = 30;
  const NAME_OVER_ATTR = 6;
  const PX_MIX = 24;
  const BAG_LIFT = 3;
  const CAKE_W = 1.15;
  const QR_CELL = 5, QR_SIZE = 21 * QR_CELL;
  const FONT_FAMILY = '"Noto Sans CJK TC", "Noto Sans TC", "Microsoft JhengHei", sans-serif';

  // ── 畫布：白底、黑字；量字、找墨跡、搬移都在這裡 ──
  class Img {
    constructor(w, h) {
      this.w = w; this.h = h;
      this.c = document.createElement('canvas');
      this.c.width = w; this.c.height = h;
      this.c.lang = 'zh-TW';
      this.g = this.c.getContext('2d', { willReadFrequently: true });
      this.g.fillStyle = '#fff';
      this.g.fillRect(0, 0, w, h);
      this.g.textBaseline = 'alphabetic';
      this.g.textAlign = 'left';
    }
    _font(px) { this.g.font = 'bold ' + px + 'px ' + FONT_FAMILY; }
    len(text, px) { this._font(px); return this.g.measureText(text).width; }
    // Pillow 的 textbbox((x, y), text)：(x, y) 是字的左上（上緣＝字型的 ascender）
    bbox(x, y, text, px) {
      this._font(px);
      const m = this.g.measureText(text);
      const base = y + m.fontBoundingBoxAscent;
      return [x - m.actualBoundingBoxLeft, base - m.actualBoundingBoxAscent, x + m.actualBoundingBoxRight, base + m.actualBoundingBoxDescent];
    }
    text(x, y, text, px, white) {
      this._font(px);
      const m = this.g.measureText(text);
      this.g.fillStyle = white ? '#fff' : '#000';
      this.g.fillText(text, x, y + m.fontBoundingBoxAscent);
    }
    // Pillow 的 rectangle([x0, y0, x1, y1])：兩端都包含
    rect(b, white) {
      this.g.fillStyle = white ? '#fff' : '#000';
      this.g.fillRect(b[0], b[1], b[2] - b[0] + 1, b[3] - b[1] + 1);
    }
    rectOutline(b, width) {
      const [x0, y0, x1, y1] = b;
      this.rect([x0, y0, x1, y0 + width - 1]);
      this.rect([x0, y1 - width + 1, x1, y1]);
      this.rect([x0, y0, x0 + width - 1, y1]);
      this.rect([x1 - width + 1, y0, x1, y1]);
    }
    ellipse(b, white) {
      const g = this.g;
      g.fillStyle = white ? '#fff' : '#000';
      g.beginPath();
      g.ellipse((b[0] + b[2]) / 2, (b[1] + b[3]) / 2, Math.max(0.5, (b[2] - b[0]) / 2), Math.max(0.5, (b[3] - b[1]) / 2), 0, 0, Math.PI * 2);
      g.fill();
    }
    // 墨跡範圍 [x0, y0, x1, y1)（跟 Pillow 的 getbbox 一樣右下不含）；全白回傳 null
    ink() {
      const d = this.g.getImageData(0, 0, this.w, this.h).data;
      let x0 = this.w, y0 = this.h, x1 = -1, y1 = -1;
      for (let y = 0; y < this.h; y++) {
        for (let x = 0; x < this.w; x++) {
          if (d[(y * this.w + x) * 4] < 128) {
            if (x < x0) x0 = x; if (x > x1) x1 = x;
            if (y < y0) y0 = y; if (y > y1) y1 = y;
          }
        }
      }
      return x1 < 0 ? null : [x0, y0, x1 + 1, y1 + 1];
    }
    // 把 src 的 (sx, sy, sw, sh) 貼到 (dx, dy)
    paste(src, sx, sy, sw, sh, dx, dy) {
      if (sw <= 0 || sh <= 0) return;
      this.g.drawImage(src.c, sx, sy, sw, sh, dx, dy, sw, sh);
    }
    // 黑白點陣：每列 ceil(W/8) 位元組、最高位在左、1＝白（跟 Pillow 的 '1' 模式 tobytes() 一樣，TSPL BITMAP 用）
    bits() {
      const d = this.g.getImageData(0, 0, this.w, this.h).data;
      const wb = (this.w + 7) >> 3, out = new Uint8Array(wb * this.h);
      for (let y = 0; y < this.h; y++) {
        for (let x = 0; x < wb * 8; x++) {
          const white = x >= this.w || d[(y * this.w + x) * 4] >= 128;
          if (white) out[y * wb + (x >> 3)] |= 0x80 >> (x & 7);
        }
      }
      return out;
    }
  }

  // 太寬就一級一級縮（fit），R＝右緣
  function fit(img, text, start, min, R) {
    let px = start;
    while (px > min && img.len(text, px) > (R - LEFT)) px -= 2;
    return px;
  }

  // 放不下一行時換行：優先在「、」後面斷開，單一段太長才逐字斷
  function wrapLines(img, text, px, maxw) {
    const parts = []; let buf = '';
    for (const ch of text) { buf += ch; if (ch === '、') { parts.push(buf); buf = ''; } }
    if (buf) parts.push(buf);
    const lines = []; let cur = '';
    parts.forEach(p => {
      if (img.len(cur + p, px) <= maxw) { cur += p; return; }
      if (cur) lines.push(cur);
      cur = '';
      for (const ch of p) {
        if (cur && img.len(cur + ch, px) > maxw) { lines.push(cur); cur = ''; }
        cur += ch;
      }
    });
    if (cur) lines.push(cur);
    return lines;
  }

  // 生日蛋糕小圖（當日壽星那杯），底部對齊 bottom，高 s、寬 s × CAKE_W
  function drawCake(img, x, bottom, s) {
    const w = s * CAKE_W;
    const plate = Math.max(2, Math.round(s * 0.07));
    img.rect([x, bottom - plate, x + w, bottom]);
    const bTop = bottom - plate - 1 - s * 0.36;
    img.rect([x + w * 0.07, bTop, x + w * 0.93, bottom - plate - 1]);
    const r = Math.max(1.5, s * 0.055);
    for (let i = 0; i < 4; i++) {
      const cx = x + w * (0.2 + 0.2 * i);
      img.ellipse([cx - r, bTop + s * 0.1 - r, cx + r, bTop + s * 0.1 + r], true);
    }
    const gapH = Math.max(2, Math.round(s * 0.06));
    const tTop = bTop - gapH - s * 0.24;
    img.rect([x + w * 0.22, tTop, x + w * 0.78, bTop - gapH]);
    const cx = x + w / 2, half = Math.max(1, s * 0.035);
    img.rect([cx - half, tTop - s * 0.17, cx + half, tTop - 1]);
    img.ellipse([cx - s * 0.07, tTop - s * 0.34, cx + s * 0.07, tTop - s * 0.16]);
  }

  // 所有貼紙同一套上下位置：內容上緣放在 PLACE_TOP；太高就往上挪，但下緣離底邊至少 BOTTOM_KEEP。回傳 [新圖, 往下移幾 dot]
  function place(img) {
    const ink = img.ink();
    if (!ink) return [img, 0];
    const h = ink[3] - ink[1];
    const top = PLACE_TOP + h <= H - BOTTOM_KEEP ? PLACE_TOP : Math.max(4, H - BOTTOM_KEEP - h);
    const dy = top - ink[1];
    if (!dy) return [img, 0];
    const moved = new Img(W, H);
    if (dy > 0) moved.paste(img, 0, 0, W, H - dy, 0, dy);
    else moved.paste(img, 0, -dy, W, H + dy, 0, 0);
    return [moved, dy];
  }

  // ── 杯子貼紙 ──
  function draw(o, shrink, R) {
    const T = new Img(W, H * 2);
    const marks = [];
    if (o.bag) marks.push('袋' + (o.bag > 1 ? String(o.bag) : ''));
    if (o.revised) marks.push('改');
    const pad = 5;
    const markW = marks.map(t => { const b = T.bbox(0, 0, t, PX_BAG); return (b[2] - b[0]) + pad * 2 + 2; });

    const cupT = o.cups > 1 ? o.cup + '/' + o.cups : null;
    const cupBB = cupT ? T.bbox(0, 0, cupT, PX_CUP) : null;
    const cupW = cupT ? cupBB[2] - cupBB[0] : 0;
    const rightW = markW.reduce((s, w) => s + w + 10, 0) + (cupT ? cupW + 10 : 0);

    let spx = PX_SEQ;
    while (spx > 24 && T.len(o.seq, spx) > (R - LEFT - rightW - 8)) spx -= 2;
    T.text(LEFT, 10, o.seq, spx);
    const base = T.bbox(LEFT, 10, o.seq, spx)[3];
    let lowest = base;
    const cupMid = cupT ? base - (cupBB[3] - cupBB[1]) / 2 : null;

    let right = R;
    marks.forEach((t, i) => {
      const bb = T.bbox(0, 0, t, PX_BAG);
      const tw = bb[2] - bb[0], th = bb[3] - bb[1];
      const xInk = right - 1 - pad - tw;
      const inkTop = (cupT ? cupMid - th / 2 : base - th) - BAG_LIFT;
      T.text(xInk - bb[0], inkTop - bb[1], t, PX_BAG);
      const box = [xInk - pad, inkTop - pad, right - 1, inkTop + th + pad];
      T.rectOutline(box, 2);
      right = box[0] - 10;
      lowest = Math.max(lowest, box[3]);
    });
    if (cupT) T.text(right - cupW - cupBB[0], base - cupBB[3], cupT, PX_CUP);

    const sep = Math.trunc(lowest) + (shrink < 6 ? 10 : 7);
    T.rect([LEFT, sep, R - 1, sep + 2]);

    const ny = sep + (shrink < 6 ? 10 : 6);
    const gap = 8;
    const tag = o.birthday ? '生日快樂' : o.price;
    const tagW = px => {
      const ppx = Math.max(16, Math.trunc(px * 0.6));
      return gap + T.len(tag, ppx) + (o.birthday ? ppx * CAKE_W + 5 : 0);
    };
    const apxPlan = Math.max(20, PX_ATTR - shrink * 2);
    let px = Math.max(apxPlan + NAME_OVER_ATTR, PX_NAME - shrink * 2);
    while (px > 24) {
      const w = T.len(o.name, px) + (tag ? tagW(px) : 0);
      if (w <= R - LEFT) break;
      px -= 2;
    }
    const bdayOwnLine = o.birthday && px < 32;
    if (bdayOwnLine) px = fit(T, o.name, Math.max(apxPlan + NAME_OVER_ATTR, PX_NAME - shrink * 2), 24, R);
    T.text(LEFT, ny, o.name, px);
    let nb = T.bbox(LEFT, ny, o.name, px)[3];
    if (tag && !bdayOwnLine) {
      const ppx = Math.max(16, Math.trunc(px * 0.6));
      let x = LEFT + T.len(o.name, px) + gap;
      if (o.birthday) { drawCake(T, x, nb, ppx); x += ppx * CAKE_W + 5; }
      const pbb = T.bbox(0, 0, tag, ppx);
      T.text(x - pbb[0], nb - pbb[3], tag, ppx);
    }
    if (bdayOwnLine) {
      const bpx = Math.max(20, 28 - shrink);
      const bb = T.bbox(0, 0, tag, bpx);
      const lineBottom = nb + 6 + Math.max(bb[3] - bb[1], bpx);
      drawCake(T, LEFT, lineBottom, bpx);
      T.text(LEFT + bpx * CAKE_W + 6 - bb[0], lineBottom - bb[3], tag, bpx);
      nb = lineBottom;
    }

    let y = Math.trunc(nb) + (shrink < 6 ? 8 : 5);
    if (o.attrs) {
      const apx = fit(T, o.attrs, apxPlan, 20, R);
      T.text(LEFT, y, o.attrs, apx);
      y = T.bbox(LEFT, y, o.attrs, apx)[3] + 6;
    }
    const smallLine = (text, y0) => {
      let yy = y0;
      const mpx = fit(T, text, Math.max(16, PX_MIX - shrink), 16, R);
      if (T.len(text, mpx) <= R - LEFT) {
        T.text(LEFT, yy, text, mpx);
        return T.bbox(LEFT, yy, text, mpx)[3] + 4;
      }
      const wpx = shrink < 6 ? 16 : 14;
      wrapLines(T, text, wpx, R - LEFT).forEach(line => {
        T.text(LEFT, yy, line, wpx);
        yy = T.bbox(LEFT, yy, line, wpx)[3] + 3;
      });
      return yy + 1;
    };
    if (o.mix) y = smallLine(o.mix, y);
    if (o.remark) y = smallLine('備註：' + o.remark, y);
    return [T, T.ink()];
  }

  function renderCup(o) {
    let tall = null, ink = null;
    for (let shrink = 0; shrink < 16; shrink++) {
      [tall, ink] = draw(o, shrink, RIGHT0);
      if (!ink || (ink[3] - ink[1]) <= H - FIT_MARGIN) break;
    }
    let img = new Img(W, H);
    if (ink) {
      img.paste(tall, 0, ink[1], W, Math.min(ink[3] - ink[1], H), 0, 0);
      [img] = place(img);
    }
    return img;
  }

  // ── 結帳統計貼紙 ──
  function renderSummary(title, rows) {
    const T = new Img(W, H * 2);
    T.text(LEFT, 10, title, 30);
    let y = T.bbox(LEFT, 10, title, 30)[3] + 8;
    T.rect([LEFT, y, RIGHT0 - 1, y + 2]);
    y += 12;
    rows.forEach(([key, val]) => {
      T.text(LEFT, y + 6, key, 24);
      let px = 32;
      const keyW = T.len(key, 24);
      while (px > 18 && T.len(val, px) > (RIGHT0 - LEFT - keyW - 14)) px -= 2;
      T.text(RIGHT0 - T.len(val, px), y, val, px);
      y += 38;
    });
    const ink = T.ink();
    let img = new Img(W, H);
    if (ink) {
      img.paste(T, 0, ink[1], W, Math.min(ink[3] - ink[1], H), 0, 0);
      [img] = place(img);
    }
    return img;
  }

  // ── 沒有防偽代碼的寄杯貼紙（登記簿發不出代碼時才會用到）──
  function renderVoucher(store, value, note, date, serial, name) {
    const T = new Img(W, H * 2);
    const head = store + ' 寄杯券';
    const hpx = fit(T, head, 30, 20, RIGHT0);
    T.text(LEFT, 8, head, hpx);
    let y = T.bbox(LEFT, 8, head, hpx)[3] + 8;
    T.rect([LEFT, y, RIGHT0 - 1, y + 2]);
    y += 10;
    const amt = '$' + value;
    if (name) {
      const npx = fit(T, name, 40, 20, RIGHT0), nbb = T.bbox(0, 0, name, npx);
      T.text(LEFT - nbb[0], y - nbb[1], name, npx);
      y += (nbb[3] - nbb[1]) + 10;
      const apx = fit(T, amt, 56, 30, RIGHT0), abb = T.bbox(0, 0, amt, apx);
      T.text(LEFT - abb[0], y - abb[1], amt, apx);
      y += (abb[3] - abb[1]) + 10;
    } else {
      const apx = fit(T, amt, 76, 40, RIGHT0), bb = T.bbox(0, 0, amt, apx);
      T.text(LEFT + (RIGHT0 - LEFT - (bb[2] - bb[0])) / 2 - bb[0], y - bb[1], amt, apx);
      y += (bb[3] - bb[1]) + 10;
    }
    [[note, 22], [date + '  No.' + serial, 20]].forEach(([text, px]) => {
      if (!text) return;
      const tpx = fit(T, text, px, 14, RIGHT0);
      T.text(LEFT, y, text, tpx);
      y = T.bbox(LEFT, y, text, tpx)[3] + 6;
    });
    const ink = T.ink();
    let img = new Img(W, H);
    if (ink) {
      const top = ink[1], bot = Math.min(ink[3], ink[1] + H - 8);
      img.paste(T, 0, top, W, bot - top, 0, 0);
      [img] = place(img);
    }
    return img;
  }

  // ── 有防偽代碼的寄杯券、寄存券：右上 QR（印表機畫）＋代碼，左欄品名／大字／說明 ──
  function renderVoucherCoded(store, value, note, name, code, qr, title, amount) {
    const R = RIGHT0, QR_X = R - 10 - QR_SIZE, COL_W = QR_X - 8 - LEFT;
    const img = new Img(W, H);
    const extra = [];
    const head = store + ' ' + (title || '寄杯券');
    const hpx = fit(img, head, 24, 16, R), hb = img.bbox(0, 0, head, hpx);
    img.text(LEFT - hb[0], 6 - hb[1], head, hpx);
    const sep = 6 + (hb[3] - hb[1]) + 7;
    img.rect([LEFT, sep, R - 1, sep + 2]);
    const top = sep + 9;

    const safeQr = String(qr).split('').filter(ch => /[A-Za-z0-9:]/.test(ch)).join('');
    extra.push('QRCODE ' + QR_X + ',' + top + ',M,' + QR_CELL + ',A,0,"' + safeQr + '"');
    let cpx = 24;
    while (cpx > 16 && img.len(code, cpx) > QR_SIZE) cpx -= 2;
    const cb = img.bbox(0, 0, code, cpx);
    img.text(QR_X + (QR_SIZE - (cb[2] - cb[0])) / 2 - cb[0], top + QR_SIZE + 6 - cb[1], code, cpx);

    const colFit = (text, start, min) => { let px = start; while (px > min && img.len(text, px) > COL_W) px -= 2; return px; };
    const nameRows = (nm, maxPx) => {
      const rows = [...nm].length <= 5 ? [nm] : [[...nm].slice(0, 4).join(''), [...nm].slice(4).join('')];
      for (let px = maxPx; px > 15; px -= 2) if (rows.every(r => img.len(r, px) <= COL_W)) return [px, rows];
      return [16, rows];
    };
    const amt = amount || ('$' + value);
    const notes = String(note).split('，').filter(Boolean);
    const BOTTOM = H - 22;
    const inkH = (text, px) => { const b = img.bbox(0, 0, text, px); return b[3] - b[1]; };
    const plan = shrink => {
      const rows = [];
      if (name) {
        const [px, names] = nameRows(name, 34 - shrink);
        names.forEach((r, k) => rows.push([r, px, k === names.length - 1 ? 9 : 5]));
      }
      rows.push([amt, colFit(amt, (name ? 50 : 60) - shrink, 24), 10]);
      notes.forEach(p => rows.push([p, colFit(p, 20, 14), 4]));
      return [rows, rows.reduce((s, [t, px, g]) => s + inkH(t, px) + g, 0)];
    };
    let shrink = 0;
    let [rows, total] = plan(shrink);
    while (top + total > BOTTOM && shrink < 20) { shrink += 2; [rows, total] = plan(shrink); }
    let y = top;
    rows.forEach(([text, px, gapAfter]) => {
      const b = img.bbox(0, 0, text, px);
      img.text(LEFT - b[0], y - b[1], text, px);
      y += (b[3] - b[1]) + gapAfter;
    });
    const [moved, dy] = place(img);
    const fixed = dy ? extra.map(e => e.startsWith('QRCODE') ? 'QRCODE ' + QR_X + ',' + (top + dy) + ',' + e.split(',').slice(2).join(',') : e) : extra;
    return [moved, fixed];
  }

  // ── TSPL ──
  const ascii = s => { const b = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) b[i] = s.charCodeAt(i) & 0x7f; return b; };
  function tspl(img, extra) {
    const parts = [];
    const line = s => parts.push(ascii(s + '\r\n'));
    line('SIZE 35 mm,25 mm');
    line('GAP 2 mm,0 mm');
    line('DIRECTION 1');
    line('REFERENCE ' + SHIFT_X + ',0');
    line('CLS');
    parts.push(ascii('BITMAP 0,0,' + ((W + 7) >> 3) + ',' + H + ',0,'));
    parts.push(img.bits());
    parts.push(ascii('\r\n'));
    (extra || []).forEach(line);
    line('PRINT 1,1');
    return parts;
  }
  function concat(parts) {
    const n = parts.reduce((s, p) => s + p.length, 0), out = new Uint8Array(n);
    let o = 0;
    parts.forEach(p => { out.set(p, o); o += p.length; });
    return out;
  }

  // 對外：label-render.py 的 main()
  function render(data) {
    const labels = (data && data.labels) || [];
    if (!labels.length) throw new Error('沒有要印的標籤');
    const parts = [];
    labels.forEach(L => {
      const s = v => (v == null ? '' : String(v));
      if (L.kind === 'summary') {
        parts.push(...tspl(renderSummary(s(L.title || '結帳'), (L.rows || []).map(r => [s(r[0]), s(r[1])]))));
      } else if (L.kind === 'voucher' && L.code) {
        const [img, extra] = renderVoucherCoded(s(L.store), parseInt(L.value, 10) || 0, s(L.note), s(L.name),
          s(L.code), s(L.qr || L.code), s(L.head), s(L.amt));
        parts.push(...tspl(img, extra));
      } else if (L.kind === 'voucher') {
        parts.push(...tspl(renderVoucher(s(L.store), parseInt(L.value, 10) || 0, s(L.note), s(L.date), s(L.serial), s(L.name))));
      } else {
        parts.push(...tspl(renderCup({
          seq: s(L.seq), name: s(L.name), attrs: s(L.attrs), cup: parseInt(L.cup, 10) || 1, cups: parseInt(L.cups, 10) || 1,
          bag: parseInt(L.bag, 10) || 0, revised: !!L.revised, price: s(L.price), mix: s(L.mix), remark: s(L.remark),
          birthday: !!L.birthday
        })));
      }
    });
    return concat(parts);
  }

  // 預覽用（測試、之後的設定畫面）：每張貼紙的 canvas
  function preview(data) {
    return ((data && data.labels) || []).map(L => {
      if (L.kind === 'summary') return renderSummary(String(L.title || '結帳'), L.rows || []).c;
      if (L.kind === 'voucher' && L.code) {
        const [img, extra] = renderVoucherCoded(String(L.store || ''), parseInt(L.value, 10) || 0, String(L.note || ''), String(L.name || ''),
          String(L.code), String(L.qr || L.code), String(L.head || ''), String(L.amt || ''));
        // 預覽時把 QR 的位置框出來（實際由印表機畫）
        const m = /^QRCODE (\d+),(\d+)/.exec(extra[0] || '');
        if (m) img.rectOutline([+m[1], +m[2], +m[1] + QR_SIZE - 1, +m[2] + QR_SIZE - 1], 3);
        return img.c;
      }
      if (L.kind === 'voucher') return renderVoucher(String(L.store || ''), parseInt(L.value, 10) || 0, String(L.note || ''), String(L.date || ''), String(L.serial || ''), String(L.name || '')).c;
      return renderCup({ seq: String(L.seq || ''), name: String(L.name || ''), attrs: String(L.attrs || ''), cup: L.cup || 1, cups: L.cups || 1,
        bag: L.bag || 0, revised: !!L.revised, price: String(L.price || ''), mix: String(L.mix || ''), remark: String(L.remark || ''), birthday: !!L.birthday }).c;
    });
  }

  window.ZaokaLabel = { render, preview, W, H };
})();
