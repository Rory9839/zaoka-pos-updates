// 灶咖點餐（平板當主機）：出單機還沒接（2026-11-01 Rory：先設定貼紙機，出單機不在身邊）。
// 取代 Pi 上的 receipt.js，介面一樣，但什麼都不印；標題列的出單機燈號會是紅的。
// 貼紙機用的是原本的 printer.js（runtime.js 把 /dev/juicebar-label 換成 USB、Python 繪圖換成 host/label-render.js）。
(function () {
  if (!window.ZaokaHost || !window.ZaokaHost.active) return;
  const H = window.ZaokaHost;

  H.define('receipt', function (require, module) {
    module.exports = {
      PORT: 9100,
      configure() {},
      usbPresent: () => false,
      printerHost: () => '',
      printReceipt: async () => null,          // null＝畫不出來（測試列印會顯示「收據畫不出來」）
      printSummaryReceipt: async () => ({ ok: false, reason: '平板版的出單機還沒接上' })
    };
  });
})();
