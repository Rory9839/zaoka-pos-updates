// 貼紙繪圖（35 × 25 mm / 203dpi = 280 × 200 dot）——平板版（2026-11-01）。
//
// 這是 Pi 上 label-render.py 的逐行移植：同一套版面數字、同一套縮字／換行／上下定位規則，
// 只是改用網頁的 canvas 畫（字型是 Android 內建的思源黑體，跟 Pi 上的 Noto Sans CJK 同一套字），
// 畫完轉成黑白點陣，用 TSPL 的 BITMAP 送出。
//   ZaokaLabel.render({ labels: [...] }) → Uint8Array（整串 TSPL），labels 的格式跟 label-render.py 的 stdin 一樣
// 寄杯券的 QR code 請貼紙機自己畫（TSPL 的 QRCODE 指令）：label-render.py 在沒有 python3-qrcode 時本來就走這條路，位置一樣。
// 「小心燙口」直條 2026-10-29 已取消（printer.js 一律送 hot:false），這裡沒有移植。
//
// 版面數字不要隨意更動（2026-09-20、10-29 與 Rory 逐張比對實體貼紙後定案，見 label-render.py）。
// 2026-11-02 起跟 label-render.py 不一樣了：哥哥的貼紙右上角有預印 logo，橫線固定在 0.8 cm（見 LOGO_X0／LINE_Y）。
// Pi 已經退役，label-render.py 沒有跟著改。
(function () {
  'use strict';

  const W = 280, H = 200;
  const LEFT = 10;
  const RIGHT0 = 252;
  const BOTTOM_KEEP = 12;              // 最下面留白（2026-11-02 起位置固定：橫線、logo，不再整塊上下搬）
  const SHIFT_X = 0;
  // 杯數 30→24（2026-11-02 Rory：單號右邊的 1/3 小一點）；單號 38→32（2026-11-04 Rory：橫線往上 1 mm、單號小一點）
  const CUP_LEFT = 16;         // 杯數（2/3）的右緣比 logo 前面再往左 16 dot（約 2 mm）
  const PX_SEQ = 32, PX_CUP = 24, PX_BAG = 26, PX_NAME = 46, PX_ATTR = 30;
  const NAME_OVER_ATTR = 6;
  const PX_MIX = 24;
  const CAKE_W = 1.15;
  // QR 21×21 格 × 每格 4 dot＝84 dot≈10.5 mm（2026-11-03 Rory：調回前一晚試過的 10.5 mm；QR＋下面的代碼在線下面上下置中）
  const QR_CELL = 4, QR_SIZE = 21 * QR_CELL;
  // 2026-11-02 Rory：哥哥店裡的貼紙右上角預印了 logo（寬約 1.5 cm、高約 0.6 cm）→ 那一塊什麼都不印；
  // 橫線固定在離上緣約 0.8 cm。203dpi＝每 mm 8 dot。logo 四周再多留 1 mm（貼紙機送紙會有一點誤差）。
  // 線上面只放「單號、杯數、袋／改」（都往左靠，右邊停在 logo 前面），線下面照舊用整個寬度。
  // 要微調：改這三個數字就好（單位 dot，8 dot＝1 mm）
  const LOGO_X0 = W - 15 * 8 - 8;     // logo 左緣（再往左留 1 mm）＝152
  const LOGO_Y1 = 6 * 8 + 8;          // logo 下緣（再往下留 1 mm）＝56
  const LINE_Y = 7 * 8;               // 橫線上緣＝56（線粗 3 dot）；2026-11-04 Rory：從 0.8 cm 再往上 1 mm
  const HEAD_R = LOGO_X0 - 4;         // 線上面的字，右邊最多到這裡
  const HEAD_GAP = 8;                 // 線上面的字，底部離線多遠
  const BODY_TOP = LINE_Y + 3 + 8;    // 線下面的內容從這裡開始
  const FONT_FAMILY = '"Noto Sans CJK TC", "Noto Sans TC", "Microsoft JhengHei", sans-serif';

  // ── 畫布：白底、黑字；量字、找墨跡、搬移都在這裡 ──
  class Img {
    constructor(w, h) {
      this.w = w; this.h = h;
      this.c = document.createElement('canvas');
      this.c.width = w; this.c.height = h;
      this.c.lang = 'zh-TW';
      this.g = this.c.getContext('2d', { willReadFrequently: true });
      this.g.fillStyle = '#fff';
      this.g.fillRect(0, 0, w, h);
      this.g.textBaseline = 'alphabetic';
      this.g.textAlign = 'left';
    }
    _font(px) { this.g.font = 'bold ' + px + 'px ' + FONT_FAMILY; }
    len(text, px) { this._font(px); return this.g.measureText(text).width; }
    // Pillow 的 textbbox((x, y), text)：(x, y) 是字的左上（上緣＝字型的 ascender）
    bbox(x, y, text, px) {
      this._font(px);
      const m = this.g.measureText(text);
      const base = y + m.fontBoundingBoxAscent;
      return [x - m.actualBoundingBoxLeft, base - m.actualBoundingBoxAscent, x + m.actualBoundingBoxRight, base + m.actualBoundingBoxDescent];
    }
    text(x, y, text, px, white) {
      this._font(px);
      const m = this.g.measureText(text);
      this.g.fillStyle = white ? '#fff' : '#000';
      this.g.fillText(text, x, y + m.fontBoundingBoxAscent);
    }
    // Pillow 的 rectangle([x0, y0, x1, y1])：兩端都包含
    rect(b, white) {
      this.g.fillStyle = white ? '#fff' : '#000';
      this.g.fillRect(b[0], b[1], b[2] - b[0] + 1, b[3] - b[1] + 1);
    }
    rectOutline(b, width) {
      const [x0, y0, x1, y1] = b;
      this.rect([x0, y0, x1, y0 + width - 1]);
      this.rect([x0, y1 - width + 1, x1, y1]);
      this.rect([x0, y0, x0 + width - 1, y1]);
      this.rect([x1 - width + 1, y0, x1, y1]);
    }
    ellipse(b, white) {
      const g = this.g;
      g.fillStyle = white ? '#fff' : '#000';
      g.beginPath();
      g.ellipse((b[0] + b[2]) / 2, (b[1] + b[3]) / 2, Math.max(0.5, (b[2] - b[0]) / 2), Math.max(0.5, (b[3] - b[1]) / 2), 0, 0, Math.PI * 2);
      g.fill();
    }
    // 墨跡範圍 [x0, y0, x1, y1)（跟 Pillow 的 getbbox 一樣右下不含）；全白回傳 null
    ink() {
      const d = this.g.getImageData(0, 0, this.w, this.h).data;
      let x0 = this.w, y0 = this.h, x1 = -1, y1 = -1;
      for (let y = 0; y < this.h; y++) {
        for (let x = 0; x < this.w; x++) {
          if (d[(y * this.w + x) * 4] < 128) {
            if (x < x0) x0 = x; if (x > x1) x1 = x;
            if (y < y0) y0 = y; if (y > y1) y1 = y;
          }
        }
      }
      return x1 < 0 ? null : [x0, y0, x1 + 1, y1 + 1];
    }
    // 把 src 的 (sx, sy, sw, sh) 貼到 (dx, dy)
    paste(src, sx, sy, sw, sh, dx, dy) {
      if (sw <= 0 || sh <= 0) return;
      this.g.drawImage(src.c, sx, sy, sw, sh, dx, dy, sw, sh);
    }
    // 黑白點陣：每列 ceil(W/8) 位元組、最高位在左、1＝白（跟 Pillow 的 '1' 模式 tobytes() 一樣，TSPL BITMAP 用）
    bits() {
      const d = this.g.getImageData(0, 0, this.w, this.h).data;
      const wb = (this.w + 7) >> 3, out = new Uint8Array(wb * this.h);
      for (let y = 0; y < this.h; y++) {
        for (let x = 0; x < wb * 8; x++) {
          const white = x >= this.w || d[(y * this.w + x) * 4] >= 128;
          if (white) out[y * wb + (x >> 3)] |= 0x80 >> (x & 7);
        }
      }
      return out;
    }
  }

  // 屬性中間的「·」自己畫（2026-11-02）：Android 的思源黑體把「·」畫成跟中文字一樣寬，兩邊看起來像有空格。
  // 改成字和字之間留一小段、中間畫一個小圓點
  const SEP = '·';
  const sepW = px => Math.round(px * 0.42);           // 點佔的寬度（含左右空隙）
  function sepLen(T, text, px) {
    const parts = text.split(SEP);
    return parts.reduce((w, p) => w + T.len(p, px), 0) + (parts.length - 1) * sepW(px);
  }
  function drawSep(T, x, y, text, px) {
    const parts = text.split(SEP);
    const mb = T.bbox(0, y, '中', px), cy = (mb[1] + mb[3]) / 2, r = Math.max(2, px * 0.1);
    parts.forEach((p, i) => {
      T.text(x, y, p, px);
      x += T.len(p, px);
      if (i < parts.length - 1) {
        const cx = x + sepW(px) / 2;
        T.ellipse([cx - r, cy - r, cx + r, cy + r]);
        x += sepW(px);
      }
    });
  }

  // 太寬就一級一級縮（fit），R＝右緣
  function fit(img, text, start, min, R) {
    let px = start;
    while (px > min && img.len(text, px) > (R - LEFT)) px -= 2;
    return px;
  }

  // 放不下一行時換行：優先在「、」後面斷開，單一段太長才逐字斷
  function wrapLines(img, text, px, maxw) {
    const parts = []; let buf = '';
    for (const ch of text) { buf += ch; if (ch === '、') { parts.push(buf); buf = ''; } }
    if (buf) parts.push(buf);
    const lines = []; let cur = '';
    parts.forEach(p => {
      if (img.len(cur + p, px) <= maxw) { cur += p; return; }
      if (cur) lines.push(cur);
      cur = '';
      for (const ch of p) {
        if (cur && img.len(cur + ch, px) > maxw) { lines.push(cur); cur = ''; }
        cur += ch;
      }
    });
    if (cur) lines.push(cur);
    return lines;
  }

  // 生日蛋糕小圖（當日壽星那杯），底部對齊 bottom，高 s、寬 s × CAKE_W
  function drawCake(img, x, bottom, s) {
    const w = s * CAKE_W;
    const plate = Math.max(2, Math.round(s * 0.07));
    img.rect([x, bottom - plate, x + w, bottom]);
    const bTop = bottom - plate - 1 - s * 0.36;
    img.rect([x + w * 0.07, bTop, x + w * 0.93, bottom - plate - 1]);
    const r = Math.max(1.5, s * 0.055);
    for (let i = 0; i < 4; i++) {
      const cx = x + w * (0.2 + 0.2 * i);
      img.ellipse([cx - r, bTop + s * 0.1 - r, cx + r, bTop + s * 0.1 + r], true);
    }
    const gapH = Math.max(2, Math.round(s * 0.06));
    const tTop = bTop - gapH - s * 0.24;
    img.rect([x + w * 0.22, tTop, x + w * 0.78, bTop - gapH]);
    const cx = x + w / 2, half = Math.max(1, s * 0.035);
    img.rect([cx - half, tTop - s * 0.17, cx + half, tTop - 1]);
    img.ellipse([cx - s * 0.07, tTop - s * 0.34, cx + s * 0.07, tTop - s * 0.16]);
  }

  // 線上面那一塊（head）＋橫線＋線下面那一塊（body）拼成一張：head 的字底部貼著線上方 HEAD_GAP，
  // body 從 BODY_TOP 往下排；太高的部分切掉（呼叫的人會先縮字，正常不會切到）
  // placed：head 已經畫在最終位置（杯子貼紙的單號固定大小、固定位置），直接貼上不搬
  function compose(head, body, placed) {
    const img = new Img(W, H);
    const hi = head && head.ink();
    if (hi && placed) img.paste(head, 0, 0, W, LINE_Y, 0, 0);
    else if (hi) {
      const room = LINE_Y - HEAD_GAP - 2;
      const h = Math.min(hi[3] - hi[1], room);
      img.paste(head, 0, hi[1], W, h, 0, LINE_Y - HEAD_GAP - h);
    }
    img.rect([LEFT, LINE_Y, RIGHT0 - 1, LINE_Y + 2]);
    const bi = body && body.ink();
    if (bi) img.paste(body, 0, bi[1], W, Math.min(bi[3] - bi[1], H - BODY_TOP), 0, BODY_TOP);
    return img;
  }
  const BODY_ROOM = H - BOTTOM_KEEP - BODY_TOP;   // 線下面能用的高度

  // ── 杯子貼紙 ──
  // 線上面（2026-11-02 Rory：單號要固定大小）：單號（固定 PX_SEQ、固定位置，底部貼著線上方）＋杯數（單號右邊，
  // 靠右停在 logo 前面，放不下才縮）。「袋」「改」不在這裡，在右下角（drawMarks）
  function drawHead(o) {
    const R = HEAD_R, B = LINE_Y - HEAD_GAP;
    const T = new Img(W, H);
    const sb = T.bbox(0, 0, o.seq, PX_SEQ);
    // 有袋子：單號反白（黑底白字），右下角不再印「袋」框（2026-11-04 Rory）
    let headEnd = LEFT + (sb[2] - sb[0]);       // 單號（含反白框）右緣
    if (o.bag) {
      const p = 4;
      // 2 個以上袋子：反白框裡單號後面加小字「×2」（2026-11-04 Rory：看得出要幾個袋子）；
      // 線上面放不下（例如 12 杯）時 renderCup 會設 o.bagBox，改在右下角印「袋2」框
      const nT = o.bag > 1 && !o.bagBox ? '×' + o.bag : '', npx = o.bagPx || 20;
      const nb = nT ? T.bbox(0, 0, nT, npx) : null;
      const nW = nT ? (nb[2] - nb[0]) + 5 : 0;
      const bx = [LEFT - p, B - (sb[3] - sb[1]) - p, LEFT + (sb[2] - sb[0]) + nW + p, B + p];
      T.g.fillStyle = '#000';
      T.g.beginPath(); T.g.roundRect(bx[0], bx[1], bx[2] - bx[0], bx[3] - bx[1], 4); T.g.fill();
      T.text(LEFT - sb[0], B - sb[3], o.seq, PX_SEQ, true);
      if (nT) T.text(LEFT + (sb[2] - sb[0]) + 5 - nb[0], B - nb[3], nT, npx, true);
      headEnd = bx[2];
    } else T.text(LEFT - sb[0], B - sb[3], o.seq, PX_SEQ);
    const cupT = o.cups > 1 ? o.cup + '/' + o.cups : '';
    if (cupT) {
      const room = R - (headEnd + 10);
      // 比單號小一點（2026-11-04 Rory：先改成跟單號一樣大，又說小一點）；放不下才再縮（例如「12/12」）
      let cpx = PX_SEQ - 10;     // 32→26→22（2026-11-04 Rory：再小一點）
      while (cpx > 14 && T.len(cupT, cpx) > room) cpx -= 2;
      const cb = T.bbox(0, 0, cupT, cpx);
      // 底部跟單號對齊：用數字的底（「/」會往下凸，不算）
      const db = T.bbox(0, 0, cupT.replace(/\//g, ''), cpx);
      // 往左一點（2026-11-04 Rory）：右緣停在 R 往左 CUP_LEFT dot，但不會貼到單號（至少隔 10 dot）
      const seqEnd = headEnd + 10;
      const cx = Math.max(seqEnd, R - CUP_LEFT - (cb[2] - cb[0]));
      T.text(cx - cb[0], B - db[3], cupT, cpx);
    }
    return T;
  }

  // 「袋」「改」（2026-11-02 Rory）：放在貼紙右下角，各一個框；兩個都有時上下疊（改在上、袋在下），框一樣寬、靠右對齊。
  // 回傳它佔的範圍 [x0, y0, x1, y1]（線下面的字要避開）；沒有就回傳 null
  // 2026-11-03 Rory：外送單加「外」、自取單加「自」，跟「袋」一樣一個框（順序由上而下：改、外／自、袋）；
  // 疊起來太高（三個都有）就整組字縮小，框不會超出線下面的空間
  const MARK_PX = 21;          // 框裡的字固定大小
  const MARK_SHIFT = 12;       // 框比其他字的右緣再往右 12 dot（約 1.5 mm，2026-11-03 Rory：再靠右一些）
  function marksBox(o, y1 = H - BOTTOM_KEEP) {
    const parts = [];
    if (o.revised) parts.push('改');
    if (o.delivery) parts.push('外'); else if (o.pickup) parts.push('自');
    // 袋子不印框了：改成單號反白（drawHead，2026-11-04 Rory）；只有線上面放不下「×2」時才印「袋2」框
    if (o.bagBox) parts.push('袋' + o.bag);
    if (!parts.length) return null;
    // 字一律 MARK_PX（2026-11-03 Rory：跟 014 改單後三個框的大小一樣，不管幾個框都一樣大）
    const T = new Img(W, H), pad = 5, gap = 4, px = MARK_PX;
    const bbs = parts.map(t => T.bbox(0, 0, t, px));
    const bw = Math.max(...bbs.map(b => b[2] - b[0])) + pad * 2;
    const th = Math.max(...bbs.map(b => b[3] - b[1]));
    const bh = th + pad * 2;
    const x1 = RIGHT0 - 1 + MARK_SHIFT;
    return { parts, bbs, bw, bh, gap, pad, px, area: [x1 - bw, y1 - parts.length * bh - (parts.length - 1) * gap, x1, y1] };
  }
  function drawMarks(img, m) {
    if (!m) return;
    let y = m.area[1];
    m.parts.forEach((t, i) => {
      const b = m.bbs[i], box = [m.area[0], y, m.area[2], y + m.bh];
      img.rect(box, true);
      img.text(box[0] + (m.bw - (b[2] - b[0])) / 2 - b[0], y + (m.bh - (b[3] - b[1])) / 2 - b[1], t, m.px);
      img.rectOutline(box, 2);
      y += m.bh + m.gap;
    });
  }
  // img 在 [x0, y0, x1, y1]（含邊框外 4 dot）有沒有墨跡
  function inkIn(img, a) {
    const x0 = Math.max(0, a[0] - 4), y0 = Math.max(0, a[1] - 4), x1 = Math.min(W, a[2] + 4), y1 = Math.min(H, a[3] + 4);
    const d = img.g.getImageData(x0, y0, x1 - x0, y1 - y0).data;
    for (let i = 0; i < d.length; i += 4) if (d[i] < 128) return true;
    return false;
  }
  // 線下面：品名＋單價、屬性、特調、備註
  function draw(o, shrink, R) {
    const T = new Img(W, H * 2);
    const ny = 10;
    const gap = 8;
    const tag = o.birthday ? '生日快樂' : o.price;
    const tagW = px => {
      const ppx = Math.max(16, Math.trunc(px * 0.6));
      return gap + T.len(tag, ppx) + (o.birthday ? ppx * CAKE_W + 5 : 0);
    };
    const apxPlan = Math.max(20, PX_ATTR - shrink * 2);
    let px = Math.max(apxPlan + NAME_OVER_ATTR, PX_NAME - shrink * 2);
    while (px > (shrink >= 12 ? 20 : 24)) {      // 縮到很後面（字非常多）品名可以再小一點
      const w = T.len(o.name, px) + (tag ? tagW(px) : 0);
      if (w <= R - LEFT) break;
      px -= 2;
    }
    // 品名太長、一行要縮到比屬性還小才放得下（例如「黑糖珍珠布丁鮮奶」）：拆成兩行（前半、後半），字放大；
    // 單價接在第二行後面（2026-11-02 Rory）
    let lines = [o.name];
    const big = Math.max(apxPlan + NAME_OVER_ATTR, PX_NAME - shrink * 2);
    // 縮到第 10 級還放不下（例如再加上最下面的時間電話）：不拆兩行，品名一行、字小一點
    // 當日壽星也一樣（2026-11-03：長品名＋蛋糕＋生日快樂一行放不下，「生日快樂」接在第二行後面）
    if (px < apxPlan + NAME_OVER_ATTR && [...o.name].length >= 5 && shrink < 10) {
      const ch = [...o.name], h = Math.ceil(ch.length / 2);
      lines = [ch.slice(0, h).join(''), ch.slice(h).join('')];
      px = big;
      while (px > 24 && (T.len(lines[0], px) > R - LEFT || T.len(lines[1], px) + (tag ? tagW(px) : 0) > R - LEFT)) px -= 2;
    }
    // 「生日快樂」一律接在品名右邊（2026-11-03 Rory：016 自己一行時擠掉了別的字）；品名照上面的迴圈縮到放得下
    const bdayOwnLine = false;
    if (bdayOwnLine) px = fit(T, o.name, big, 24, R);
    // blocks：每一塊（品名、屬性、加料、備註）的上下緣，給 spreadBody 平均分散用
    const blocks = [];
    const nameTop = T.bbox(LEFT, ny, lines[0], px)[1];
    let nb = ny, lastLine = lines[0];
    lines.forEach((ln, i) => {
      const y0 = i ? Math.trunc(nb) + 4 - T.bbox(0, 0, ln, px)[1] : ny;   // 第二行：上緣離第一行底部 4 dot
      T.text(LEFT, y0, ln, px);
      nb = T.bbox(LEFT, y0, ln, px)[3];
      lastLine = ln;
    });
    if (tag && !bdayOwnLine) {
      const ppx = Math.max(16, Math.trunc(px * 0.6));
      let x = LEFT + T.len(lastLine, px) + gap;
      if (o.birthday) { drawCake(T, x, nb, ppx); x += ppx * CAKE_W + 5; }
      const pbb = T.bbox(0, 0, tag, ppx);
      T.text(x - pbb[0], nb - pbb[3], tag, ppx);
    }
    if (bdayOwnLine) {
      const bpx = Math.max(20, 28 - shrink);
      const bb = T.bbox(0, 0, tag, bpx);
      const lineBottom = nb + 6 + Math.max(bb[3] - bb[1], bpx);
      drawCake(T, LEFT, lineBottom, bpx);
      T.text(LEFT + bpx * CAKE_W + 6 - bb[0], lineBottom - bb[3], tag, bpx);
      nb = lineBottom;
    }
    blocks.push([nameTop, nb]);

    let y = Math.trunc(nb) + (shrink < 6 ? 8 : 5);
    let capPx = Math.max(16, px - NAME_OVER_ATTR);   // 下面的字（加料、備註）最大到這裡：不比上一行大
    if (o.attrs) {
      // 屬性不能比品名大（2026-11-02 Rory：「黑糖珍珠布丁鮮奶」品名長、縮小後反而比屬性小，看起來怪）
      const aStart = Math.min(apxPlan, Math.max(18, px - NAME_OVER_ATTR));
      let apx = aStart;
      while (apx > 18 && sepLen(T, o.attrs, apx) > R - LEFT) apx -= 2;
      // 縮到 18 還太長（例如「固定甜度·正常冰·環保杯要洗」又要讓位給右邊的框）：在「·」的地方換行（2026-11-03）
      let aLines = [o.attrs];
      if (sepLen(T, o.attrs, apx) > R - LEFT && o.attrs.includes(SEP)) {
        const wrap = p => o.attrs.split(SEP).reduce((ls, part) => {
          const cur = ls.length ? ls[ls.length - 1] : null;
          if (cur != null && sepLen(T, cur + SEP + part, p) <= R - LEFT) ls[ls.length - 1] = cur + SEP + part; else ls.push(part);
          return ls;
        }, []);
        apx = aStart;
        aLines = wrap(apx);
        while (apx > 16 && aLines.some(l => sepLen(T, l, apx) > R - LEFT)) { apx -= 2; aLines = wrap(apx); }
      }
      let aTop = null, aBottom = y;
      aLines.forEach(l => {
        drawSep(T, LEFT, y, l, apx);
        const ab = T.bbox(LEFT, y, l.split(SEP).join(''), apx);
        if (aTop == null) aTop = ab[1];
        aBottom = ab[3];
        y = ab[3] + 3;
      });
      blocks.push([aTop, aBottom]);
      y = aBottom + (shrink < 6 ? 6 : 3);
      capPx = Math.max(16, apx);
    }
    // start：從多大開始試（沒給＝PX_MIX 小一號）；一行放不下就縮，縮到 16 還放不下才換行
    // 加料的「加梅子·加布丁」也是自己畫點（drawSep）；放不下要換行時，點換回「、」讓 wrapLines 從那裡斷
    const smallLine = (text, y0, start) => {
      let yy = y0;
      let mpx = Math.min(capPx, start || Math.max(16, PX_MIX - shrink));
      while (mpx > 16 && sepLen(T, text, mpx) > R - LEFT) mpx -= 2;
      if (sepLen(T, text, mpx) <= R - LEFT) {
        drawSep(T, LEFT, yy, text, mpx);
        const b = T.bbox(LEFT, yy, text.split(SEP).join(''), mpx);
        blocks.push([b[1], b[3]]);
        return b[3] + 4;
      }
      const wpx = shrink < 6 ? 16 : shrink < 12 ? 14 : 13;
      let top = null, bottom = yy;
      // 有「·」的（加料）：在點的地方斷行，每一行一樣自己畫點；其他（備註）照 wrapLines
      let lines;
      if (text.includes(SEP)) {
        lines = [];
        text.split(SEP).forEach(p => {
          const cur = lines.length ? lines[lines.length - 1] : null;
          if (cur != null && sepLen(T, cur + SEP + p, wpx) <= R - LEFT) lines[lines.length - 1] = cur + SEP + p;
          else lines.push(p);
        });
      } else lines = wrapLines(T, text, wpx, R - LEFT);
      lines.forEach(line => {
        drawSep(T, LEFT, yy, line, wpx);
        const b = T.bbox(LEFT, yy, line.split(SEP).join(''), wpx);
        if (top == null) top = b[1];
        bottom = b[3];
        yy = b[3] + 3;
      });
      if (top != null) blocks.push([top, bottom]);
      return yy + 1;
    };
    // 加料跟甜度冰塊一樣大（2026-11-02 Rory：012「加 黑糖珍珠」比「固定甜度」小）；備註維持小一號
    if (o.mix) y = smallLine(o.mix, y, capPx);
    if (o.remark) y = smallLine('備註：' + o.remark, y);
    return [T, T.ink(), blocks];
  }

  // 線下面平均分散（2026-11-02 Rory：只有兩行字時下面空太多）：線到貼紙底之間，每一塊上下的空白一樣大。
  // img 是 compose 排好（從 BODY_TOP 往下擠在一起）的整張；blocks 是各塊在 img 上的上下緣。空白太小（< 8 dot）就維持原樣
  function spreadBody(img, blocks, bottom = H - 6) {
    if (!blocks.length) return img;
    const top = LINE_Y + 3;
    const bs = blocks.map(([a, b]) => [Math.max(top, Math.floor(a) - 1), Math.min(H, Math.ceil(b) + 1)]);
    const sum = bs.reduce((s, [a, b]) => s + (b - a), 0);
    const gap = (bottom - top - sum) / (bs.length + 1);
    if (gap < 8) return img;
    const out = new Img(W, H);
    out.paste(img, 0, 0, W, top, 0, 0);
    let y = top + gap;
    bs.forEach(([a, b]) => { out.paste(img, 0, a, W, b - a, 0, Math.round(y)); y += (b - a) + gap; });
    return out;
  }

  // 最下面一行小字「2026-11-03 08:15  05-6364499」（2026-11-03 哥哥要的，店家設定可關）：固定 PX_FOOT、貼著底邊；
  // 有這一行時，上面的字、袋／改框、平均分散都只用到它上面
  const PX_FOOT = 17, FOOT_BOTTOM = H - 3;     // 14→17（2026-11-04 Rory：時間電話再大一點）
  function footerBox(text) {
    if (!text) return null;
    const b = new Img(W, 40).bbox(0, 0, text, PX_FOOT);
    const top = FOOT_BOTTOM - (b[3] - b[1]);
    return { text, b, top, limit: top - 9 };   // 上面的字最低到這裡：跟時間電話至少隔 9 dot（約 1 mm，2026-11-03 Rory：太近）
  }
  function drawFooter(img, f) {
    if (!f) return;
    img.rect([0, f.top - 2, W - 1, H - 1], true);      // 萬一上面的字太多擠到這裡：這一行一定看得清楚
    // 時間和電話中間的空白：原本兩個空格的 3 倍（2026-11-03 Rory）
    const parts = f.text.split(/\s{2,}/);
    // 字放大後放不下就把中間的空白縮小，整行右緣不超過 RIGHT0＋8（離貼紙右邊緣還有約 2.5 mm）
    const used = parts.reduce((s, p) => s + img.len(p, PX_FOOT), 0);
    const space = img.len(' ', PX_FOOT);
    const gapW = parts.length > 1 ? Math.max(space * 2, Math.min(img.len('  ', PX_FOOT) * 3, (RIGHT0 + 8 - LEFT - used) / (parts.length - 1))) : 0;
    let x = LEFT - f.b[0];
    parts.forEach((p, i) => {
      img.text(x, FOOT_BOTTOM - f.b[3], p, PX_FOOT);
      x += img.len(p, PX_FOOT) + (i < parts.length - 1 ? gapW : 0);
    });
  }

  function renderCup(o) {
    // 袋子 2 個以上＋杯數：反白框（含「×2」）＋杯數最小字還是擠不進 logo 前面，就把袋子數改到右下角框
    if (o.bag > 1 && o.cups > 1) {
      const T = new Img(W, 40);
      const sb = T.bbox(0, 0, o.seq, PX_SEQ);
      // 「×2」先試 20，放不下試 16；都不行才改到右下角框（多 4 dot 的寬容：logo 本來就多留了 1 mm 邊）
      o.bagBox = true;
      for (const npx of [20, 16]) {
        const nb = T.bbox(0, 0, '×' + o.bag, npx);
        const headEnd = LEFT + (sb[2] - sb[0]) + (nb[2] - nb[0]) + 5 + 4;   // 跟 drawHead 反白框右緣一樣算
        if (T.len(o.cup + '/' + o.cups, 14) <= HEAD_R + 4 - (headEnd + 10)) { o.bagBox = false; o.bagPx = npx; break; }
      }
    }
    const f = footerBox(o.footer);
    const bottom = f ? f.limit : H - BOTTOM_KEEP;        // 線下面的字最低到這裡
    const head = drawHead(o), m = marksBox(o, bottom);
    const room = bottom - BODY_TOP;
    // 線下面的字放得下、又不會壓到右下角的袋／改框：先照原本寬度一級一級縮；縮到底還會壓到，就整塊改窄（右邊讓給框）
    let img = null;
    for (const R of m ? [RIGHT0, m.area[0] - 6] : [RIGHT0]) {
      for (let shrink = 0; shrink < 16; shrink++) {
        const [body, ink, blocks] = draw(o, shrink, R);
        const fits = !ink || (ink[3] - ink[1]) <= room;
        img = compose(head, body, true);
        if (!fits) continue;
        // 先試平均分散；分散後會壓到袋／改框就用擠在一起的
        const spread = ink ? spreadBody(img, blocks.map(([a, b]) => [a - ink[1] + BODY_TOP, b - ink[1] + BODY_TOP]), f ? bottom : H - 6) : img;
        for (const c of [spread, img]) if (!m || !inkIn(c, m.area)) { drawMarks(c, m); drawFooter(c, f); return c; }
      }
    }
    drawMarks(img, m);             // 怎樣都放不下（字非常多）：框蓋在上面，至少袋／改一定看得到
    drawFooter(img, f);
    return img;
  }

  // 線上面只有一行標題（往左靠、停在 logo 前面）
  function headTitle(text, start, min) {
    const T = new Img(W, H);
    // 「飲品 寄存券」「袋子 寄存券」「珍珠 寄存券」：前面的字放大、「寄存券」維持原大小，底部對齊（2026-11-02 Rory）
    const m = /^(.+) (寄存券)$/.exec(text);
    if (m) {
      const spx = start, room = HEAD_R - LEFT - T.len(m[2], spx) - 6;
      let wpx = 44;
      while (wpx > spx && T.len(m[1], wpx) > room) wpx -= 2;
      const wb = T.bbox(0, 0, m[1], wpx), sb = T.bbox(0, 0, m[2], spx);
      const base = 60;
      T.text(LEFT - wb[0], base - wb[3], m[1], wpx);
      T.text(LEFT + (wb[2] - wb[0]) + 6 - sb[0], base - sb[3], m[2], spx);
      return T;
    }
    T.text(LEFT, 10, text, fit(T, text, start, min, HEAD_R));
    return T;
  }

  // ── 結帳統計貼紙 ──
  function renderSummary(title, rows) {
    for (let step = 38; ; step -= 2) {
      const T = new Img(W, H * 2);
      let y = 10;
      rows.forEach(([key, val]) => {
        T.text(LEFT, y + 6, key, 24);
        let px = 32;
        const keyW = T.len(key, 24);
        while (px > 18 && T.len(val, px) > (RIGHT0 - LEFT - keyW - 14)) px -= 2;
        T.text(RIGHT0 - T.len(val, px), y, val, px);
        y += step;
      });
      const ink = T.ink();
      if (!ink || ink[3] - ink[1] <= BODY_ROOM || step <= 26) return compose(headTitle(title, 30, 18), T);
    }
  }

  // ── 沒有防偽代碼的寄杯貼紙（登記簿發不出代碼時才會用到）──
  function renderVoucher(store, value, note, date, serial, name, head, footer) {
    const amt = '$' + value;
    const f = footerBox(footer), room = f ? f.limit - BODY_TOP : BODY_ROOM;
    // 線下面放不下就整塊一起縮
    for (let s = 1; ; s -= 0.05) {
      const z = px => Math.max(12, Math.round(px * s));
      const T = new Img(W, H * 2);
      let y = 10;
      if (name) {
        const npx = fit(T, name, z(40), z(20), RIGHT0), nbb = T.bbox(0, 0, name, npx);
        T.text(LEFT - nbb[0], y - nbb[1], name, npx);
        y += (nbb[3] - nbb[1]) + 10;
        const apx = fit(T, amt, z(56), z(30), RIGHT0), abb = T.bbox(0, 0, amt, apx);
        T.text(LEFT - abb[0], y - abb[1], amt, apx);
        y += (abb[3] - abb[1]) + 10;
      } else {
        const apx = fit(T, amt, z(76), z(40), RIGHT0), bb = T.bbox(0, 0, amt, apx);
        T.text(LEFT + (RIGHT0 - LEFT - (bb[2] - bb[0])) / 2 - bb[0], y - bb[1], amt, apx);
        y += (bb[3] - bb[1]) + 10;
      }
      [[note, 22], [date + '  No.' + serial, 20]].forEach(([text, px]) => {
        if (!text) return;
        const tpx = fit(T, text, z(px), 12, RIGHT0);
        T.text(LEFT, y, text, tpx);
        y = T.bbox(LEFT, y, text, tpx)[3] + 6;
      });
      const ink = T.ink();
      if (!ink || ink[3] - ink[1] <= room || s < 0.5) {
        const img = compose(headTitle(head || store + ' 寄杯券', 30, 16), T);
        drawFooter(img, f);
        return img;
      }
    }
  }

  // ── 有防偽代碼的寄杯券、寄存券：右上 QR（印表機畫）＋代碼，左欄品名／大字／說明 ──
  // 標題在線上面（停在 logo 前面），QR 從線下面開始
  function renderVoucherCoded(store, value, note, name, code, qr, title, amount, footer) {
    const R = RIGHT0, QR_X = R - 10 - QR_SIZE, COL_W = QR_X - 8 - LEFT;
    const extra = [];
    // 標題由 printer.js 給：「飲品 寄存券」「袋子 寄存券」「珍珠 寄存券」（2026-11-02 Rory：不印店名）；沒給才用「店名 寄杯券」
    const img = compose(headTitle(title ? title : store + ' 寄杯券', 24, 16), null);
    const top = LINE_Y + 3 + 5;

    // QR＋正下方的代碼文字：整塊在線下面的空間上下置中
    const safeQr = String(qr).split('').filter(ch => /[A-Za-z0-9:]/.test(ch)).join('');
    let cpx = 18;
    while (cpx > 14 && img.len(code, cpx) > QR_SIZE + 16) cpx -= 2;
    const cb = img.bbox(0, 0, code, cpx), codeGap = 4;
    const qrTop = LINE_Y + 3 + Math.max(4, Math.floor((H - 4 - (LINE_Y + 3) - (QR_SIZE + codeGap + (cb[3] - cb[1]))) / 2));
    extra.push('QRCODE ' + QR_X + ',' + qrTop + ',M,' + QR_CELL + ',A,0,"' + safeQr + '"');
    img.text(QR_X + (QR_SIZE - (cb[2] - cb[0])) / 2 - cb[0], qrTop + QR_SIZE + codeGap - cb[1], code, cpx);

    // 左欄的字：有「·」的（可折抵飲品·不找零）點自己畫，量寬度也照這樣量
    const colFit = (text, start, min) => { let px = start; while (px > min && sepLen(img, text, px) > COL_W) px -= 2; return px; };
    const nameRows = (nm, maxPx) => {
      const rows = [...nm].length <= 5 ? [nm] : [[...nm].slice(0, 4).join(''), [...nm].slice(4).join('')];
      for (let px = maxPx; px > 15; px -= 2) if (rows.every(r => img.len(r, px) <= COL_W)) return [px, rows];
      return [16, rows];
    };
    const amt = amount || ('$' + value);
    const notes = String(note).split('，').filter(Boolean);
    let BOTTOM = H - 8;
    // 點單時間與電話（2026-11-03 Rory：跟杯子貼紙同一個開關）：右邊是 QR，放在左欄最下面、分兩行（時間／電話），固定 PX_FOOT
    if (footer) {
      const lines = String(footer).split(/\s{2,}/).filter(Boolean);
      let yb = FOOT_BOTTOM;
      for (let i = lines.length - 1; i >= 0; i--) {
        let fpx = Math.min(PX_FOOT, 15);     // 寄存券左欄比較窄，右邊還有代碼：維持 15
        while (fpx > 12 && img.len(lines[i], fpx) > COL_W - 6) fpx -= 1;
        const b = img.bbox(0, 0, lines[i], fpx);
        img.text(LEFT - b[0], yb - b[3], lines[i], fpx);
        yb -= (b[3] - b[1]) + 3;
      }
      BOTTOM = yb + 3 - 9;
    }
    const inkH = (text, px) => { const b = img.bbox(0, 0, text.split(SEP).join(''), px); return b[3] - b[1]; };
    const plan = shrink => {
      const rows = [];
      if (name) {
        const [px, names] = nameRows(name, 34 - shrink);
        names.forEach((r, k) => rows.push([r, px, k === names.length - 1 ? 9 : 5]));
      }
      rows.push([amt, colFit(amt, (name ? 50 : 60) - shrink, 20), shrink > 10 ? 6 : 10]);
      notes.forEach(p => rows.push([p, colFit(p, Math.max(14, 20 - Math.floor(shrink / 4)), 14), 4]));
      return [rows, rows.reduce((s, [t, px, g]) => s + inkH(t, px) + g, 0)];
    };
    let shrink = 0;
    let [rows, total] = plan(shrink);
    while (top + total - (rows.length ? rows[rows.length - 1][2] : 0) > BOTTOM && shrink < 30) { shrink += 2; [rows, total] = plan(shrink); }
    // 左欄在線下面的空間上下置中（2026-11-02 Rory：「3 份」「憑券領取」不要擠在上面）
    const lastGap = rows.length ? rows[rows.length - 1][2] : 0;
    let y = top + Math.max(0, Math.floor((BOTTOM - top - (total - lastGap)) / 2));
    rows.forEach(([text, px, gapAfter]) => {
      const b = img.bbox(0, 0, text.split(SEP).join(''), px);
      drawSep(img, LEFT - b[0], y - b[1], text, px);
      y += (b[3] - b[1]) + gapAfter;
    });
    return [img, extra];       // 位置固定（線、logo），不再上下搬
  }

  // ── TSPL ──
  const ascii = s => { const b = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) b[i] = s.charCodeAt(i) & 0x7f; return b; };
  // 貼紙之間的空隙（2026-11-04 Rory 實測）：
  //   設 2 mm：每單第一張偏下、後面正常；設 3 mm（實際量的）：第一張正常、第二張以後偏低 1 mm；
  //   3 mm＋整張上提 1 mm：第一張偏高、後面正常。
  //   → 用 3 mm，同一批的第二張以後往上提 LIFT_Y dot（點陣圖上面 LIFT_Y 列拿掉、下面補白；QR 的 y 跟著減），第一張不動
  const LIFT_Y = 8;            // 1 mm
  function lifted(img, lift) {
    const wb = (W + 7) >> 3, bits = img.bits();
    if (!lift) return bits;
    const out = new Uint8Array(bits.length).fill(0xff);
    out.set(bits.subarray(wb * lift), 0);
    return out;
  }
  function tspl(img, extra, lift) {
    const parts = [];
    const line = s => parts.push(ascii(s + '\r\n'));
    line('SIZE 35 mm,25 mm');
    line('GAP 3 mm,0 mm');
    line('DIRECTION 1');
    line('REFERENCE ' + SHIFT_X + ',0');
    line('CLS');
    parts.push(ascii('BITMAP 0,0,' + ((W + 7) >> 3) + ',' + H + ',0,'));
    parts.push(lifted(img, lift || 0));
    parts.push(ascii('\r\n'));
    (extra || []).map(e => e.replace(/^QRCODE (\d+),(\d+),/, (m, x, y) => 'QRCODE ' + x + ',' + Math.max(0, +y - (lift || 0)) + ',')).forEach(line);
    line('PRINT 1,1');
    return parts;
  }
  function concat(parts) {
    const n = parts.reduce((s, p) => s + p.length, 0), out = new Uint8Array(n);
    let o = 0;
    parts.forEach(p => { out.set(p, o); o += p.length; });
    return out;
  }

  // 對外：label-render.py 的 main()
  function render(data) {
    const labels = (data && data.labels) || [];
    if (!labels.length) throw new Error('沒有要印的標籤');
    const parts = [];
    labels.forEach((L, i) => {
      const s = v => (v == null ? '' : String(v));
      const lift = i > 0 ? LIFT_Y : 0;     // 同一批的第二張以後往上提（見 LIFT_Y）
      if (L.kind === 'summary') {
        parts.push(...tspl(renderSummary(s(L.title || '結帳'), (L.rows || []).map(r => [s(r[0]), s(r[1])])), null, lift));
      } else if (L.kind === 'voucher' && L.code) {
        const [img, extra] = renderVoucherCoded(s(L.store), parseInt(L.value, 10) || 0, s(L.note), s(L.name),
          s(L.code), s(L.qr || L.code), s(L.head), s(L.amt), s(L.footer));
        parts.push(...tspl(img, extra, lift));
      } else if (L.kind === 'voucher') {
        parts.push(...tspl(renderVoucher(s(L.store), parseInt(L.value, 10) || 0, s(L.note), s(L.date), s(L.serial), s(L.name), s(L.head), s(L.footer)), null, lift));
      } else {
        parts.push(...tspl(renderCup({
          seq: s(L.seq), name: s(L.name), attrs: s(L.attrs), cup: parseInt(L.cup, 10) || 1, cups: parseInt(L.cups, 10) || 1,
          bag: parseInt(L.bag, 10) || 0, revised: !!L.revised, price: s(L.price), mix: s(L.mix), remark: s(L.remark),
          birthday: !!L.birthday, footer: s(L.footer), delivery: !!L.delivery, pickup: !!L.pickup
        }), null, lift));
      }
    });
    return concat(parts);
  }

  // 預覽用（測試、之後的設定畫面）：每張貼紙的 canvas
  function preview(data) {
    return ((data && data.labels) || []).map(L => {
      if (L.kind === 'summary') return renderSummary(String(L.title || '結帳'), L.rows || []).c;
      if (L.kind === 'voucher' && L.code) {
        const [img, extra] = renderVoucherCoded(String(L.store || ''), parseInt(L.value, 10) || 0, String(L.note || ''), String(L.name || ''),
          String(L.code), String(L.qr || L.code), String(L.head || ''), String(L.amt || ''), String(L.footer || ''));
        // 預覽時把 QR 的位置框出來（實際由印表機畫）
        const m = /^QRCODE (\d+),(\d+)/.exec(extra[0] || '');
        if (m) img.rectOutline([+m[1], +m[2], +m[1] + QR_SIZE - 1, +m[2] + QR_SIZE - 1], 3);
        return img.c;
      }
      if (L.kind === 'voucher') return renderVoucher(String(L.store || ''), parseInt(L.value, 10) || 0, String(L.note || ''), String(L.date || ''), String(L.serial || ''), String(L.name || ''), String(L.head || ''), String(L.footer || '')).c;
      return renderCup({ seq: String(L.seq || ''), name: String(L.name || ''), attrs: String(L.attrs || ''), cup: L.cup || 1, cups: L.cups || 1,
        bag: L.bag || 0, revised: !!L.revised, price: String(L.price || ''), mix: String(L.mix || ''), remark: String(L.remark || ''), birthday: !!L.birthday, footer: String(L.footer || ''), delivery: !!L.delivery, pickup: !!L.pickup }).c;
    });
  }

  window.ZaokaLabel = { render, preview, W, H };
})();
