// 貼紙繪圖（35 × 25 mm / 203dpi = 280 × 200 dot）——平板版（2026-11-01）。
//
// 這是 Pi 上 label-render.py 的逐行移植：同一套版面數字、同一套縮字／換行／上下定位規則，
// 只是改用網頁的 canvas 畫（字型是 Android 內建的思源黑體，跟 Pi 上的 Noto Sans CJK 同一套字），
// 畫完轉成黑白點陣，用 TSPL 的 BITMAP 送出。
//   ZaokaLabel.render({ labels: [...] }) → Uint8Array（整串 TSPL），labels 的格式跟 label-render.py 的 stdin 一樣
// 寄杯券的 QR code 請貼紙機自己畫（TSPL 的 QRCODE 指令）：label-render.py 在沒有 python3-qrcode 時本來就走這條路，位置一樣。
// 「小心燙口」直條 2026-10-29 已取消（printer.js 一律送 hot:false），這裡沒有移植。
//
// 版面數字不要隨意更動（2026-09-20、10-29 與 Rory 逐張比對實體貼紙後定案，見 label-render.py）。
// 2026-11-02 起跟 label-render.py 不一樣了：哥哥的貼紙右上角有預印 logo，橫線固定在 0.8 cm（見 LOGO_X0／LINE_Y）。
// Pi 已經退役，label-render.py 沒有跟著改。
(function () {
  'use strict';

  const W = 280, H = 200;
  const LEFT = 10;
  const RIGHT0 = 252;
  const BOTTOM_KEEP = 12;              // 最下面留白（2026-11-02 起位置固定：橫線、logo，不再整塊上下搬）
  const SHIFT_X = 0;
  const PX_SEQ = 38, PX_CUP = 24, PX_BAG = 26, PX_NAME = 46, PX_ATTR = 30;   // 杯數 30→24（2026-11-02 Rory：單號右邊的 1/3 小一點）
  const NAME_OVER_ATTR = 6;
  const PX_MIX = 24;
  const CAKE_W = 1.15;
  // QR 21×21 格 × 每格 5 dot＝105 dot≈13 mm（2026-11-02 試過 10.5、12.5 mm，Rory 決定維持原本的 13 mm、原本的位置）
  const QR_CELL = 5, QR_SIZE = 21 * QR_CELL;
  // 2026-11-02 Rory：哥哥店裡的貼紙右上角預印了 logo（寬約 1.5 cm、高約 0.6 cm）→ 那一塊什麼都不印；
  // 橫線固定在離上緣約 0.8 cm。203dpi＝每 mm 8 dot。logo 四周再多留 1 mm（貼紙機送紙會有一點誤差）。
  // 線上面只放「單號、杯數、袋／改」（都往左靠，右邊停在 logo 前面），線下面照舊用整個寬度。
  // 要微調：改這三個數字就好（單位 dot，8 dot＝1 mm）
  const LOGO_X0 = W - 15 * 8 - 8;     // logo 左緣（再往左留 1 mm）＝152
  const LOGO_Y1 = 6 * 8 + 8;          // logo 下緣（再往下留 1 mm）＝56
  const LINE_Y = 8 * 8;               // 橫線上緣＝64（線粗 3 dot）
  const HEAD_R = LOGO_X0 - 4;         // 線上面的字，右邊最多到這裡
  const HEAD_GAP = 8;                 // 線上面的字，底部離線多遠
  const BODY_TOP = LINE_Y + 3 + 8;    // 線下面的內容從這裡開始
  const FONT_FAMILY = '"Noto Sans CJK TC", "Noto Sans TC", "Microsoft JhengHei", sans-serif';

  // ── 畫布：白底、黑字；量字、找墨跡、搬移都在這裡 ──
  class Img {
    constructor(w, h) {
      this.w = w; this.h = h;
      this.c = document.createElement('canvas');
      this.c.width = w; this.c.height = h;
      this.c.lang = 'zh-TW';
      this.g = this.c.getContext('2d', { willReadFrequently: true });
      this.g.fillStyle = '#fff';
      this.g.fillRect(0, 0, w, h);
      this.g.textBaseline = 'alphabetic';
      this.g.textAlign = 'left';
    }
    _font(px) { this.g.font = 'bold ' + px + 'px ' + FONT_FAMILY; }
    len(text, px) { this._font(px); return this.g.measureText(text).width; }
    // Pillow 的 textbbox((x, y), text)：(x, y) 是字的左上（上緣＝字型的 ascender）
    bbox(x, y, text, px) {
      this._font(px);
      const m = this.g.measureText(text);
      const base = y + m.fontBoundingBoxAscent;
      return [x - m.actualBoundingBoxLeft, base - m.actualBoundingBoxAscent, x + m.actualBoundingBoxRight, base + m.actualBoundingBoxDescent];
    }
    text(x, y, text, px, white) {
      this._font(px);
      const m = this.g.measureText(text);
      this.g.fillStyle = white ? '#fff' : '#000';
      this.g.fillText(text, x, y + m.fontBoundingBoxAscent);
    }
    // Pillow 的 rectangle([x0, y0, x1, y1])：兩端都包含
    rect(b, white) {
      this.g.fillStyle = white ? '#fff' : '#000';
      this.g.fillRect(b[0], b[1], b[2] - b[0] + 1, b[3] - b[1] + 1);
    }
    rectOutline(b, width) {
      const [x0, y0, x1, y1] = b;
      this.rect([x0, y0, x1, y0 + width - 1]);
      this.rect([x0, y1 - width + 1, x1, y1]);
      this.rect([x0, y0, x0 + width - 1, y1]);
      this.rect([x1 - width + 1, y0, x1, y1]);
    }
    ellipse(b, white) {
      const g = this.g;
      g.fillStyle = white ? '#fff' : '#000';
      g.beginPath();
      g.ellipse((b[0] + b[2]) / 2, (b[1] + b[3]) / 2, Math.max(0.5, (b[2] - b[0]) / 2), Math.max(0.5, (b[3] - b[1]) / 2), 0, 0, Math.PI * 2);
      g.fill();
    }
    // 墨跡範圍 [x0, y0, x1, y1)（跟 Pillow 的 getbbox 一樣右下不含）；全白回傳 null
    ink() {
      const d = this.g.getImageData(0, 0, this.w, this.h).data;
      let x0 = this.w, y0 = this.h, x1 = -1, y1 = -1;
      for (let y = 0; y < this.h; y++) {
        for (let x = 0; x < this.w; x++) {
          if (d[(y * this.w + x) * 4] < 128) {
            if (x < x0) x0 = x; if (x > x1) x1 = x;
            if (y < y0) y0 = y; if (y > y1) y1 = y;
          }
        }
      }
      return x1 < 0 ? null : [x0, y0, x1 + 1, y1 + 1];
    }
    // 把 src 的 (sx, sy, sw, sh) 貼到 (dx, dy)
    paste(src, sx, sy, sw, sh, dx, dy) {
      if (sw <= 0 || sh <= 0) return;
      this.g.drawImage(src.c, sx, sy, sw, sh, dx, dy, sw, sh);
    }
    // 黑白點陣：每列 ceil(W/8) 位元組、最高位在左、1＝白（跟 Pillow 的 '1' 模式 tobytes() 一樣，TSPL BITMAP 用）
    bits() {
      const d = this.g.getImageData(0, 0, this.w, this.h).data;
      const wb = (this.w + 7) >> 3, out = new Uint8Array(wb * this.h);
      for (let y = 0; y < this.h; y++) {
        for (let x = 0; x < wb * 8; x++) {
          const white = x >= this.w || d[(y * this.w + x) * 4] >= 128;
          if (white) out[y * wb + (x >> 3)] |= 0x80 >> (x & 7);
        }
      }
      return out;
    }
  }

  // 屬性中間的「·」自己畫（2026-11-02）：Android 的思源黑體把「·」畫成跟中文字一樣寬，兩邊看起來像有空格。
  // 改成字和字之間留一小段、中間畫一個小圓點
  const SEP = '·';
  const sepW = px => Math.round(px * 0.42);           // 點佔的寬度（含左右空隙）
  function sepLen(T, text, px) {
    const parts = text.split(SEP);
    return parts.reduce((w, p) => w + T.len(p, px), 0) + (parts.length - 1) * sepW(px);
  }
  function drawSep(T, x, y, text, px) {
    const parts = text.split(SEP);
    const mb = T.bbox(0, y, '中', px), cy = (mb[1] + mb[3]) / 2, r = Math.max(2, px * 0.1);
    parts.forEach((p, i) => {
      T.text(x, y, p, px);
      x += T.len(p, px);
      if (i < parts.length - 1) {
        const cx = x + sepW(px) / 2;
        T.ellipse([cx - r, cy - r, cx + r, cy + r]);
        x += sepW(px);
      }
    });
  }

  // 太寬就一級一級縮（fit），R＝右緣
  function fit(img, text, start, min, R) {
    let px = start;
    while (px > min && img.len(text, px) > (R - LEFT)) px -= 2;
    return px;
  }

  // 放不下一行時換行：優先在「、」後面斷開，單一段太長才逐字斷
  function wrapLines(img, text, px, maxw) {
    const parts = []; let buf = '';
    for (const ch of text) { buf += ch; if (ch === '、') { parts.push(buf); buf = ''; } }
    if (buf) parts.push(buf);
    const lines = []; let cur = '';
    parts.forEach(p => {
      if (img.len(cur + p, px) <= maxw) { cur += p; return; }
      if (cur) lines.push(cur);
      cur = '';
      for (const ch of p) {
        if (cur && img.len(cur + ch, px) > maxw) { lines.push(cur); cur = ''; }
        cur += ch;
      }
    });
    if (cur) lines.push(cur);
    return lines;
  }

  // 生日蛋糕小圖（當日壽星那杯），底部對齊 bottom，高 s、寬 s × CAKE_W
  function drawCake(img, x, bottom, s) {
    const w = s * CAKE_W;
    const plate = Math.max(2, Math.round(s * 0.07));
    img.rect([x, bottom - plate, x + w, bottom]);
    const bTop = bottom - plate - 1 - s * 0.36;
    img.rect([x + w * 0.07, bTop, x + w * 0.93, bottom - plate - 1]);
    const r = Math.max(1.5, s * 0.055);
    for (let i = 0; i < 4; i++) {
      const cx = x + w * (0.2 + 0.2 * i);
      img.ellipse([cx - r, bTop + s * 0.1 - r, cx + r, bTop + s * 0.1 + r], true);
    }
    const gapH = Math.max(2, Math.round(s * 0.06));
    const tTop = bTop - gapH - s * 0.24;
    img.rect([x + w * 0.22, tTop, x + w * 0.78, bTop - gapH]);
    const cx = x + w / 2, half = Math.max(1, s * 0.035);
    img.rect([cx - half, tTop - s * 0.17, cx + half, tTop - 1]);
    img.ellipse([cx - s * 0.07, tTop - s * 0.34, cx + s * 0.07, tTop - s * 0.16]);
  }

  // 線上面那一塊（head）＋橫線＋線下面那一塊（body）拼成一張：head 的字底部貼著線上方 HEAD_GAP，
  // body 從 BODY_TOP 往下排；太高的部分切掉（呼叫的人會先縮字，正常不會切到）
  // placed：head 已經畫在最終位置（杯子貼紙的單號固定大小、固定位置），直接貼上不搬
  function compose(head, body, placed) {
    const img = new Img(W, H);
    const hi = head && head.ink();
    if (hi && placed) img.paste(head, 0, 0, W, LINE_Y, 0, 0);
    else if (hi) {
      const room = LINE_Y - HEAD_GAP - 2;
      const h = Math.min(hi[3] - hi[1], room);
      img.paste(head, 0, hi[1], W, h, 0, LINE_Y - HEAD_GAP - h);
    }
    img.rect([LEFT, LINE_Y, RIGHT0 - 1, LINE_Y + 2]);
    const bi = body && body.ink();
    if (bi) img.paste(body, 0, bi[1], W, Math.min(bi[3] - bi[1], H - BODY_TOP), 0, BODY_TOP);
    return img;
  }
  const BODY_ROOM = H - BOTTOM_KEEP - BODY_TOP;   // 線下面能用的高度

  // ── 杯子貼紙 ──
  // 線上面（2026-11-02 Rory：單號要固定大小）：單號（固定 PX_SEQ、固定位置，底部貼著線上方）＋杯數（單號右邊，
  // 靠右停在 logo 前面，放不下才縮）。「袋」「改」不在這裡，在右下角（drawMarks）
  function drawHead(o) {
    const R = HEAD_R, B = LINE_Y - HEAD_GAP;
    const T = new Img(W, H);
    const sb = T.bbox(0, 0, o.seq, PX_SEQ);
    T.text(LEFT - sb[0], B - sb[3], o.seq, PX_SEQ);
    const cupT = o.cups > 1 ? o.cup + '/' + o.cups : '';
    if (cupT) {
      const room = R - (LEFT + (sb[2] - sb[0]) + 10);
      let cpx = PX_CUP;
      while (cpx > 14 && T.len(cupT, cpx) > room) cpx -= 2;
      const cb = T.bbox(0, 0, cupT, cpx);
      T.text(R - (cb[2] - cb[0]) - cb[0], B - cb[3], cupT, cpx);
    }
    return T;
  }

  // 「袋」「改」（2026-11-02 Rory）：放在貼紙右下角，各一個框；兩個都有時上下疊（改在上、袋在下），框一樣寬、靠右對齊。
  // 回傳它佔的範圍 [x0, y0, x1, y1]（線下面的字要避開）；沒有就回傳 null
  function marksBox(o) {
    const parts = [];
    if (o.revised) parts.push('改');
    if (o.bag) parts.push('袋' + (o.bag > 1 ? String(o.bag) : ''));
    if (!parts.length) return null;
    const T = new Img(W, H), pad = 5, gap = 4;
    const bbs = parts.map(t => T.bbox(0, 0, t, PX_BAG));
    const bw = Math.max(...bbs.map(b => b[2] - b[0])) + pad * 2;
    const th = Math.max(...bbs.map(b => b[3] - b[1]));
    const bh = th + pad * 2;
    const x1 = RIGHT0 - 1, y1 = H - BOTTOM_KEEP;
    return { parts, bbs, bw, bh, gap, pad, area: [x1 - bw, y1 - parts.length * bh - (parts.length - 1) * gap, x1, y1] };
  }
  function drawMarks(img, m) {
    if (!m) return;
    let y = m.area[1];
    m.parts.forEach((t, i) => {
      const b = m.bbs[i], box = [m.area[0], y, m.area[2], y + m.bh];
      img.rect(box, true);
      img.text(box[0] + (m.bw - (b[2] - b[0])) / 2 - b[0], y + (m.bh - (b[3] - b[1])) / 2 - b[1], t, PX_BAG);
      img.rectOutline(box, 2);
      y += m.bh + m.gap;
    });
  }
  // img 在 [x0, y0, x1, y1]（含邊框外 4 dot）有沒有墨跡
  function inkIn(img, a) {
    const x0 = Math.max(0, a[0] - 4), y0 = Math.max(0, a[1] - 4), x1 = Math.min(W, a[2] + 4), y1 = Math.min(H, a[3] + 4);
    const d = img.g.getImageData(x0, y0, x1 - x0, y1 - y0).data;
    for (let i = 0; i < d.length; i += 4) if (d[i] < 128) return true;
    return false;
  }
  // 線下面：品名＋單價、屬性、特調、備註
  function draw(o, shrink, R) {
    const T = new Img(W, H * 2);
    const ny = 10;
    const gap = 8;
    const tag = o.birthday ? '生日快樂' : o.price;
    const tagW = px => {
      const ppx = Math.max(16, Math.trunc(px * 0.6));
      return gap + T.len(tag, ppx) + (o.birthday ? ppx * CAKE_W + 5 : 0);
    };
    const apxPlan = Math.max(20, PX_ATTR - shrink * 2);
    let px = Math.max(apxPlan + NAME_OVER_ATTR, PX_NAME - shrink * 2);
    while (px > 24) {
      const w = T.len(o.name, px) + (tag ? tagW(px) : 0);
      if (w <= R - LEFT) break;
      px -= 2;
    }
    // 品名太長、一行要縮到比屬性還小才放得下（例如「黑糖珍珠布丁鮮奶」）：拆成兩行（前半、後半），字放大；
    // 單價接在第二行後面（2026-11-02 Rory）
    let lines = [o.name];
    const big = Math.max(apxPlan + NAME_OVER_ATTR, PX_NAME - shrink * 2);
    if (!o.birthday && px < apxPlan + NAME_OVER_ATTR && [...o.name].length >= 5) {
      const ch = [...o.name], h = Math.ceil(ch.length / 2);
      lines = [ch.slice(0, h).join(''), ch.slice(h).join('')];
      px = big;
      while (px > 24 && (T.len(lines[0], px) > R - LEFT || T.len(lines[1], px) + (tag ? tagW(px) : 0) > R - LEFT)) px -= 2;
    }
    const bdayOwnLine = o.birthday && px < 32;
    if (bdayOwnLine) px = fit(T, o.name, big, 24, R);
    // blocks：每一塊（品名、屬性、加料、備註）的上下緣，給 spreadBody 平均分散用
    const blocks = [];
    const nameTop = T.bbox(LEFT, ny, lines[0], px)[1];
    let nb = ny, lastLine = lines[0];
    lines.forEach((ln, i) => {
      const y0 = i ? Math.trunc(nb) + 4 - T.bbox(0, 0, ln, px)[1] : ny;   // 第二行：上緣離第一行底部 4 dot
      T.text(LEFT, y0, ln, px);
      nb = T.bbox(LEFT, y0, ln, px)[3];
      lastLine = ln;
    });
    if (tag && !bdayOwnLine) {
      const ppx = Math.max(16, Math.trunc(px * 0.6));
      let x = LEFT + T.len(lastLine, px) + gap;
      if (o.birthday) { drawCake(T, x, nb, ppx); x += ppx * CAKE_W + 5; }
      const pbb = T.bbox(0, 0, tag, ppx);
      T.text(x - pbb[0], nb - pbb[3], tag, ppx);
    }
    if (bdayOwnLine) {
      const bpx = Math.max(20, 28 - shrink);
      const bb = T.bbox(0, 0, tag, bpx);
      const lineBottom = nb + 6 + Math.max(bb[3] - bb[1], bpx);
      drawCake(T, LEFT, lineBottom, bpx);
      T.text(LEFT + bpx * CAKE_W + 6 - bb[0], lineBottom - bb[3], tag, bpx);
      nb = lineBottom;
    }
    blocks.push([nameTop, nb]);

    let y = Math.trunc(nb) + (shrink < 6 ? 8 : 5);
    let capPx = Math.max(16, px - NAME_OVER_ATTR);   // 下面的字（加料、備註）最大到這裡：不比上一行大
    if (o.attrs) {
      // 屬性不能比品名大（2026-11-02 Rory：「黑糖珍珠布丁鮮奶」品名長、縮小後反而比屬性小，看起來怪）
      let apx = Math.min(apxPlan, Math.max(18, px - NAME_OVER_ATTR));
      while (apx > 18 && sepLen(T, o.attrs, apx) > R - LEFT) apx -= 2;
      drawSep(T, LEFT, y, o.attrs, apx);
      const ab = T.bbox(LEFT, y, o.attrs.split(SEP).join(''), apx);
      blocks.push([ab[1], ab[3]]);
      y = ab[3] + 6;
      capPx = Math.max(16, apx);
    }
    // start：從多大開始試（沒給＝PX_MIX 小一號）；一行放不下就縮，縮到 16 還放不下才換行
    // 加料的「加梅子·加布丁」也是自己畫點（drawSep）；放不下要換行時，點換回「、」讓 wrapLines 從那裡斷
    const smallLine = (text, y0, start) => {
      let yy = y0;
      let mpx = Math.min(capPx, start || Math.max(16, PX_MIX - shrink));
      while (mpx > 16 && sepLen(T, text, mpx) > R - LEFT) mpx -= 2;
      if (sepLen(T, text, mpx) <= R - LEFT) {
        drawSep(T, LEFT, yy, text, mpx);
        const b = T.bbox(LEFT, yy, text.split(SEP).join(''), mpx);
        blocks.push([b[1], b[3]]);
        return b[3] + 4;
      }
      const wpx = shrink < 6 ? 16 : 14;
      let top = null, bottom = yy;
      // 有「·」的（加料）：在點的地方斷行，每一行一樣自己畫點；其他（備註）照 wrapLines
      let lines;
      if (text.includes(SEP)) {
        lines = [];
        text.split(SEP).forEach(p => {
          const cur = lines.length ? lines[lines.length - 1] : null;
          if (cur != null && sepLen(T, cur + SEP + p, wpx) <= R - LEFT) lines[lines.length - 1] = cur + SEP + p;
          else lines.push(p);
        });
      } else lines = wrapLines(T, text, wpx, R - LEFT);
      lines.forEach(line => {
        drawSep(T, LEFT, yy, line, wpx);
        const b = T.bbox(LEFT, yy, line.split(SEP).join(''), wpx);
        if (top == null) top = b[1];
        bottom = b[3];
        yy = b[3] + 3;
      });
      if (top != null) blocks.push([top, bottom]);
      return yy + 1;
    };
    // 加料跟甜度冰塊一樣大（2026-11-02 Rory：012「加 黑糖珍珠」比「固定甜度」小）；備註維持小一號
    if (o.mix) y = smallLine(o.mix, y, capPx);
    if (o.remark) y = smallLine('備註：' + o.remark, y);
    return [T, T.ink(), blocks];
  }

  // 線下面平均分散（2026-11-02 Rory：只有兩行字時下面空太多）：線到貼紙底之間，每一塊上下的空白一樣大。
  // img 是 compose 排好（從 BODY_TOP 往下擠在一起）的整張；blocks 是各塊在 img 上的上下緣。空白太小（< 8 dot）就維持原樣
  function spreadBody(img, blocks) {
    if (!blocks.length) return img;
    const top = LINE_Y + 3, bottom = H - 6;
    const bs = blocks.map(([a, b]) => [Math.max(top, Math.floor(a) - 1), Math.min(H, Math.ceil(b) + 1)]);
    const sum = bs.reduce((s, [a, b]) => s + (b - a), 0);
    const gap = (bottom - top - sum) / (bs.length + 1);
    if (gap < 8) return img;
    const out = new Img(W, H);
    out.paste(img, 0, 0, W, top, 0, 0);
    let y = top + gap;
    bs.forEach(([a, b]) => { out.paste(img, 0, a, W, b - a, 0, Math.round(y)); y += (b - a) + gap; });
    return out;
  }

  function renderCup(o) {
    const head = drawHead(o), m = marksBox(o);
    // 線下面的字放得下、又不會壓到右下角的袋／改框：先照原本寬度一級一級縮；縮到底還會壓到，就整塊改窄（右邊讓給框）
    let img = null;
    for (const R of m ? [RIGHT0, m.area[0] - 6] : [RIGHT0]) {
      for (let shrink = 0; shrink < 16; shrink++) {
        const [body, ink, blocks] = draw(o, shrink, R);
        const fits = !ink || (ink[3] - ink[1]) <= BODY_ROOM;
        img = compose(head, body, true);
        if (!fits) continue;
        // 先試平均分散；分散後會壓到袋／改框就用擠在一起的
        const spread = ink ? spreadBody(img, blocks.map(([a, b]) => [a - ink[1] + BODY_TOP, b - ink[1] + BODY_TOP])) : img;
        for (const c of [spread, img]) if (!m || !inkIn(c, m.area)) { drawMarks(c, m); return c; }
      }
    }
    drawMarks(img, m);             // 怎樣都放不下（字非常多）：框蓋在上面，至少袋／改一定看得到
    return img;
  }

  // 線上面只有一行標題（往左靠、停在 logo 前面）
  function headTitle(text, start, min) {
    const T = new Img(W, H);
    // 「飲品 寄存券」「袋子 寄存券」「珍珠 寄存券」：前面的字放大、「寄存券」維持原大小，底部對齊（2026-11-02 Rory）
    const m = /^(.+) (寄存券)$/.exec(text);
    if (m) {
      const spx = start, room = HEAD_R - LEFT - T.len(m[2], spx) - 6;
      let wpx = 44;
      while (wpx > spx && T.len(m[1], wpx) > room) wpx -= 2;
      const wb = T.bbox(0, 0, m[1], wpx), sb = T.bbox(0, 0, m[2], spx);
      const base = 60;
      T.text(LEFT - wb[0], base - wb[3], m[1], wpx);
      T.text(LEFT + (wb[2] - wb[0]) + 6 - sb[0], base - sb[3], m[2], spx);
      return T;
    }
    T.text(LEFT, 10, text, fit(T, text, start, min, HEAD_R));
    return T;
  }

  // ── 結帳統計貼紙 ──
  function renderSummary(title, rows) {
    for (let step = 38; ; step -= 2) {
      const T = new Img(W, H * 2);
      let y = 10;
      rows.forEach(([key, val]) => {
        T.text(LEFT, y + 6, key, 24);
        let px = 32;
        const keyW = T.len(key, 24);
        while (px > 18 && T.len(val, px) > (RIGHT0 - LEFT - keyW - 14)) px -= 2;
        T.text(RIGHT0 - T.len(val, px), y, val, px);
        y += step;
      });
      const ink = T.ink();
      if (!ink || ink[3] - ink[1] <= BODY_ROOM || step <= 26) return compose(headTitle(title, 30, 18), T);
    }
  }

  // ── 沒有防偽代碼的寄杯貼紙（登記簿發不出代碼時才會用到）──
  function renderVoucher(store, value, note, date, serial, name, head) {
    const amt = '$' + value;
    // 線下面放不下就整塊一起縮
    for (let s = 1; ; s -= 0.05) {
      const z = px => Math.max(12, Math.round(px * s));
      const T = new Img(W, H * 2);
      let y = 10;
      if (name) {
        const npx = fit(T, name, z(40), z(20), RIGHT0), nbb = T.bbox(0, 0, name, npx);
        T.text(LEFT - nbb[0], y - nbb[1], name, npx);
        y += (nbb[3] - nbb[1]) + 10;
        const apx = fit(T, amt, z(56), z(30), RIGHT0), abb = T.bbox(0, 0, amt, apx);
        T.text(LEFT - abb[0], y - abb[1], amt, apx);
        y += (abb[3] - abb[1]) + 10;
      } else {
        const apx = fit(T, amt, z(76), z(40), RIGHT0), bb = T.bbox(0, 0, amt, apx);
        T.text(LEFT + (RIGHT0 - LEFT - (bb[2] - bb[0])) / 2 - bb[0], y - bb[1], amt, apx);
        y += (bb[3] - bb[1]) + 10;
      }
      [[note, 22], [date + '  No.' + serial, 20]].forEach(([text, px]) => {
        if (!text) return;
        const tpx = fit(T, text, z(px), 12, RIGHT0);
        T.text(LEFT, y, text, tpx);
        y = T.bbox(LEFT, y, text, tpx)[3] + 6;
      });
      const ink = T.ink();
      if (!ink || ink[3] - ink[1] <= BODY_ROOM || s < 0.5) return compose(headTitle(head || store + ' 寄杯券', 30, 16), T);
    }
  }

  // ── 有防偽代碼的寄杯券、寄存券：右上 QR（印表機畫）＋代碼，左欄品名／大字／說明 ──
  // 標題在線上面（停在 logo 前面），QR 從線下面開始
  function renderVoucherCoded(store, value, note, name, code, qr, title, amount) {
    const R = RIGHT0, QR_X = R - 10 - QR_SIZE, COL_W = QR_X - 8 - LEFT;
    const extra = [];
    // 標題由 printer.js 給：「飲品 寄存券」「袋子 寄存券」「珍珠 寄存券」（2026-11-02 Rory：不印店名）；沒給才用「店名 寄杯券」
    const img = compose(headTitle(title ? title : store + ' 寄杯券', 24, 16), null);
    const top = LINE_Y + 3 + 5;

    // QR 從線下面開始，代碼文字在 QR 正下方
    const safeQr = String(qr).split('').filter(ch => /[A-Za-z0-9:]/.test(ch)).join('');
    extra.push('QRCODE ' + QR_X + ',' + top + ',M,' + QR_CELL + ',A,0,"' + safeQr + '"');
    let cpx = 18;
    while (cpx > 14 && img.len(code, cpx) > QR_SIZE) cpx -= 2;
    const cb = img.bbox(0, 0, code, cpx);
    img.text(QR_X + (QR_SIZE - (cb[2] - cb[0])) / 2 - cb[0], top + QR_SIZE + 4 - cb[1], code, cpx);

    const colFit = (text, start, min) => { let px = start; while (px > min && img.len(text, px) > COL_W) px -= 2; return px; };
    const nameRows = (nm, maxPx) => {
      const rows = [...nm].length <= 5 ? [nm] : [[...nm].slice(0, 4).join(''), [...nm].slice(4).join('')];
      for (let px = maxPx; px > 15; px -= 2) if (rows.every(r => img.len(r, px) <= COL_W)) return [px, rows];
      return [16, rows];
    };
    const amt = amount || ('$' + value);
    const notes = String(note).split('，').filter(Boolean);
    const BOTTOM = H - 8;
    const inkH = (text, px) => { const b = img.bbox(0, 0, text, px); return b[3] - b[1]; };
    const plan = shrink => {
      const rows = [];
      if (name) {
        const [px, names] = nameRows(name, 34 - shrink);
        names.forEach((r, k) => rows.push([r, px, k === names.length - 1 ? 9 : 5]));
      }
      rows.push([amt, colFit(amt, (name ? 50 : 60) - shrink, 24), 10]);
      notes.forEach(p => rows.push([p, colFit(p, 20, 14), 4]));
      return [rows, rows.reduce((s, [t, px, g]) => s + inkH(t, px) + g, 0)];
    };
    let shrink = 0;
    let [rows, total] = plan(shrink);
    while (top + total - (rows.length ? rows[rows.length - 1][2] : 0) > BOTTOM && shrink < 30) { shrink += 2; [rows, total] = plan(shrink); }
    // 左欄在線下面的空間上下置中（2026-11-02 Rory：「3 份」「憑券領取」不要擠在上面）
    const lastGap = rows.length ? rows[rows.length - 1][2] : 0;
    let y = top + Math.max(0, Math.floor((BOTTOM - top - (total - lastGap)) / 2));
    rows.forEach(([text, px, gapAfter]) => {
      const b = img.bbox(0, 0, text, px);
      img.text(LEFT - b[0], y - b[1], text, px);
      y += (b[3] - b[1]) + gapAfter;
    });
    return [img, extra];       // 位置固定（線、logo），不再上下搬
  }

  // ── TSPL ──
  const ascii = s => { const b = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) b[i] = s.charCodeAt(i) & 0x7f; return b; };
  function tspl(img, extra) {
    const parts = [];
    const line = s => parts.push(ascii(s + '\r\n'));
    line('SIZE 35 mm,25 mm');
    line('GAP 2 mm,0 mm');
    line('DIRECTION 1');
    line('REFERENCE ' + SHIFT_X + ',0');
    line('CLS');
    parts.push(ascii('BITMAP 0,0,' + ((W + 7) >> 3) + ',' + H + ',0,'));
    parts.push(img.bits());
    parts.push(ascii('\r\n'));
    (extra || []).forEach(line);
    line('PRINT 1,1');
    return parts;
  }
  function concat(parts) {
    const n = parts.reduce((s, p) => s + p.length, 0), out = new Uint8Array(n);
    let o = 0;
    parts.forEach(p => { out.set(p, o); o += p.length; });
    return out;
  }

  // 對外：label-render.py 的 main()
  function render(data) {
    const labels = (data && data.labels) || [];
    if (!labels.length) throw new Error('沒有要印的標籤');
    const parts = [];
    labels.forEach(L => {
      const s = v => (v == null ? '' : String(v));
      if (L.kind === 'summary') {
        parts.push(...tspl(renderSummary(s(L.title || '結帳'), (L.rows || []).map(r => [s(r[0]), s(r[1])]))));
      } else if (L.kind === 'voucher' && L.code) {
        const [img, extra] = renderVoucherCoded(s(L.store), parseInt(L.value, 10) || 0, s(L.note), s(L.name),
          s(L.code), s(L.qr || L.code), s(L.head), s(L.amt));
        parts.push(...tspl(img, extra));
      } else if (L.kind === 'voucher') {
        parts.push(...tspl(renderVoucher(s(L.store), parseInt(L.value, 10) || 0, s(L.note), s(L.date), s(L.serial), s(L.name), s(L.head))));
      } else {
        parts.push(...tspl(renderCup({
          seq: s(L.seq), name: s(L.name), attrs: s(L.attrs), cup: parseInt(L.cup, 10) || 1, cups: parseInt(L.cups, 10) || 1,
          bag: parseInt(L.bag, 10) || 0, revised: !!L.revised, price: s(L.price), mix: s(L.mix), remark: s(L.remark),
          birthday: !!L.birthday
        })));
      }
    });
    return concat(parts);
  }

  // 預覽用（測試、之後的設定畫面）：每張貼紙的 canvas
  function preview(data) {
    return ((data && data.labels) || []).map(L => {
      if (L.kind === 'summary') return renderSummary(String(L.title || '結帳'), L.rows || []).c;
      if (L.kind === 'voucher' && L.code) {
        const [img, extra] = renderVoucherCoded(String(L.store || ''), parseInt(L.value, 10) || 0, String(L.note || ''), String(L.name || ''),
          String(L.code), String(L.qr || L.code), String(L.head || ''), String(L.amt || ''));
        // 預覽時把 QR 的位置框出來（實際由印表機畫）
        const m = /^QRCODE (\d+),(\d+)/.exec(extra[0] || '');
        if (m) img.rectOutline([+m[1], +m[2], +m[1] + QR_SIZE - 1, +m[2] + QR_SIZE - 1], 3);
        return img.c;
      }
      if (L.kind === 'voucher') return renderVoucher(String(L.store || ''), parseInt(L.value, 10) || 0, String(L.note || ''), String(L.date || ''), String(L.serial || ''), String(L.name || ''), String(L.head || '')).c;
      return renderCup({ seq: String(L.seq || ''), name: String(L.name || ''), attrs: String(L.attrs || ''), cup: L.cup || 1, cups: L.cups || 1,
        bag: L.bag || 0, revised: !!L.revised, price: String(L.price || ''), mix: String(L.mix || ''), remark: String(L.remark || ''), birthday: !!L.birthday }).c;
    });
  }

  window.ZaokaLabel = { render, preview, W, H };
})();
