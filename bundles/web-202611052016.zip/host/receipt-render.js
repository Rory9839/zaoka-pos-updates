// 客人收據繪圖（203dpi，版面寬 384 dot＝58mm）——平板版（2026-11-01）。
//
// Pi 上 receipt-render.py 的逐行移植：同一套版面 D「明細表」、字級、字距、行距、頁尾愛心，
// 改用網頁的 canvas 畫（Android 內建思源黑體），轉成 ESC/POS 的 GS v 0 點陣圖，最後半切。
//   ZaokaReceipt.render(payload) → Uint8Array（整串 ESC/POS）；payload 跟 receipt-render.py 的 stdin 一樣
//   （receipt.js 組好送來；kind:'summary' 是營業總結）
// 為什麼畫成點陣圖：出單機內建的中文是簡體 GB18030，直接送文字會印出簡體字。
// 版面數字不要隨意更動（2026-09-23 起與 Rory 逐張比對定案，見 receipt-render.py）。
(function () {
  'use strict';

  const W = 384;
  const LEFT = 8, RIGHT = 376;
  const PAD_TOP = 2, PAD_BOTTOM = 40;
  const COL_QTY = 268, COL_AMT = RIGHT, NAME_MAX = COL_QTY - 66;
  const PX_FOOT = 28, LS_FOOT = 0;
  const FOOT_SHOP = '灶咖茶弄', FOOT_SEP = '・', DEFAULT_WISH = '祝您旅途愉快';
  const HEART_SIZE = 18, FOOT_GAP = 6;
  // 單號數字 108 → 80 → 64（2026-11-05 Rory：不需要這麼大）
  const PX_SEQ_LABEL = 34, PX_SEQ = 64, LS_SEQ = 6, PX_PRINTED = 20, PX_CUPS = 28, PX_HEAD = 22;
  const PX_NAME = 34, LS_NAME = 2, PX_QTY = 32, PX_AMT = 32, PX_ATTR = 26, LS_ATTR = 1;
  const PX_TOTAL_LABEL = 32, PX_TOTAL = 54, LS_TOTAL = 3;
  const PX_KIND = 34, LS_KIND = 6, KIND_H = 46, GAP_KIND = 14;
  const PX_STRAW = 32, PX_HOT = 28, PX_CUST = 32, PX_ADDR = 28;
  const GAP_RULE = 14, GAP_SEQ_RULE = 28, GAP_ROW = 26, GAP_ATTR = 14, GAP_MIX = 6, GAP_FOOT = 40;
  const FONT_FAMILY = '"Noto Sans CJK TC", "Noto Sans TC", "Microsoft JhengHei", sans-serif';

  // ── 畫布（同 label-render.js；多了粗細與字距）──
  class Img {
    constructor(w, h) {
      this.w = w; this.h = h;
      this.c = document.createElement('canvas');
      this.c.width = w; this.c.height = h;
      this.c.lang = 'zh-TW';
      this.g = this.c.getContext('2d', { willReadFrequently: true });
      this.g.fillStyle = '#fff';
      this.g.fillRect(0, 0, w, h);
      this.g.textBaseline = 'alphabetic';
    }
    _font(px, bold) { this.g.font = (bold === false ? '' : 'bold ') + px + 'px ' + FONT_FAMILY; }
    len(text, px, bold) { this._font(px, bold); return this.g.measureText(text).width; }
    // Pillow 的 textbbox((x, y), text)：(x, y) 是字的左上（上緣＝字型的 ascender）
    bbox(x, y, text, px, bold) {
      this._font(px, bold);
      const m = this.g.measureText(text);
      const base = y + m.fontBoundingBoxAscent;
      return [x - m.actualBoundingBoxLeft, base - m.actualBoundingBoxAscent, x + m.actualBoundingBoxRight, base + m.actualBoundingBoxDescent];
    }
    text(x, y, text, px, bold, white) {
      this._font(px, bold);
      const m = this.g.measureText(text);
      this.g.fillStyle = white ? '#fff' : '#000';
      this.g.fillText(text, x, y + m.fontBoundingBoxAscent);
    }
    rect(b, white) { this.g.fillStyle = white ? '#fff' : '#000'; this.g.fillRect(b[0], b[1], b[2] - b[0] + 1, b[3] - b[1] + 1); }
    polygon(pts) {
      const g = this.g;
      g.fillStyle = '#000';
      g.beginPath();
      pts.forEach(([x, y], i) => (i ? g.lineTo(x, y) : g.moveTo(x, y)));
      g.closePath();
      g.fill();
    }
    ink() {
      const d = this.g.getImageData(0, 0, this.w, this.h).data;
      let y0 = -1, y1 = -1, x0 = this.w, x1 = -1;
      for (let y = 0; y < this.h; y++) for (let x = 0; x < this.w; x++) {
        if (d[(y * this.w + x) * 4] < 128) { if (y0 < 0) y0 = y; y1 = y; if (x < x0) x0 = x; if (x > x1) x1 = x; }
      }
      return y0 < 0 ? null : [x0, y0, x1 + 1, y1 + 1];
    }
    crop(top, bottom) {
      const out = new Img(this.w, Math.max(1, bottom - top));
      out.g.drawImage(this.c, 0, top, this.w, out.h, 0, 0, this.w, out.h);
      return out;
    }
  }

  // ── 字距（Pillow 沒有 letter-spacing，一個字一個字畫；量寬度用同一套算法）──
  const chars = s => Array.from(String(s));
  function widthLs(img, text, px, bold, ls) {
    if (!ls) return img.len(text, px, bold);
    const cs = chars(text);
    return cs.reduce((s, c) => s + img.len(c, px, bold) + ls, 0) - ls;
  }
  function textLs(img, x, y, text, px, bold, ls, white) {
    if (!ls) { img.text(x, y, text, px, bold, white); return img.len(text, px, bold); }
    let cx = x;
    chars(text).forEach(c => { img.text(cx, y, c, px, bold, white); cx += img.len(c, px, bold) + ls; });
    return cx - x - ls;
  }
  function wrapLines(img, text, px, bold, maxw, ls) {
    const parts = []; let buf = '';
    // 斷行點：「、」以外，屬性的「・」、加料和備註中間的全形空白也可以斷（2026-11-05）
    chars(text).forEach(ch => { buf += ch; if (ch === '、' || ch === '・' || ch === '　') { parts.push(buf); buf = ''; } });
    if (buf) parts.push(buf);
    const lines = []; let cur = '';
    parts.forEach(p => {
      if (widthLs(img, cur + p, px, bold, ls) <= maxw) { cur += p; return; }
      if (cur) lines.push(cur);
      cur = '';
      chars(p).forEach(ch => {
        if (cur && widthLs(img, cur + ch, px, bold, ls) > maxw) { lines.push(cur); cur = ''; }
        cur += ch;
      });
    });
    if (cur) lines.push(cur);
    return lines;
  }
  function shrink(img, text, px, maxw, bold, ls, floor) {
    if (floor == null) floor = 16;
    while (px > floor && widthLs(img, text, px, bold, ls || 0) > maxw) px -= 2;
    return px;
  }
  function right(img, x, y, text, px, bold, ls) {
    const w = widthLs(img, text, px, bold, ls || 0);
    textLs(img, x - w, y, text, px, bold, ls || 0);
    return w;
  }
  function rule(img, y, thick) { thick = thick || 2; img.rect([LEFT, y, RIGHT, y + thick - 1]); return y + thick; }
  // 收據的主要橫線加粗（2026-11-05 Rory）：2 → 4 dot；營業總結照舊
  const RULE_MAIN = 4;
  // 品項之間的細虛線（2026-11-05 Rory）：1 dot 粗，6 實 4 空
  function dashed(img, y) { for (let x = LEFT; x <= RIGHT; x += 10) img.rect([x, y, Math.min(RIGHT, x + 5), y]); return y + 1; }
  function heart(img, cx, cy, size) {
    const raw = [];
    for (let i = 0; i <= 180; i++) {
      const t = i * 2 * Math.PI / 180;
      const x = 16 * Math.pow(Math.sin(t), 3);
      const y = 13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t);
      raw.push([x * size / 32, -y * size / 32]);
    }
    const ys = raw.map(p => p[1]);
    const dy = (Math.min(...ys) + Math.max(...ys)) / 2;
    img.polygon(raw.map(([px, py]) => [cx + px, cy + py - dy]));
  }
  function footer(img, y, wish) {
    const text = FOOT_SHOP + (wish ? FOOT_SEP + wish : '');
    const span = px => HEART_SIZE * 2 + widthLs(img, text, px, false, LS_FOOT) + FOOT_GAP * 2;
    let px = PX_FOOT;
    while (px > 16 && span(px) > RIGHT - LEFT) px -= 2;
    let x = LEFT + (RIGHT - LEFT - span(px)) / 2;
    const bb = img.bbox(0, y, FOOT_SHOP, px, false);
    const mid = (bb[1] + bb[3]) / 2;
    heart(img, x + HEART_SIZE / 2, mid, HEART_SIZE);
    x += HEART_SIZE + FOOT_GAP;
    textLs(img, x, y, text, px, false, LS_FOOT);
    x += widthLs(img, text, px, false, LS_FOOT) + FOOT_GAP;
    heart(img, x + HEART_SIZE / 2, mid, HEART_SIZE);
    return px;
  }
  // 依實際墨跡裁掉上下多餘的部分
  function trim(tall, y) {
    const ink = tall.ink();
    if (!ink) return tall.crop(0, Math.max(1, y));
    const top = Math.max(0, ink[1] - PAD_TOP);
    const bottom = Math.min(tall.h, ink[3] + PAD_BOTTOM);
    return tall.crop(top, Math.max(top + 1, bottom));
  }

  const int = v => parseInt(v, 10) || 0;
  const str = v => (v == null ? '' : String(v));

  function render(data) {
    const seq = str(data.seq);
    const cups = int(data.cups), total = int(data.total), revised = !!data.revised;
    const items = data.items || [];
    const adjust = data.adjust || [];
    const kind = str(data.kind);
    const straws = data.straws && typeof data.straws === 'object' ? data.straws : null;
    const stores = (data.stores || []).filter(s => s && typeof s === 'object' && s.left);
    const T = new Img(W, 320 + items.length * 110 + (adjust.length + 1) * 50 + 220 + (kind ? 360 : 0) + (data.hot ? 60 : 0)
      + stores.length * 90 + (stores.length ? 30 : 0) + items.length * 14 + 120);
    let y = PAD_TOP;

    if (kind) {
      const t = chars(kind).join(' ');
      const bb = T.bbox(0, 0, t, PX_KIND);
      const w = widthLs(T, t, PX_KIND, true, LS_KIND);
      T.rect([LEFT, y, RIGHT, y + KIND_H]);
      textLs(T, (LEFT + RIGHT - w) / 2, y + (KIND_H - (bb[3] - bb[1])) / 2 - bb[1], t, PX_KIND, true, LS_KIND, true);
      y += KIND_H + GAP_KIND;
    }

    const cupsT = '共 ' + cups + ' 杯';
    const rightW = Math.max(widthLs(T, cupsT, PX_CUPS, false, 0), revised ? widthLs(T, '已修改', PX_CUPS, true, 0) : 0) + 12;
    const labelW = widthLs(T, '單號', PX_SEQ_LABEL, false, 0) + 10;
    const qpx = shrink(T, seq, PX_SEQ, RIGHT - LEFT - labelW - rightW, true, LS_SEQ, 40);
    T.text(LEFT, y + qpx - PX_SEQ_LABEL - 8, '單號', PX_SEQ_LABEL, false);
    textLs(T, LEFT + labelW, y - 6, seq, qpx, true, LS_SEQ);
    if (revised) {
      right(T, RIGHT, y + 4, '已修改', PX_CUPS, true);
      right(T, RIGHT, y + 4 + PX_CUPS + 6, cupsT, PX_CUPS, false);
    } else {
      right(T, RIGHT, y + qpx - PX_CUPS - 10, cupsT, PX_CUPS, false);
    }
    y += qpx + GAP_SEQ_RULE;
    y = rule(T, y, RULE_MAIN) + GAP_RULE;

    const cust = data.customer && typeof data.customer === 'object' ? data.customer : null;
    if (kind && cust && (cust.who || cust.address || cust.due)) {
      if (cust.due) {
        const t = str(cust.due), dpx = shrink(T, t, PX_CUST, RIGHT - LEFT, true);
        textLs(T, LEFT, y, t, dpx, true, 0);
        y += dpx + 10;
      }
      if (cust.who) {
        const t = str(cust.who), cpx = shrink(T, t, PX_CUST, RIGHT - LEFT, true);
        textLs(T, LEFT, y, t, cpx, true, 0);
        y += cpx + 8;
      }
      if (cust.address) {
        wrapLines(T, str(cust.address), PX_ADDR, false, RIGHT - LEFT, 0).forEach(line => {
          textLs(T, LEFT, y, line, PX_ADDR, false, 0);
          y += PX_ADDR + 4;
        });
      }
      y += 14;
      y = rule(T, y, 1) + GAP_RULE;
    }

    T.text(LEFT, y, '品項', PX_HEAD, false);
    right(T, COL_QTY, y, '數量', PX_HEAD, false);
    right(T, COL_AMT, y, '小計', PX_HEAD, false);
    y += PX_HEAD + GAP_ROW;

    items.forEach((it, idx) => {
      // 品項之間畫細虛線（第一項上面是表頭，不畫）
      if (idx) { y -= Math.round(GAP_ROW / 2); y = dashed(T, y) + Math.round(GAP_ROW / 2) - 1; }
      // 序號「1.」「2.」…接在品名前面（2026-11-05 Rory）
      const name = (idx + 1) + '. ' + str(it.name), qty = int(it.qty), amount = int(it.amount), attrs = str(it.attrs);
      const npx = shrink(T, name, PX_NAME, NAME_MAX, true, LS_NAME);
      textLs(T, LEFT, y, name, npx, true, LS_NAME);
      const base = y + npx - PX_QTY;
      right(T, COL_QTY, base, String(qty), PX_QTY, false);
      right(T, COL_AMT, base, '$' + amount, PX_AMT, true);
      y += npx + GAP_ATTR;
      // 屬性、加料／備註的第一個字對齊品名的第一個字（序號「1. 」後面）（2026-11-05 Rory）
      const ind = LEFT + widthLs(T, (idx + 1) + '. ', npx, true, LS_NAME) + LS_NAME;
      // 屬性一行放不下就換行，不縮字：跟下面的加料／備註一樣大（2026-11-05 Rory：梅子可樂固定甜度那行變小）
      if (attrs) {
        wrapLines(T, attrs, PX_ATTR, false, RIGHT - ind, LS_ATTR).forEach((line, k) => {
          if (k) y += 4;
          textLs(T, ind, y, line, PX_ATTR, false, LS_ATTR);
          y += PX_ATTR;
        });
      }
      const mix = str(it.mix);
      if (mix) {
        y += GAP_MIX;
        wrapLines(T, mix, PX_ATTR, false, RIGHT - ind, LS_ATTR).forEach(line => {
          textLs(T, ind, y, line, PX_ATTR, false, LS_ATTR);
          y += PX_ATTR + 4;
        });
        y -= 4;
      }
      y += GAP_ROW;
    });

    if (adjust.length) {
      y += 2;
      y = rule(T, y, RULE_MAIN) + GAP_RULE;
      const rows = [['原價', '$' + int(data.subtotal)]].concat(adjust.map(a => [str(a.label), '-$' + Math.abs(int(a.amount))]));
      rows.forEach(([label, val]) => {
        T.text(LEFT, y, label, PX_NAME, false);
        right(T, COL_AMT, y, val, PX_AMT, true);
        y += PX_NAME + GAP_ATTR;
      });
    }

    y += 2;
    y = rule(T, y, RULE_MAIN) + GAP_RULE;
    T.text(LEFT, y + PX_TOTAL - PX_TOTAL_LABEL - 6, '合計', PX_TOTAL_LABEL, true);
    right(T, RIGHT, y, '$' + total, PX_TOTAL, true, LS_TOTAL);
    y += PX_TOTAL + GAP_FOOT;

    if (stores.length) {
      stores.forEach(s => {
        const t = str(s.left), lpx = shrink(T, t, PX_STRAW, RIGHT - LEFT, false);
        textLs(T, LEFT, y, t, lpx, false, 0);
        y += lpx + 8;
        if (s.right) { right(T, RIGHT, y, str(s.right), PX_STRAW + 4, true); y += PX_STRAW + 4 + 14; }
      });
      y += 6;
      y = rule(T, y, 1) + 16;
    }

    if (data.hot) {
      const t = '※ 熱飲請小心燙口 ※', w = widthLs(T, t, PX_HOT, true, 1);
      textLs(T, (LEFT + RIGHT - w) / 2, y - 6, t, PX_HOT, true, 1);
      y += PX_HOT + 22;
    }

    if (kind && straws) {
      const t = '細吸管：' + int(straws.thin) + '　粗吸管：' + int(straws.thick);
      const spx = shrink(T, t, PX_STRAW, RIGHT - LEFT, true), w = widthLs(T, t, spx, true, 0);
      textLs(T, (LEFT + RIGHT - w) / 2, y, t, spx, true, 0);
      y += spx + 22;
      y = rule(T, y, 1) + 16;
    }

    // 列印時間（2026-11-05 Rory）：置中小字、到秒，不加「列印」兩個字；改單重印時是重印的時間
    // 位置：放在「♥ 灶咖茶弄・祝福語 ♥」上面（2026-11-05 Rory：跟頁尾互換）
    const printed = str(data.printed);
    if (printed) {
      const w = widthLs(T, printed, PX_PRINTED, false, 0);
      textLs(T, (LEFT + RIGHT - w) / 2, y - 6, printed, PX_PRINTED, false, 0);
      y += PX_PRINTED + 12;
    }
    y += footer(T, y, data.noWish ? '' : str(data.wish || DEFAULT_WISH)) + 10;
    y += PAD_BOTTOM;
    return trim(T, y);
  }

  function renderSummary(data) {
    const date = str(data.date), printed = str(data.printed);
    const orders = int(data.orders), cups = int(data.cups), revenue = int(data.revenue), voided = int(data.voided);
    const items = data.items || [];
    const avg = orders ? Math.round(revenue / orders) : 0;
    const money = n => n.toLocaleString('en-US');
    const T = new Img(W, 520 + items.length * 48);
    let y = PAD_TOP;
    const title = str(data.title || '本日營業總結');
    const tw = widthLs(T, title, 40, true, 4);
    textLs(T, LEFT + (RIGHT - LEFT - tw) / 2, y, title, 40, true, 4);
    y += 40 + 14;
    // 期間比較長（10/01～10/31）時「列印 時間」放不下同一行就換到下一行靠右（2026-11-01）
    const dateT = (data.range ? '期間 ' : '營業日 ') + date;
    T.text(LEFT, y, dateT, 24, false);
    if (printed) {
      const pt = '列印 ' + printed;
      if (widthLs(T, dateT, 24, false, 0) + 12 + widthLs(T, pt, 22, false, 0) > RIGHT - LEFT) y += 24 + 6;
      right(T, RIGHT, y, pt, 22, false);
    }
    y += 24 + GAP_RULE;
    y = rule(T, y) + GAP_RULE;
    // 營業額：整個月的數字比較長，放不下就縮字（不要撞到「營業額」三個字）
    T.text(LEFT, y + 60 - 32 - 8, '營業額', 32, true);
    const revT = '$' + money(revenue);
    const rpx = shrink(T, revT, 60, RIGHT - LEFT - widthLs(T, '營業額', 32, true, 0) - 14, true, 2, 30);
    right(T, RIGHT, y + (60 - rpx), revT, rpx, true, 2);
    y += 60 + GAP_RULE + 4;
    [['訂單數', orders + ' 筆'], ['杯數', cups + ' 杯'], ['平均客單價', '$' + money(avg)], ['作廢', voided + ' 筆']].forEach(([label, val]) => {
      T.text(LEFT, y, label, 28, false);
      right(T, RIGHT, y - 2, val, 30, true);
      y += 30 + 12;
    });
    if (items.length) {
      y += 4;
      y = rule(T, y) + GAP_RULE;
      T.text(LEFT, y, '品項', PX_HEAD, false);
      right(T, COL_QTY, y, '杯數', PX_HEAD, false);
      right(T, COL_AMT, y, '金額', PX_HEAD, false);
      y += PX_HEAD + 12;
      items.forEach(([name, qty, amt]) => {
        name = str(name);
        const npx = shrink(T, name, 28, NAME_MAX, true);
        T.text(LEFT, y, name, npx, true);
        right(T, COL_QTY, y + npx - 28, String(int(qty)), 28, false);
        // 金額欄只有數量欄右邊到紙邊這麼寬：整個月的金額（$377,190）放不下就縮字，不要壓到杯數
        const amtT = '$' + money(int(amt));
        const apx = shrink(T, amtT, 28, COL_AMT - COL_QTY - 10, true, 0, 16);
        right(T, COL_AMT, y + npx - apx, amtT, apx, true);
        y += npx + 14;
      });
    }
    y += 2;
    y = rule(T, y);
    return trim(T, y);
  }

  // ── ESC/POS：GS v 0 點陣圖（1＝黑），每 128 列一段；最後 GS V B 0 送到切刀位置半切 ──
  function escpos(img) {
    const wb = (img.w + 7) >> 3;
    const d = img.g.getImageData(0, 0, img.w, img.h).data;
    const parts = [new Uint8Array([0x1b, 0x40])];
    for (let top = 0; top < img.h; top += 128) {
      const h = Math.min(128, img.h - top);
      const block = new Uint8Array(8 + wb * h);
      block.set([0x1d, 0x76, 0x30, 0x00, wb & 0xff, wb >> 8, h & 0xff, h >> 8]);
      for (let y = 0; y < h; y++) for (let x = 0; x < img.w; x++) {
        if (d[((top + y) * img.w + x) * 4] < 128) block[8 + y * wb + (x >> 3)] |= 0x80 >> (x & 7);
      }
      parts.push(block);
    }
    parts.push(new Uint8Array([0x1d, 0x56, 0x42, 0x00]));
    const out = new Uint8Array(parts.reduce((n, p) => n + p.length, 0));
    let o = 0;
    parts.forEach(p => { out.set(p, o); o += p.length; });
    return out;
  }

  // 對外：receipt-render.py 的 main()
  function render_(data) {
    if (data && data.kind === 'summary') return escpos(renderSummary(data));
    if (!data || !data.items || !data.items.length) throw new Error('沒有品項');
    return escpos(render(data));
  }
  // 預覽用：收據的 canvas
  function preview(data) { return (data && data.kind === 'summary' ? renderSummary(data) : render(data)).c; }

  window.ZaokaReceipt = { render: render_, preview, W };
})();
