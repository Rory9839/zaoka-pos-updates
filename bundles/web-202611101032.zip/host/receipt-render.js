// 客人收據繪圖（203dpi，版面寬 384 dot＝58mm）——平板版（2026-11-01）。
//
// Pi 上 receipt-render.py 的逐行移植：同一套版面 D「明細表」、字級、字距、行距、頁尾愛心，
// 改用網頁的 canvas 畫（Android 內建思源黑體），轉成 ESC/POS 的 GS v 0 點陣圖，最後半切。
//   ZaokaReceipt.render(payload) → Uint8Array（整串 ESC/POS）；payload 跟 receipt-render.py 的 stdin 一樣
//   （receipt.js 組好送來；kind:'summary' 是營業總結）
// 為什麼畫成點陣圖：出單機內建的中文是簡體 GB18030，直接送文字會印出簡體字。
// 版面數字不要隨意更動（2026-09-23 起與 Rory 逐張比對定案，見 receipt-render.py）。
(function () {
  'use strict';

  const W = 384;
  const LEFT = 8, RIGHT = 376;
  const SHIFT_X = 8;             // 送給出單機時整張往右挪 1 mm（2026-11-05 Rory），預覽不挪
  const PAD_TOP = 2, PAD_BOTTOM = 40;
  const COL_QTY = 268, COL_AMT = RIGHT, NAME_MAX = COL_QTY - 66;
  const PX_FOOT = 28, LS_FOOT = 0;
  const FOOT_SHOP = '灶咖茶弄', FOOT_SEP = '・', DEFAULT_WISH = '想家的時候，喝一杯灶咖';   // 2026-11-06：標語固定這一句
  const HEART_SIZE = 18, FOOT_GAP = 6;
  // 單號數字 108 → 80 → 64（2026-11-05 Rory：不需要這麼大）
  // 2026-11-05 Rory：「單號」兩字跟右邊「共 N 杯」一樣大（34 → 28）；數字 64 → 54
  const PX_SEQ_LABEL = 28, PX_SEQ = 54, LS_SEQ = 6, PX_PRINTED = 20, PX_CUPS = 28, PX_HEAD = 22;
  const PX_NAME = 34, LS_NAME = 2, PX_QTY = 32, PX_AMT = 32, PX_ATTR = 26, LS_ATTR = 1;
  const PX_TOTAL_LABEL = 32, PX_TOTAL = 54, LS_TOTAL = 3;
  const PX_KIND = 34, LS_KIND = 6, KIND_H = 46, GAP_KIND = 14;
  const PX_STRAW = 32, PX_HOT = 28, PX_CUST = 32, PX_ADDR = 28, PX_CUST_INFO = 28;
  const GAP_RULE = 14, GAP_SEQ_RULE = 28, GAP_ROW = 26, GAP_ATTR = 14, GAP_MIX = 6, GAP_FOOT = 22;   // 合計下面的空白 40 → 22（2026-11-05 Rory）
  // 店標（2026-11-05 Rory 給的圖，去背後轉成黑白點陣）：印在收據最上面。300×65 dot（352 → 280 → 232；2026-11-06 Rory 標語移到店標下面時又加大成 300 寬）、每列 38 bytes、1＝黑
  const LOGO = { w: 300, h: 65, b64: 'AAAAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD///////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP//////8AAAAAAAAAAAAAAAAA8AAAAAAAAAAABwAAAAAAAAAAMA///////wAAAH8AAAAAAAAAAAH8AAAAAAAfgAA/gAAAAAAAAAB8D///////AAAAf4AAAAAAAAAAAfwAAAAAAB/AAD+AAAAP//////4H/+H/4j4AAAB/gAA/gAAAAAAB/AAAAAAAH8AAP4AAAB///////wAAAAAADAAAAH+AAD/AAAAAAAH8AAAAAAAfwAA/gAAAH///////Af/////8AAAAfwAAP8AAAAAAAfwAAAAAAB/AAD+HAAAf//////8B//////wAAAB/AAA/wAAAAAAA+AAAAAAAH8AAP5+AAAAAD/gAAAH//////AAAAH8AAD/AAAAAAAD4eAAAAA///////+AAAAAH8AAAAf/////8AABAfwAAP8AAAAAA4f38AAAAH///////4AAAAAfwAAAB//////wAAMB/AAA/wAAAAeH///5AeAAf///////gAAAAB/gAAAH//////AAAwH8fgD/AAAAB//////j8AB//////wAAAAAAH+ADwAf//4B/8AAHgfx+AP8AAAAH///////4AAD/AAD+AAAACAD//4fgB///gH/wAAeB/P4A/wEAAAf////7//gAAH8HAP4AAAAf/////+AH//////AAB8H8/gD+B8AAB///8fv/+AAAfw/A/gAAAD//////8Af/////8AAP4fz+AP8PwAAH/+fh8//wAAB/H+D+AAAAH//////wB/h/ngfwAA/h/Pz////gAAfH5+Hz+/AAAGA/8MAAAAAP///wAAAHwDAMA+AAD/H8/f////AAB8Pn4fHh8AAAAH/wAAAAAAAAH+AAAAfAOAwD4AAP8fj5////8AAHw+fh8eHwAAAAf/gAAAAAAAAf4AAAB//////gAAfx+fn////wAAfD5+Hx4fAAAAH//AAAAAAAAB/gAAAH/////+AAB/P58f///4AAB8Pn4fHh8AAAA/9/gAAAAAAAH+ABwAf+AYB/4AAH8/nwAP8AAAAHw+fh8eHwAAAH/j/gAAAAAAAf4APwB/4BgH/gAAPj+eAA/gAAAAfD5+Hx4fAAAA/4H/wAAAAAAD////gH/8f//+AAAcP5wAD+AAAAB8Pn4fHh8AAAH/AH/4AAAP///////Af/////4AAAY/GAAP4AAAAHw+fg8eHwAAA/4AP/8AAA///////8B////gPgAAAj8AAA/gAAAAfD5+D54fAAAP+AAP//AAD///////wH///8A+AAADPwAAD+AAAAB8Pn4Pnh8AAB/w/wP/+AAP//////gAf///wH4AAAA/AAAP4AAAAHw+fg+eHwAAf8D/AP/wAAAAAAAAAAB//////gAAAH4AAA/gAAAAfD5+D54fAAD/AP8Af/AAAAB+AP4AAH/////+AAAAfgAAD+AAAAB8Pn4Pnh8AA/wA/wIP4AAAAH8A/gAAfAP///4AAAB+AAAP4AAAAHw+fg+fHwAHwAD/D4PAAAAAfwD+AAB8A////gAAAH4AAA/gAAAAfD58D58fAAAAH///wMAAAAB/AP4AAD/////+AAAAf8AAD+AAAAB8PnwPnx8AAAP////gAAAAAP8A/gAAP/////4AAAB//AAP4AAAAHw+fA+fHwAAA////+AAAAAA/gD+DgA//////gAAAP//AA/gAAAAfD58D58fAAAD///4AAAAAAH/Af8/AD/////+AAAA//+AD+AAAAB8PvwPnx+AAAAA/wAAAAAH//////+AP/+B//4AAAD5/4AP4AAAAH/+/A+fH4AAAAB/AAAAAAf//////8A//wD//gAAAPj/wA/gAAAAf/74D5//gAAAcH8fAAAAB///////wD/+AH/8AAAA8H/AD+AAAAB//vifn/+AAAD4fx/gAAAD/////wAAP/wAP/wAAAHwf8AP4AAAAH/++P+f/4AAAfx/B/wAAAAB/AD+AAA//AAf/AAAAfA/wA/gBgAAf/7w/5//AAAD/H8D/gAAAAH4AP4AAD/8AB/8AAAB4D/AD+APAAB8PPD/n/8AAAP8fwH/AAAAA/AA/gAAP/gAH/wAAAPgH8AP8P+AAHg48H+fHwAAB/j/Af8AAAAD8AD+AAA/+AAf/gAAA8AP/////8AAADHgf5weAAAP8P8A/wAAAAPgAP4AAD/4AB/8AAADwAf/////wAAAAcB/AAwAAB/A/wB+AAAAA8AA/gAAP/gAH/wAAAOAAf/////gAAABgH8AAAAAP4D/ADwAAAAHwAD+AAAf/AAf/AAABwAA/////+AAAAEAfwAAAAB+AP8AAAAAAAeAAP4AAB/8AB/4AAAHAAD/////wAAAAAA+AAAAAHgA/wAAAAAADgAA/gAAD///v/AAAAYAAAAAAAAAAAAAABwAAAAAAAB4AAAAAAAEAAD4AAA==' };
  // 頁尾標語點陣（2026-11-06 Rory 要跟店裡招牌「想家的時候，喝一杯灶咖」一樣的粗明體）：電腦上用思源宋體 Bold 畫好轉黑白，252×22 dot（2026-11-06 Rory 移到店標下面：縮小、左右比店標內縮）、每列 32 bytes
  const SLOGAN_TEXT = '想家的時候，喝一杯灶咖';
  const SLOGAN = { w: 252, h: 22, b64: 'DgAAAMAAAAAAAAAAAAAAAAAAAAAAAAAIAAAAAAAAAAAOEDAA8AA8PAAAOAHgDAAAAAAYDAAAAA4AGDwPAAOAAA4f+ABwIDg8Axg4gcP+AAAAEZ/+AAAADgA8OA4AE4AADtx4P//wMDhD/DnBwA4AAAAf/BwAAAAO//w4DgH7juD//HhgAHn3OOO//8O4DgAAAB3cHAAAAA6DgDgOAbuv8B4f+OABYf//87g4A7gfgAAAHd/8AAAAD8eBu44Bv/7gHhx54APBx3DjuDkDv//AAAAd3BwAAAD/xwH/jgG7/uAfnHjf/8HHYOO4O4O5gAAPAB3cHAAAAB4PAP8OYbv+4D/f+APBgcfA47v/x7vCAA8AHd/8AAAYH4+A///xu/7gPvx4B4Phx8DjuAcHu4cADwAd3wgAADwf3+D8HgG7/uA+3Hgfx+HHMOP4B0e7/4AHAB3OBn///j/fcPgOAbt+4G4ceDn/Af8847wP77t4AAMAHd//AAAAP/84OA4Bu37gzh/4w/wBxxzjv//jvngAAgAd2c4AAAA+dxw4DgG7fuAOHHAPdAHHHOO7hwO8c4AOAB35zgAAAH7HHDgOAbt+4AYwAB72Accc47nHA7//wAgAHfnuAAAAb4cMPg4Bv37gF5xgcfMBxwDjuecDuHAAAAAf234AAADOBwA/DgH/fuAXnLjD+8HHAeP45wO4eAAAAB3ePgAAAI4HADcOAb5+4DecuAe58ccBw7jHA7juAAAAHZ/uAAAADgcAc44Bhn/gd4G8Hnjx/wHDuAcDsOeAAAAYH/4AAAAOBwBjjiGP/uD3/9hz8GHHD8MAPwOBw4AAAAAPzgAAAA4HAGAOcA3u4GP/wIHwAcAHwAAeA4MDwAAAAAB+AAAADgcAw//4GO7AAAAAAOAAAAcAAA4DjAGAAAAAABwAAAAMBwGAAAAQBAA=' };
  const FONT_FAMILY = '"Noto Sans CJK TC", "Noto Sans TC", "Microsoft JhengHei", sans-serif';
  // 明體：頁尾標語用（2026-11-06 Rory 要新細明體粗體；平板沒有新細明體，用內建的 Noto Serif CJK，電腦預覽才是新細明體）
  const FONT_SERIF = '"Noto Serif CJK TC", "Noto Serif TC", "PMingLiU", serif';
  let fontNow = FONT_FAMILY;     // 目前畫字的字型（頁尾標語暫時換成明體）

  // ── 畫布（同 label-render.js；多了粗細與字距）──
  class Img {
    constructor(w, h) {
      this.w = w; this.h = h;
      this.c = document.createElement('canvas');
      this.c.width = w; this.c.height = h;
      this.c.lang = 'zh-TW';
      this.g = this.c.getContext('2d', { willReadFrequently: true });
      this.g.fillStyle = '#fff';
      this.g.fillRect(0, 0, w, h);
      this.g.textBaseline = 'alphabetic';
    }
    _font(px, bold) { this.g.font = (bold === false ? '' : 'bold ') + px + 'px ' + fontNow; }
    len(text, px, bold) { this._font(px, bold); return this.g.measureText(text).width; }
    // Pillow 的 textbbox((x, y), text)：(x, y) 是字的左上（上緣＝字型的 ascender）
    bbox(x, y, text, px, bold) {
      this._font(px, bold);
      const m = this.g.measureText(text);
      const base = y + m.fontBoundingBoxAscent;
      return [x - m.actualBoundingBoxLeft, base - m.actualBoundingBoxAscent, x + m.actualBoundingBoxRight, base + m.actualBoundingBoxDescent];
    }
    text(x, y, text, px, bold, white) {
      this._font(px, bold);
      const m = this.g.measureText(text);
      this.g.fillStyle = white ? '#fff' : '#000';
      this.g.fillText(text, x, y + m.fontBoundingBoxAscent);
    }
    rect(b, white) { this.g.fillStyle = white ? '#fff' : '#000'; this.g.fillRect(b[0], b[1], b[2] - b[0] + 1, b[3] - b[1] + 1); }
    polygon(pts) {
      const g = this.g;
      g.fillStyle = '#000';
      g.beginPath();
      pts.forEach(([x, y], i) => (i ? g.lineTo(x, y) : g.moveTo(x, y)));
      g.closePath();
      g.fill();
    }
    ink() {
      const d = this.g.getImageData(0, 0, this.w, this.h).data;
      let y0 = -1, y1 = -1, x0 = this.w, x1 = -1;
      for (let y = 0; y < this.h; y++) for (let x = 0; x < this.w; x++) {
        if (d[(y * this.w + x) * 4] < 128) { if (y0 < 0) y0 = y; y1 = y; if (x < x0) x0 = x; if (x > x1) x1 = x; }
      }
      return y0 < 0 ? null : [x0, y0, x1 + 1, y1 + 1];
    }
    crop(top, bottom) {
      const out = new Img(this.w, Math.max(1, bottom - top));
      out.g.drawImage(this.c, 0, top, this.w, out.h, 0, 0, this.w, out.h);
      return out;
    }
  }

  // ── 字距（Pillow 沒有 letter-spacing，一個字一個字畫；量寬度用同一套算法）──
  const chars = s => Array.from(String(s));
  function widthLs(img, text, px, bold, ls) {
    if (!ls) return img.len(text, px, bold);
    const cs = chars(text);
    return cs.reduce((s, c) => s + img.len(c, px, bold) + ls, 0) - ls;
  }
  function textLs(img, x, y, text, px, bold, ls, white) {
    if (!ls) { img.text(x, y, text, px, bold, white); return img.len(text, px, bold); }
    let cx = x;
    chars(text).forEach(c => { img.text(cx, y, c, px, bold, white); cx += img.len(c, px, bold) + ls; });
    return cx - x - ls;
  }
  function wrapLines(img, text, px, bold, maxw, ls) {
    const parts = []; let buf = '';
    // 斷行點：「、」以外，屬性的「・」、加料和備註中間的全形空白也可以斷（2026-11-05）
    chars(text).forEach(ch => { buf += ch; if (ch === '、' || ch === '・' || ch === '　' || ch === ' ') { parts.push(buf); buf = ''; } });
    if (buf) parts.push(buf);
    const lines = []; let cur = '';
    parts.forEach(p => {
      if (widthLs(img, cur + p, px, bold, ls) <= maxw) { cur += p; return; }
      if (cur) lines.push(cur);
      cur = '';
      chars(p).forEach(ch => {
        if (cur && widthLs(img, cur + ch, px, bold, ls) > maxw) { lines.push(cur); cur = ''; }
        cur += ch;
      });
    });
    if (cur) lines.push(cur);
    return lines;
  }
  function shrink(img, text, px, maxw, bold, ls, floor) {
    if (floor == null) floor = 16;
    while (px > floor && widthLs(img, text, px, bold, ls || 0) > maxw) px -= 2;
    return px;
  }
  function right(img, x, y, text, px, bold, ls) {
    const w = widthLs(img, text, px, bold, ls || 0);
    textLs(img, x - w, y, text, px, bold, ls || 0);
    return w;
  }
  // 把店標畫在 (x, y)，回傳高度
  function drawLogo(img, x, y) { return drawBits(img, LOGO, x, y); }
  // 點陣圖（{ w, h, b64 }，1＝黑）畫在 (x, y)，回傳高度：店標、頁尾標語共用
  function drawBits(img, B, x, y) {
    x = Math.round(x); y = Math.round(y);
    const bin = atob(B.b64), wb = (B.w + 7) >> 3;
    const id = img.g.getImageData(x, y, B.w, B.h), d = id.data;
    for (let r = 0; r < B.h; r++) for (let c = 0; c < B.w; c++) {
      if (bin.charCodeAt(r * wb + (c >> 3)) & (0x80 >> (c & 7))) { const i = (r * B.w + c) * 4; d[i] = d[i + 1] = d[i + 2] = 0; }
    }
    img.g.putImageData(id, x, y);
    return B.h;
  }
  function rule(img, y, thick) { thick = thick || 2; img.rect([LEFT, y, RIGHT, y + thick - 1]); return y + thick; }
  // 收據的主要橫線加粗（2026-11-05 Rory）：2 → 4 dot；營業總結照舊
  const RULE_MAIN = 4;
  // 品項之間的細虛線（2026-11-05 Rory）：1 dot 粗，6 實 4 空
  function dashed(img, y) { for (let x = LEFT; x <= RIGHT; x += 10) img.rect([x, y, Math.min(RIGHT, x + 5), y]); return y + 1; }
  function heart(img, cx, cy, size) {
    const raw = [];
    for (let i = 0; i <= 180; i++) {
      const t = i * 2 * Math.PI / 180;
      const x = 16 * Math.pow(Math.sin(t), 3);
      const y = 13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t);
      raw.push([x * size / 32, -y * size / 32]);
    }
    const ys = raw.map(p => p[1]);
    const dy = (Math.min(...ys) + Math.max(...ys)) / 2;
    img.polygon(raw.map(([px, py]) => [cx + px, cy + py - dy]));
  }
  // 頁尾：♥ 標語 ♥。2026-11-06 Rory：標語固定「想家的時候，喝一杯灶咖」、明體粗體（不再接在「灶咖茶弄・」後面）；
  // 設定關掉標語時照舊印 ♥ 灶咖茶弄 ♥（黑體）
  function footer(img, y, wish) {
    // 固定標語：用招牌字型的點陣（2026-11-06），置中；兩邊不加愛心（2026-11-06 Rory）
    if (wish === SLOGAN_TEXT) {
      drawBits(img, SLOGAN, LEFT + (RIGHT - LEFT - SLOGAN.w) / 2, y);
      return SLOGAN.h;
    }
    const text = wish || FOOT_SHOP, bold = !!wish;
    if (wish) fontNow = FONT_SERIF;
    const span = px => HEART_SIZE * 2 + widthLs(img, text, px, bold, LS_FOOT) + FOOT_GAP * 2;
    let px = PX_FOOT;
    while (px > 16 && span(px) > RIGHT - LEFT) px -= 2;
    let x = LEFT + (RIGHT - LEFT - span(px)) / 2;
    const bb = img.bbox(0, y, text, px, bold);
    const mid = (bb[1] + bb[3]) / 2;
    heart(img, x + HEART_SIZE / 2, mid, HEART_SIZE);
    x += HEART_SIZE + FOOT_GAP;
    textLs(img, x, y, text, px, bold, LS_FOOT);
    x += widthLs(img, text, px, bold, LS_FOOT) + FOOT_GAP;
    heart(img, x + HEART_SIZE / 2, mid, HEART_SIZE);
    fontNow = FONT_FAMILY;
    return px;
  }
  // 依實際墨跡裁掉上下多餘的部分
  function trim(tall, y) {
    const ink = tall.ink();
    if (!ink) return tall.crop(0, Math.max(1, y));
    const top = Math.max(0, ink[1] - PAD_TOP);
    const bottom = Math.min(tall.h, ink[3] + PAD_BOTTOM);
    return tall.crop(top, Math.max(top + 1, bottom));
  }

  const int = v => parseInt(v, 10) || 0;
  const str = v => (v == null ? '' : String(v));

  function render(data) {
    const seq = str(data.seq);
    const cups = int(data.cups), total = int(data.total), revised = !!data.revised;
    const items = data.items || [];
    const adjust = data.adjust || [];
    const kind = str(data.kind);
    const straws = data.straws && typeof data.straws === 'object' ? data.straws : null;
    const stores = (data.stores || []).filter(s => s && typeof s === 'object' && s.left);
    const T = new Img(W, 320 + items.length * 110 + (adjust.length + 1) * 50 + 220 + (kind ? 360 : straws ? 90 : 0) + (data.hot ? 60 : 0)
      + stores.length * 90 + (stores.length ? 30 : 0) + items.length * 14 + 120 + LOGO.h + 30);
    let y = PAD_TOP;
    // 店標印在最上面（2026-11-05 Rory），在「外送單／自取單」黑條之上
    y += drawLogo(T, Math.round((W - LOGO.w) / 2), y) + 18;
    // 標語「想家的時候，喝一杯灶咖」：2026-11-06 Rory 從收據最下面移到店標下面（字縮小、左右比店標內縮）；設定關掉（noWish）就不印
    if (!data.noWish) {
      y -= 6;
      y += footer(T, y, SLOGAN_TEXT) + 14;
    }
    // 列印時間：置中小字、到秒，不加「列印」兩個字；改單重印時是重印的時間
    // 位置：2026-11-06 Rory 改放在店標下面（原本在頁尾標語上面）
    // 2026-11-06 Rory：時間再改放到收據最下面（置中）
    const printed = str(data.printed);

    // 「外送單／自取單」黑條：店標下面、單號上面（2026-11-05 試過移到單號下面取代粗線，Rory 覺得不好，改回來）
    if (kind) {
      const t = chars(kind).join(' ');
      const bb = T.bbox(0, 0, t, PX_KIND);
      const w = widthLs(T, t, PX_KIND, true, LS_KIND);
      T.rect([LEFT, y, RIGHT, y + KIND_H]);
      textLs(T, (LEFT + RIGHT - w) / 2, y + (KIND_H - (bb[3] - bb[1])) / 2 - bb[1], t, PX_KIND, true, LS_KIND, true);
      y += KIND_H + GAP_KIND;
    }

    const cupsT = '共 ' + cups + ' 杯';
    const rightW = Math.max(widthLs(T, cupsT, PX_CUPS, false, 0), revised ? widthLs(T, '已修改', PX_CUPS, true, 0) : 0) + 12;
    const labelW = widthLs(T, '單號', PX_SEQ_LABEL, false, 0) + 10;
    const qpx = shrink(T, seq, PX_SEQ, RIGHT - LEFT - labelW - rightW, true, LS_SEQ, 40);
    // 「單號」、數字、「共 N 杯」三個靠下對齊（2026-11-05 Rory）：照各自字的實際墨跡底部對齊到數字的底
    // seqStyle 1–5：預覽用的五種擺法（2026-11-05 Rory 要看），選定後拿掉
    const ss = int(data.seqStyle) || 1;
    const sb = T.bbox(0, 0, seq, qpx, true);
    let B = y - 6 + sb[3];
    const bottomAt = (text, px, bold) => B - T.bbox(0, 0, text, px, bold)[3];
    const cupsRight = () => {
      const cupsY = bottomAt(cupsT, PX_CUPS, false);
      right(T, RIGHT, cupsY, cupsT, PX_CUPS, false);
      if (revised) right(T, RIGHT, cupsY - PX_CUPS - 8, '已修改', PX_CUPS, true);
    };
    if (ss === 1) {
      textLs(T, LEFT + labelW, y - 6, seq, qpx, true, LS_SEQ);
      T.text(LEFT, bottomAt('單號', PX_SEQ_LABEL, false), '單號', PX_SEQ_LABEL, false);
      cupsRight();
    } else if (ss === 2) {
      // 「單號」小字在數字上面，數字靠左放大；共 N 杯靠右下
      T.text(LEFT, y - 4, '單號', 22, false);
      y += 22;
      const p2 = PX_SEQ + 8;
      textLs(T, LEFT - 2, y - 6, seq, p2, true, LS_SEQ);
      B = y - 6 + T.bbox(0, 0, seq, p2, true)[3];
      cupsRight();
      y += p2 - qpx;
    } else if (ss === 3) {
      // 三欄：左「單號」、中間數字置中、右「共 N 杯」
      const w = widthLs(T, seq, qpx, true, LS_SEQ);
      textLs(T, (LEFT + RIGHT - w) / 2, y - 6, seq, qpx, true, LS_SEQ);
      T.text(LEFT, bottomAt('單號', PX_SEQ_LABEL, false), '單號', PX_SEQ_LABEL, false);
      cupsRight();
    } else if (ss === 4) {
      // 數字反白：黑色圓角框、白字；「單號」在框左邊
      const w = widthLs(T, seq, qpx, true, LS_SEQ), x0 = LEFT + labelW, top = y - 6 + sb[1] - 8;
      T.g.fillStyle = '#000'; T.g.beginPath(); T.g.roundRect(x0 - 4, top, w + 20, (sb[3] - sb[1]) + 16, 8); T.g.fill();
      textLs(T, x0 + 6, y - 6, seq, qpx, true, LS_SEQ, true);
      B += 8;
      T.text(LEFT, bottomAt('單號', PX_SEQ_LABEL, false), '單號', PX_SEQ_LABEL, false);
      cupsRight();
      y += 8;
    } else if (ss === 5) {
      // 不寫「單號」，改成「#027」
      const t = '#' + seq, p5 = shrink(T, t, PX_SEQ, RIGHT - LEFT - rightW, true, LS_SEQ, 40);
      textLs(T, LEFT, y - 6, t, p5, true, LS_SEQ);
      B = y - 6 + T.bbox(0, 0, t, p5, true)[3];
      cupsRight();
    }
    y += qpx + GAP_SEQ_RULE;
    y = rule(T, y, RULE_MAIN) + GAP_RULE;

    const cust = data.customer && typeof data.customer === 'object' ? data.customer : null;
    if (kind && cust && (cust.who || cust.address || cust.due)) {
      // 外送／自取時間、稱呼電話、地址（2026-11-05 Rory 從十種選 5）：圓角外框包起來，28 號字；
      // 稱呼靠左、電話靠右同一行；差一點點放不下就縮一點排一行，不然才換行（地址斷在空格）
      const dueS = str(cust.due), whoS = str(cust.who), addrS = str(cust.address);
      const nameS = whoS.split('　')[0], phoneS = whoS.split('　').slice(1).join('　');
      const PAD = 12, X0 = LEFT + PAD, X1 = RIGHT - PAD, PX = PX_CUST_INFO;
      // 字體（2026-11-05 Rory 從五種選 2）：黑體、全部不加粗
      const LB = false, RB = false;     // 左邊（外送時間、稱呼）、右邊（時間、電話、地址）都不加粗
      const lines = text => {
        const fit = shrink(T, text, PX, X1 - X0, RB, 0, PX - 4);
        if (widthLs(T, text, fit, RB, 0) <= X1 - X0) { textLs(T, X0, y, text, fit, RB, 0); y += PX + 8; return; }
        wrapLines(T, text, PX, RB, X1 - X0, 0).forEach(l => { textLs(T, X0, y, l, PX, RB, 0); y += PX + 8; });
      };
      // 左右分開排：左邊字靠左、右邊字靠右；放不下就照原本整行排
      const split = (l, r) => {
        let p = PX;
        const need = q => widthLs(T, l, q, LB, 0) + 16 + widthLs(T, r, q, RB, 0);
        while (r && p > PX - 4 && need(p) > X1 - X0) p -= 1;
        if (r && need(p) <= X1 - X0) {
          textLs(T, X0, y, l, p, LB, 0);
          right(T, X1, y, r, p, RB);
          y += PX + 8;
        } else lines([l, r].filter(Boolean).join('　'));
      };
      const top = y; y += 12;
      // 外送時間：「外送時間」靠左、日期時間靠右（2026-11-05 Rory：跟下面的電話一樣）
      if (dueS) split(dueS.split('　')[0], dueS.split('　').slice(1).join('　'));
      if (whoS) split(nameS, phoneS);
      // 地址靠右；太長換行時，第一行靠右、後面幾行靠左（2026-11-05 Rory）
      if (addrS) {
        const fit = shrink(T, addrS, PX, X1 - X0, RB, 0, PX - 4);
        if (widthLs(T, addrS, fit, RB, 0) <= X1 - X0) { right(T, X1, y, addrS, fit, RB); y += PX + 8; }
        else wrapLines(T, addrS, PX, RB, X1 - X0, 0).forEach((l, k) => {
          if (k === 0) right(T, X1, y, l, PX, RB); else textLs(T, X0, y, l, PX, RB, 0);
          y += PX + 8;
        });
      }
      const g = T.g; g.lineWidth = 3; g.strokeStyle = '#000';
      g.beginPath(); g.roundRect(LEFT + 1.5, top + 1.5, RIGHT - LEFT - 3, y - top + 2, 10); g.stroke();
      y += 14;
      y += 6;
      y = rule(T, y, 1) + GAP_RULE;
    }

    // 表頭「品項」對齊品名的第一個字（序號「1. 」後面，照第一項的字級算）（2026-11-05 Rory）
    const firstName = '1. ' + str((items[0] || {}).name);
    const firstPx = shrink(T, firstName, PX_NAME, NAME_MAX, true, LS_NAME);
    T.text(LEFT + widthLs(T, '1. ', firstPx, true, LS_NAME) + LS_NAME, y, '品項', PX_HEAD, false);
    right(T, COL_QTY, y, '數量', PX_HEAD, false);
    right(T, COL_AMT, y, '小計', PX_HEAD, false);
    y += PX_HEAD + GAP_ROW;

    items.forEach((it, idx) => {
      // 品項之間畫細虛線（第一項上面是表頭，不畫）
      if (idx) { y -= Math.round(GAP_ROW / 2); y = dashed(T, y) + Math.round(GAP_ROW / 2) - 1; }
      // 序號「1.」「2.」…接在品名前面（2026-11-05 Rory）
      const name = (idx + 1) + '. ' + str(it.name), qty = int(it.qty), amount = int(it.amount), attrs = str(it.attrs);
      const npx = shrink(T, name, PX_NAME, NAME_MAX, true, LS_NAME);
      textLs(T, LEFT, y, name, npx, true, LS_NAME);
      const base = y + npx - PX_QTY;
      right(T, COL_QTY, base, String(qty), PX_QTY, false);
      right(T, COL_AMT, base, '$' + amount, PX_AMT, true);
      y += npx + GAP_ATTR;
      // 屬性、加料／備註的第一個字對齊品名的第一個字（序號「1. 」後面）（2026-11-05 Rory）
      const ind = LEFT + widthLs(T, (idx + 1) + '. ', npx, true, LS_NAME) + LS_NAME;
      // 屬性一行放不下就換行，不縮字：跟下面的加料／備註一樣大（2026-11-05 Rory：梅子可樂固定甜度那行變小）
      if (attrs) {
        wrapLines(T, attrs, PX_ATTR, false, RIGHT - ind, LS_ATTR).forEach((line, k) => {
          if (k) y += 4;
          textLs(T, ind, y, line, PX_ATTR, false, LS_ATTR);
          y += PX_ATTR;
        });
      }
      const mix = str(it.mix);
      if (mix) {
        y += GAP_MIX;
        wrapLines(T, mix, PX_ATTR, false, RIGHT - ind, LS_ATTR).forEach(line => {
          textLs(T, ind, y, line, PX_ATTR, false, LS_ATTR);
          y += PX_ATTR + 4;
        });
        y -= 4;
      }
      y += GAP_ROW;
    });

    if (adjust.length) {
      y += 2;
      y = rule(T, y, RULE_MAIN) + GAP_RULE;
      const rows = [['原價', '$' + int(data.subtotal)]].concat(adjust.map(a => [str(a.label), '-$' + Math.abs(int(a.amount))]));
      rows.forEach(([label, val]) => {
        T.text(LEFT, y, label, PX_NAME, false);
        right(T, COL_AMT, y, val, PX_AMT, true);
        y += PX_NAME + GAP_ATTR;
      });
    }

    y += 2;
    y = rule(T, y, RULE_MAIN) + GAP_RULE;
    // 合計金額跟「合計」兩個字一樣大（2026-11-05 Rory：不需要特別大；原本 54）
    T.text(LEFT, y, '合計', PX_TOTAL_LABEL, true);
    right(T, RIGHT, y, '$' + total, PX_TOTAL_LABEL, true);
    y += PX_TOTAL_LABEL + GAP_FOOT;

    if (stores.length) {
      stores.forEach(s => {
        const t = str(s.left), lpx = shrink(T, t, PX_STRAW, RIGHT - LEFT, false);
        textLs(T, LEFT, y, t, lpx, false, 0);
        y += lpx + 8;
        if (s.right) { right(T, RIGHT, y, str(s.right), PX_STRAW + 4, true); y += PX_STRAW + 4 + 14; }
      });
      y += 6;
      y = rule(T, y, 1) + 16;
    }

    if (data.hot) {
      const t = '※ 熱飲請小心燙口 ※', w = widthLs(T, t, PX_HOT, true, 1);
      textLs(T, (LEFT + RIGHT - w) / 2, y - 6, t, PX_HOT, true, 1);
      y += PX_HOT + 22;
    }

    // 吸管：2026-11-07 Rory 起每一張收據都印（原本只有外送、自取單）
    if (straws) {
      const t = '細吸管：' + int(straws.thin) + '　粗吸管：' + int(straws.thick);
      const spx = shrink(T, t, PX_STRAW, RIGHT - LEFT, true), w = widthLs(T, t, spx, true, 0);
      textLs(T, (LEFT + RIGHT - w) / 2, y, t, spx, true, 0);
      y += spx + 22;
      y = rule(T, y, 1) + 16;
    }

    // 標語已移到店標下面（2026-11-06），最下面不再印
    // 最下面一行：列印時間置中（2026-11-06 Rory：試過右邊加電話，又拿掉）
    if (printed) {
      y += 6;
      textLs(T, (LEFT + RIGHT - widthLs(T, printed, PX_PRINTED, false, 0)) / 2, y, printed, PX_PRINTED, false, 0);
      y += PX_PRINTED + 4;
    }
    y += PAD_BOTTOM;
    return trim(T, y);
  }

  function renderSummary(data) {
    const date = str(data.date), printed = str(data.printed);
    const orders = int(data.orders), cups = int(data.cups), revenue = int(data.revenue), voided = int(data.voided);
    const items = data.items || [];
    const avg = orders ? Math.round(revenue / orders) : 0;
    const money = n => n.toLocaleString('en-US');
    const T = new Img(W, 520 + items.length * 48);
    let y = PAD_TOP;
    const title = str(data.title || '本日營業總結');
    const tw = widthLs(T, title, 40, true, 4);
    textLs(T, LEFT + (RIGHT - LEFT - tw) / 2, y, title, 40, true, 4);
    y += 40 + 14;
    // 期間比較長（10/01～10/31）時「列印 時間」放不下同一行就換到下一行靠右（2026-11-01）
    const dateT = (data.range ? '期間 ' : '營業日 ') + date;
    T.text(LEFT, y, dateT, 24, false);
    if (printed) {
      const pt = '列印 ' + printed;
      if (widthLs(T, dateT, 24, false, 0) + 12 + widthLs(T, pt, 22, false, 0) > RIGHT - LEFT) y += 24 + 6;
      right(T, RIGHT, y, pt, 22, false);
    }
    y += 24 + GAP_RULE;
    y = rule(T, y) + GAP_RULE;
    // 營業額：整個月的數字比較長，放不下就縮字（不要撞到「營業額」三個字）
    T.text(LEFT, y + 60 - 32 - 8, '營業額', 32, true);
    const revT = '$' + money(revenue);
    const rpx = shrink(T, revT, 60, RIGHT - LEFT - widthLs(T, '營業額', 32, true, 0) - 14, true, 2, 30);
    right(T, RIGHT, y + (60 - rpx), revT, rpx, true, 2);
    y += 60 + GAP_RULE + 4;
    [['訂單數', orders + ' 筆'], ['杯數', cups + ' 杯'], ['平均客單價', '$' + money(avg)], ['作廢', voided + ' 筆']].forEach(([label, val]) => {
      T.text(LEFT, y, label, 28, false);
      right(T, RIGHT, y - 2, val, 30, true);
      y += 30 + 12;
    });
    if (items.length) {
      y += 4;
      y = rule(T, y) + GAP_RULE;
      T.text(LEFT, y, '品項', PX_HEAD, false);
      right(T, COL_QTY, y, '杯數', PX_HEAD, false);
      right(T, COL_AMT, y, '金額', PX_HEAD, false);
      y += PX_HEAD + 12;
      items.forEach(([name, qty, amt]) => {
        name = str(name);
        const npx = shrink(T, name, 28, NAME_MAX, true);
        T.text(LEFT, y, name, npx, true);
        right(T, COL_QTY, y + npx - 28, String(int(qty)), 28, false);
        // 金額欄只有數量欄右邊到紙邊這麼寬：整個月的金額（$377,190）放不下就縮字，不要壓到杯數
        const amtT = '$' + money(int(amt));
        const apx = shrink(T, amtT, 28, COL_AMT - COL_QTY - 10, true, 0, 16);
        right(T, COL_AMT, y + npx - apx, amtT, apx, true);
        y += npx + 14;
      });
    }
    y += 2;
    y = rule(T, y);
    return trim(T, y);
  }

  // ── 今日結算（2026-11-08 Rory，照舊收銀機的「銷售明細」）：品項 數量 金額 → 品項合計、折扣、寄杯折抵 → 現金應收 → 單數杯數 ──
  function renderClosing(data) {
    const items = data.items || [], discounts = data.discounts || [];
    const money = n => '$' + int(n).toLocaleString('en-US');
    const T = new Img(W, 900 + items.length * 48 + discounts.length * 34);
    let y = PAD_TOP;
    const title = '今日結算';
    textLs(T, LEFT + (RIGHT - LEFT - widthLs(T, title, 40, true, 6)) / 2, y, title, 40, true, 6);
    y += 40 + 14;
    T.text(LEFT, y, '營業日 ' + str(data.date), 24, false);
    if (data.printed) right(T, RIGHT, y, '列印 ' + str(data.printed), 22, false);
    y += 24 + GAP_RULE;
    y = rule(T, y) + GAP_RULE;
    T.text(LEFT, y, '品名', PX_HEAD, false);
    right(T, COL_QTY, y, '數量', PX_HEAD, false);
    right(T, COL_AMT, y, '金額', PX_HEAD, false);
    y += PX_HEAD + 12;
    items.forEach(([name, qty, amt]) => {
      name = str(name);
      const npx = shrink(T, name, 28, NAME_MAX, true);
      T.text(LEFT, y, name, npx, true);
      right(T, COL_QTY, y + npx - 28, String(int(qty)), 28, false);
      const amtT = money(amt);
      const apx = shrink(T, amtT, 28, COL_AMT - COL_QTY - 10, true, 0, 16);
      right(T, COL_AMT, y + npx - apx, amtT, apx, true);
      y += npx + 14;
    });
    y += 2;
    y = rule(T, y) + GAP_RULE;
    const row = (label, val, px) => { T.text(LEFT, y, label, px, false); right(T, RIGHT, y - 2, val, px + 2, true); y += px + 12; };
    row('品項合計', money(data.itemsSum), 28);
    row('折扣', '−' + money(data.discount), 28);
    discounts.forEach(([k, v]) => { T.text(LEFT + 24, y, str(k), 24, false); right(T, RIGHT - 120, y, '−' + money(v), 24, false); y += 24 + 10; });
    if (int(data.voucher)) row('寄杯折抵', '−' + money(data.voucher), 28);
    y += 2;
    y = rule(T, y) + GAP_RULE;
    // 現金應收：最大的字，放不下就縮
    T.text(LEFT, y + 60 - 34 - 8, '現金應收', 34, true);
    const cashT = money(data.cash);
    const cpx = shrink(T, cashT, 60, RIGHT - LEFT - widthLs(T, '現金應收', 34, true, 0) - 14, true, 2, 30);
    right(T, RIGHT, y + (60 - cpx), cashT, cpx, true, 2);
    y += 60 + GAP_RULE + 14;
    y = rule(T, y) + GAP_RULE;
    row('訂單數', int(data.orders) + ' 筆', 28);
    row('杯數(含' + int(data.ecoCups) + '環保杯)', int(data.cups) + ' 杯', 28);
    row('作廢', int(data.voided) + ' 筆', 28);
    // 待結帳：沒有也印「0 筆」（2026-11-09 Rory）
    row('待結帳', int(data.unpaid) + ' 筆　' + money(data.unpaidSum), 28);
    if (int(data.unpaid)) {
      T.text(LEFT, y, '（還沒收錢，不算在現金應收）', 22, false);
      y += 22 + 10;
    }
    // 還沒做的預定單：照預定的日子一天一行（還沒收錢的不算單數、杯數，做好那天才算）
    const rsv = Array.isArray(data.reserves) ? data.reserves : [];
    rsv.forEach(r => {
      const m = /^\d{4}-(\d{2})-(\d{2})$/.exec(str(r.due));
      row('預定單 ' + (m ? int(m[1]) + '/' + int(m[2]) : '日期未定'), int(r.n) + ' 筆　' + money(r.sum), 28);
    });
    // 收錢那天才算（2026-11-09 Rory）：以前下單今天結帳的算進今天；今天下單之後才結的算在結帳那天
    if (int(data.later)) {
      row('以前的單今天結帳', int(data.later) + ' 筆　' + money(data.laterSum), 28);
      T.text(LEFT, y, '（已算在現金應收）', 22, false);
      y += 22 + 10;
    }
    if (int(data.paidLater)) {
      row('今天的單之後結帳', int(data.paidLater) + ' 筆　' + money(data.paidLaterSum), 28);
      T.text(LEFT, y, '（算在結帳那天，不在現金應收）', 22, false);
      y += 22 + 10;
    }
    y += 2;
    y = rule(T, y);
    return trim(T, y);
  }

  // ── ESC/POS：GS v 0 點陣圖（1＝黑），每 128 列一段；最後 GS V B 0 送到切刀位置半切 ──
  function escpos(img) {
    const wb = (img.w + 7) >> 3;
    const d = img.g.getImageData(0, 0, img.w, img.h).data;
    const parts = [new Uint8Array([0x1b, 0x40])];
    for (let top = 0; top < img.h; top += 128) {
      const h = Math.min(128, img.h - top);
      const block = new Uint8Array(8 + wb * h);
      block.set([0x1d, 0x76, 0x30, 0x00, wb & 0xff, wb >> 8, h & 0xff, h >> 8]);
      // 整張往右挪 SHIFT_X dot 再送（2026-11-05 Rory：出單收據整體往右 1 mm＝8 dot）；右邊本來就留了 8 dot 白邊，不會切到字
      for (let y = 0; y < h; y++) for (let x = 0; x + SHIFT_X < img.w; x++) {
        const X = x + SHIFT_X;
        if (d[((top + y) * img.w + x) * 4] < 128) block[8 + y * wb + (X >> 3)] |= 0x80 >> (X & 7);
      }
      parts.push(block);
    }
    parts.push(new Uint8Array([0x1d, 0x56, 0x42, 0x00]));
    const out = new Uint8Array(parts.reduce((n, p) => n + p.length, 0));
    let o = 0;
    parts.forEach(p => { out.set(p, o); o += p.length; });
    return out;
  }

  // 對外：receipt-render.py 的 main()
  function render_(data) {
    if (data && data.kind === 'summary') return escpos(renderSummary(data));
    if (data && data.kind === 'closing') return escpos(renderClosing(data));
    if (!data || !data.items || !data.items.length) throw new Error('沒有品項');
    return escpos(render(data));
  }
  // 預覽用：收據的 canvas
  function preview(data) { return (data && data.kind === 'summary' ? renderSummary(data) : data && data.kind === 'closing' ? renderClosing(data) : render(data)).c; }

  window.ZaokaReceipt = { render: render_, preview, W };
})();
